import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  Users,
  FolderKanban,
  NotebookPen,
  CalendarDays,
  ShieldCheck,
  Package,
  FolderTree,
  Wrench,
  BadgePercent,
} from 'lucide-react';
import { useAppInfo } from '@lark-apaas/client-toolkit/hooks/useAppInfo';
import { useCurrentUserProfile } from '@lark-apaas/client-toolkit/hooks/useCurrentUserProfile';
import { getDataloom } from '@lark-apaas/client-toolkit/dataloom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from '@client/src/components/ui/sidebar';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbList,
} from '@client/src/components/ui/breadcrumb';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@client/src/components/ui/dropdown-menu';
import { Avatar, AvatarImage } from '@client/src/components/ui/avatar';
import { Separator } from '@client/src/components/ui/separator';
import { Image } from '@client/src/components/ui/image';
import { Can } from '@lark-apaas/client-toolkit/auth';

interface NavItem {
  path: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  subject?: 'Quotation' | 'Customer' | 'Project' | 'DailyReport' | 'MeetingMinutes' | 'Permission';
}

const NAV_ITEMS: NavItem[] = [
  { path: '/', label: '工作台', icon: LayoutDashboard },
  { path: '/quotations', label: '智能报价', icon: FileText, subject: 'Quotation' },
  { path: '/customers', label: '客户管理', icon: Users, subject: 'Customer' },
  { path: '/projects', label: '项目管理', icon: FolderKanban, subject: 'Project' },
  { path: '/daily-reports', label: '员工日报', icon: NotebookPen, subject: 'DailyReport' },
  { path: '/meeting-minutes', label: '会议纪要', icon: CalendarDays, subject: 'MeetingMinutes' },
  { path: '/permissions', label: '权限管理', icon: ShieldCheck, subject: 'Permission' },
];

const MASTER_DATA_ITEMS: NavItem[] = [
  { path: '/master-data/products', label: '产品管理', icon: Package },
  { path: '/master-data/categories', label: '定制分类', icon: FolderTree },
  { path: '/master-data/custom-items', label: '定制项管理', icon: Wrench },
  { path: '/master-data/pricing-rules', label: '定价规则', icon: BadgePercent },
];

const GUEST_AVATAR =
  'https://lf3-static.bytednsdoc.com/obj/eden-cn/LMfspH/ljhwZthlaukjlkulzlp/miao/no-person.svg';

const LayoutContent: React.FC = () => {
  const { pathname } = useLocation();
  const { appName, appLogo } = useAppInfo();
  const userInfo = useCurrentUserProfile();
  const isLoggedIn: boolean = Boolean(userInfo?.user_id);

  const activeItem: NavItem | undefined = [...NAV_ITEMS, ...MASTER_DATA_ITEMS].find(
    (item: NavItem) =>
      item.path === '/'
        ? pathname === '/'
        : pathname === item.path || pathname.startsWith(`${item.path}/`)
  );

  const handleLogout = async () => {
    const dataloom = await getDataloom();
    const result = await dataloom.service.session.signOut();
    if (result.error) {
      logger.error(`退出登录失败: ${result.error.message}`);
      return;
    }
    window.location.reload();
  };

  const handleLogin = async () => {
    const dataloom = await getDataloom();
    dataloom.service.session.redirectToLogin();
  };

  return (
    <>
      <Sidebar collapsible="icon" className="border-r">
        <SidebarHeader>
          <SidebarMenu>
            <SidebarMenuItem>
              <SidebarMenuButton size="lg" asChild>
                <Link to="/">
                  <div className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground overflow-hidden">
                    {appLogo ? (
                      <Image
                        src={appLogo}
                        alt="应用图标"
                        className="size-8 object-cover"
                      />
                    ) : (
                      <span className="text-sm font-bold">AI</span>
                    )}
                  </div>
                  <div className="grid flex-1 text-left text-sm leading-tight group-data-[collapsible=icon]:hidden">
                    <span className="truncate font-semibold">
                      {appName || '企业 AI 办公系统'}
                    </span>
                    <span className="truncate text-xs text-muted-foreground">
                      智能办公协作平台
                    </span>
                  </div>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupContent>
              <SidebarMenu>
                {NAV_ITEMS.map((item: NavItem) => {
                  const menuButton = (
                    <SidebarMenuButton
                      asChild
                      isActive={
                        item.path === '/'
                          ? pathname === '/'
                          : pathname === item.path ||
                            pathname.startsWith(`${item.path}/`)
                      }
                      tooltip={item.label}
                    >
                      <Link to={item.path}>
                        <item.icon className="size-4" />
                        <span>{item.label}</span>
                      </Link>
                    </SidebarMenuButton>
                  );
                  return (
                    <SidebarMenuItem key={item.path}>
                      {item.subject ? (
                        <Can action="read" subject={item.subject}>
                          {menuButton}
                        </Can>
                      ) : (
                        menuButton
                      )}
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
          <SidebarGroup>
            <SidebarGroupLabel>基础数据管理</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {MASTER_DATA_ITEMS.map((item: NavItem) => (
                  <SidebarMenuItem key={item.path}>
                    <SidebarMenuButton
                      asChild
                      isActive={
                        pathname === item.path ||
                        pathname.startsWith(`${item.path}/`)
                      }
                      tooltip={item.label}
                    >
                      <Link to={item.path}>
                        <item.icon className="size-4" />
                        <span>{item.label}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                className="flex w-full items-center gap-2 rounded-lg p-2 text-left hover:bg-accent transition-colors"
              >
                <Avatar className="size-8">
                  <AvatarImage
                    src={isLoggedIn ? userInfo.avatar : GUEST_AVATAR}
                    alt={userInfo?.name || '用户头像'}
                  />
                </Avatar>
                <div className="grid flex-1 text-left text-sm leading-tight group-data-[collapsible=icon]:hidden">
                  <span className="truncate font-medium">
                    {isLoggedIn ? userInfo.name : '游客'}
                  </span>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              {isLoggedIn ? (
                <DropdownMenuItem onClick={handleLogout}>
                  退出登录
                </DropdownMenuItem>
              ) : (
                <DropdownMenuItem onClick={handleLogin}>登录</DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </SidebarFooter>
      </Sidebar>
      <main className="flex flex-1 flex-col overflow-hidden p-6">
        <header className="mb-6 flex h-8 items-center gap-2">
          <SidebarTrigger />
          <Separator orientation="vertical" className="h-4" />
          <Breadcrumb className="self-center">
            <BreadcrumbList>
              <BreadcrumbItem className="text-foreground font-medium">
                {activeItem ? activeItem.label : '未找到页面'}
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
        </header>
        <div className="flex-1 overflow-auto">
          <Outlet />
        </div>
      </main>
    </>
  );
};

const Layout: React.FC = () => {
  return (
    <SidebarProvider>
      <LayoutContent />
    </SidebarProvider>
  );
};

export default Layout;
