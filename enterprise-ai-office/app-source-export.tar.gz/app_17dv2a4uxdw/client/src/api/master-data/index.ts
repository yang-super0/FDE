import { request } from '@client/src/api';
import type {
  CreateCustomCategoryRequest,
  CreateCustomItemRequest,
  CreatePricingRuleRequest,
  CreateProductRequest,
  CustomCategoryOptionsResponse,
  CustomCategoryTreeResponse,
  CustomItemAdminListParams,
  CustomItemAdminListResponse,
  CustomItemOptionsResponse,
  PricingRuleAdminListParams,
  PricingRuleAdminListResponse,
  ProductAdminListParams,
  ProductAdminListResponse,
  SuccessResponse,
  UpdateBaseDataStatusRequest,
  UpdateCustomCategoryRequest,
  UpdateCustomItemRequest,
  UpdatePricingRuleRequest,
  UpdateProductRequest,
} from '@shared/api.interface';

export function listProductsAdmin(
  params: ProductAdminListParams,
): Promise<ProductAdminListResponse> {
  return request<ProductAdminListResponse>({
    url: '/api/master-data/products',
    method: 'GET',
    params,
  });
}

export function createProduct(
  data: CreateProductRequest,
): Promise<{ id: string }> {
  return request<{ id: string }>({
    url: '/api/master-data/products',
    method: 'POST',
    data,
  });
}

export function updateProduct(
  id: string,
  data: UpdateProductRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/master-data/products/${id}`,
    method: 'PATCH',
    data,
  });
}

export function updateProductStatus(
  id: string,
  data: UpdateBaseDataStatusRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/master-data/products/${id}/status`,
    method: 'PATCH',
    data,
  });
}

export function listCategoryTree(
  keyword?: string,
): Promise<CustomCategoryTreeResponse> {
  return request<CustomCategoryTreeResponse>({
    url: '/api/master-data/custom-categories/tree',
    method: 'GET',
    params: keyword ? { keyword } : undefined,
  });
}

export function listCategoryOptions(): Promise<CustomCategoryOptionsResponse> {
  return request<CustomCategoryOptionsResponse>({
    url: '/api/master-data/custom-categories/options',
    method: 'GET',
  });
}

export function createCategory(
  data: CreateCustomCategoryRequest,
): Promise<{ id: string }> {
  return request<{ id: string }>({
    url: '/api/master-data/custom-categories',
    method: 'POST',
    data,
  });
}

export function updateCategory(
  id: string,
  data: UpdateCustomCategoryRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/master-data/custom-categories/${id}`,
    method: 'PATCH',
    data,
  });
}

export function updateCategoryStatus(
  id: string,
  data: UpdateBaseDataStatusRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/master-data/custom-categories/${id}/status`,
    method: 'PATCH',
    data,
  });
}

export function listCustomItemsAdmin(
  params: CustomItemAdminListParams,
): Promise<CustomItemAdminListResponse> {
  return request<CustomItemAdminListResponse>({
    url: '/api/master-data/custom-items',
    method: 'GET',
    params,
  });
}

export function listCustomItemOptions(): Promise<CustomItemOptionsResponse> {
  return request<CustomItemOptionsResponse>({
    url: '/api/master-data/custom-items/options',
    method: 'GET',
  });
}

export function createCustomItem(
  data: CreateCustomItemRequest,
): Promise<{ id: string }> {
  return request<{ id: string }>({
    url: '/api/master-data/custom-items',
    method: 'POST',
    data,
  });
}

export function updateCustomItem(
  id: string,
  data: UpdateCustomItemRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/master-data/custom-items/${id}`,
    method: 'PATCH',
    data,
  });
}

export function updateCustomItemStatus(
  id: string,
  data: UpdateBaseDataStatusRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/master-data/custom-items/${id}/status`,
    method: 'PATCH',
    data,
  });
}

export function listPricingRulesAdmin(
  params: PricingRuleAdminListParams,
): Promise<PricingRuleAdminListResponse> {
  return request<PricingRuleAdminListResponse>({
    url: '/api/master-data/pricing-rules',
    method: 'GET',
    params,
  });
}

export function createPricingRule(
  data: CreatePricingRuleRequest,
): Promise<{ id: string }> {
  return request<{ id: string }>({
    url: '/api/master-data/pricing-rules',
    method: 'POST',
    data,
  });
}

export function updatePricingRule(
  id: string,
  data: UpdatePricingRuleRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/master-data/pricing-rules/${id}`,
    method: 'PATCH',
    data,
  });
}

export function updatePricingRuleStatus(
  id: string,
  data: UpdateBaseDataStatusRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/master-data/pricing-rules/${id}/status`,
    method: 'PATCH',
    data,
  });
}
