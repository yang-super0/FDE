import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  AlertListResponse,
  AlertMarkAllReadResponse,
  AlertSuccessResponse,
  AlertType,
} from '@shared/api.interface';

export const fetchAlerts = async (
  type?: AlertType
): Promise<AlertListResponse> => {
  const response = await axiosForBackend.get('/api/alerts', {
    params: type ? { type } : {},
  });
  return response.data;
};

export const dismissAlert = async (
  type: AlertType,
  targetId: string
): Promise<AlertSuccessResponse> => {
  const response = await axiosForBackend.post('/api/alerts/dismiss', {
    type,
    targetId,
  });
  return response.data;
};

export const markAlertsAllRead =
  async (): Promise<AlertMarkAllReadResponse> => {
    const response = await axiosForBackend.post('/api/alerts/mark-all-read');
    return response.data;
  };
