import { request } from '@client/src/api';
import type {
  CustomerTimelineMinutesResponse,
  MeetingMinuteDetail,
  MeetingMinuteListParams,
  MeetingMinuteListResponse,
  SaveMeetingMinuteRequest,
  SaveMeetingMinuteResponse,
  SuccessResponse,
} from '@shared/api.interface';

export function listMeetingMinutes(
  params: MeetingMinuteListParams,
): Promise<MeetingMinuteListResponse> {
  return request<MeetingMinuteListResponse>({
    url: '/api/meeting-minutes',
    method: 'GET',
    params,
  });
}

export function getMeetingMinuteDetail(id: string): Promise<MeetingMinuteDetail> {
  return request<MeetingMinuteDetail>({
    url: `/api/meeting-minutes/${id}`,
    method: 'GET',
  });
}

export function createMeetingMinute(
  data: SaveMeetingMinuteRequest,
): Promise<SaveMeetingMinuteResponse> {
  return request<SaveMeetingMinuteResponse>({
    url: '/api/meeting-minutes',
    method: 'POST',
    data,
  });
}

export function updateMeetingMinute(
  id: string,
  data: SaveMeetingMinuteRequest,
): Promise<SaveMeetingMinuteResponse> {
  return request<SaveMeetingMinuteResponse>({
    url: `/api/meeting-minutes/${id}`,
    method: 'PUT',
    data,
  });
}

export function deleteMeetingMinute(id: string): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/meeting-minutes/${id}`,
    method: 'DELETE',
  });
}

export function listCustomerMinutes(
  customerId: string,
): Promise<CustomerTimelineMinutesResponse> {
  return request<CustomerTimelineMinutesResponse>({
    url: `/api/meeting-minutes/customer/${customerId}`,
    method: 'GET',
  });
}
