import { request } from '@client/src/api';
import type {
  CreateQuotationRequest,
  CreateQuotationResponse,
  QuotationDetail,
  QuotationListParams,
  QuotationListResponse,
  SuccessResponse,
  UpdateQuotationRequest,
  UpdateQuotationStatusRequest,
} from '@shared/api.interface';

export function listQuotations(
  params: QuotationListParams,
): Promise<QuotationListResponse> {
  return request<QuotationListResponse>({
    url: '/api/quotations',
    method: 'GET',
    params,
  });
}

export function getQuotationDetail(id: string): Promise<QuotationDetail> {
  return request<QuotationDetail>({
    url: `/api/quotations/${id}`,
    method: 'GET',
  });
}

export function createQuotation(
  data: CreateQuotationRequest,
): Promise<CreateQuotationResponse> {
  return request<CreateQuotationResponse>({
    url: '/api/quotations',
    method: 'POST',
    data,
  });
}

export function updateQuotation(
  id: string,
  data: UpdateQuotationRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/quotations/${id}`,
    method: 'PATCH',
    data,
  });
}

export function updateQuotationStatus(
  id: string,
  data: UpdateQuotationStatusRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/quotations/${id}/status`,
    method: 'PATCH',
    data,
  });
}
