import { request } from '@client/src/api';
import type {
  ProductCustomOptionsResponse,
  ProductListResponse,
} from '@shared/api.interface';

export function listProducts(): Promise<ProductListResponse> {
  return request<ProductListResponse>({
    url: '/api/products',
    method: 'GET',
  });
}

export function getProductCustomOptions(
  productId: string,
): Promise<ProductCustomOptionsResponse> {
  return request<ProductCustomOptionsResponse>({
    url: `/api/products/${productId}/custom-options`,
    method: 'GET',
  });
}
