import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import type {
  DashboardOverview,
  DashboardOwnerOption,
  DashboardRange,
  DashboardStats,
  DashboardTodos,
} from '@shared/api.interface';

export const getOverview = async (): Promise<DashboardOverview> => {
  const response = await axiosForBackend.get('/api/dashboard/overview');
  return response.data;
};

export const getTodos = async (): Promise<DashboardTodos> => {
  const response = await axiosForBackend.get('/api/dashboard/todos');
  return response.data;
};

export interface GetDashboardStatsParams {
  range: DashboardRange;
  startDate?: string;
  endDate?: string;
  ownerId?: string;
}

export const getStats = async (
  params: GetDashboardStatsParams
): Promise<DashboardStats> => {
  const response = await axiosForBackend.get('/api/dashboard/stats', {
    params,
  });
  return response.data;
};

export const getOwners = async (): Promise<DashboardOwnerOption[]> => {
  const response = await axiosForBackend.get('/api/dashboard/owners');
  return response.data;
};
