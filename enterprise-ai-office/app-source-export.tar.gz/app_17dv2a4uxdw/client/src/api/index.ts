import type { AxiosRequestConfig, AxiosResponse } from 'axios';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';

export class ForbiddenError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ForbiddenError';
  }
}

export async function request<T>(config: AxiosRequestConfig): Promise<T> {
  try {
    const response: AxiosResponse<T> = await axiosForBackend<T>(config);
    if (response.status === 403) {
      throw new ForbiddenError('无操作权限，请联系管理员分配角色');
    }
    return response.data;
  } catch (error) {
    if (error instanceof ForbiddenError) {
      throw error;
    }
    logger.error(String(error));
    throw error;
  }
}

export { axiosForBackend };
