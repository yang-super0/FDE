import { request } from '@client/src/api';
import type {
  AddProjectMembersRequest,
  CreateProjectRequest,
  CreateProjectResponse,
  CreateProjectTaskRequest,
  CreateProjectTaskResponse,
  ProjectDetail,
  ProjectListParams,
  ProjectListResponse,
  ProjectTaskListResponse,
  SuccessResponse,
  UpdateProjectStatusRequest,
  UpdateProjectRequest,
  UpdateProjectTaskRequest,
} from '@shared/api.interface';

export async function fetchProjects(
  params: ProjectListParams,
): Promise<ProjectListResponse> {
  return request<ProjectListResponse>({
    url: '/api/projects',
    method: 'GET',
    params,
  });
}

export async function createProject(
  data: CreateProjectRequest,
): Promise<CreateProjectResponse> {
  return request<CreateProjectResponse>({
    url: '/api/projects',
    method: 'POST',
    data,
  });
}

export async function fetchProjectDetail(id: string): Promise<ProjectDetail> {
  return request<ProjectDetail>({
    url: `/api/projects/${id}`,
    method: 'GET',
  });
}

export async function updateProject(
  id: string,
  data: UpdateProjectRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/projects/${id}`,
    method: 'PATCH',
    data,
  });
}

export async function updateProjectStatus(
  id: string,
  data: UpdateProjectStatusRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/projects/${id}/status`,
    method: 'PATCH',
    data,
  });
}

export async function addProjectMembers(
  id: string,
  data: AddProjectMembersRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/projects/${id}/members`,
    method: 'POST',
    data,
  });
}

export async function fetchProjectTasks(
  id: string,
): Promise<ProjectTaskListResponse> {
  return request<ProjectTaskListResponse>({
    url: `/api/projects/${id}/tasks`,
    method: 'GET',
  });
}

export async function createProjectTask(
  id: string,
  data: CreateProjectTaskRequest,
): Promise<CreateProjectTaskResponse> {
  return request<CreateProjectTaskResponse>({
    url: `/api/projects/${id}/tasks`,
    method: 'POST',
    data,
  });
}

export async function updateProjectTask(
  id: string,
  taskId: string,
  data: UpdateProjectTaskRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/projects/${id}/tasks/${taskId}`,
    method: 'PATCH',
    data,
  });
}
