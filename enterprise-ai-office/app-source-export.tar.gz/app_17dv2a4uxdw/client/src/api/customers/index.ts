import { request } from '@client/src/api';
import type {
  BatchAssignCustomerRequest,
  CreateCustomerRequest,
  CreateCustomerResponse,
  CreateFollowUpRequest,
  CreateFollowUpResponse,
  CustomerDetail,
  CustomerListParams,
  CustomerListResponse,
  CustomerOwnerListResponse,
  CustomerProjectListResponse,
  CustomerQuotationListResponse,
  CustomerUnassignedCountResponse,
  CurrentUserRoleResponse,
  FollowUpListResponse,
  SuccessResponse,
  TransferCustomerRequest,
  UpdateCustomerRequest,
} from '@shared/api.interface';

export function listCustomers(
  params: CustomerListParams,
): Promise<CustomerListResponse> {
  return request<CustomerListResponse>({
    url: '/api/customers',
    method: 'GET',
    params,
  });
}

export function createCustomer(
  data: CreateCustomerRequest,
): Promise<CreateCustomerResponse> {
  return request<CreateCustomerResponse>({
    url: '/api/customers',
    method: 'POST',
    data,
  });
}

export function getCustomerDetail(id: string): Promise<CustomerDetail> {
  return request<CustomerDetail>({
    url: `/api/customers/${id}`,
    method: 'GET',
  });
}

export function updateCustomer(
  id: string,
  data: UpdateCustomerRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/customers/${id}`,
    method: 'PATCH',
    data,
  });
}

export function listFollowUps(
  customerId: string,
): Promise<FollowUpListResponse> {
  return request<FollowUpListResponse>({
    url: `/api/customers/${customerId}/follow-ups`,
    method: 'GET',
  });
}

export function createFollowUp(
  customerId: string,
  data: CreateFollowUpRequest,
): Promise<CreateFollowUpResponse> {
  return request<CreateFollowUpResponse>({
    url: `/api/customers/${customerId}/follow-ups`,
    method: 'POST',
    data,
  });
}

export function listCustomerQuotations(
  customerId: string,
): Promise<CustomerQuotationListResponse> {
  return request<CustomerQuotationListResponse>({
    url: `/api/customers/${customerId}/quotations`,
    method: 'GET',
  });
}

export function listCustomerProjects(
  customerId: string,
): Promise<CustomerProjectListResponse> {
  return request<CustomerProjectListResponse>({
    url: `/api/customers/${customerId}/projects`,
    method: 'GET',
  });
}

export function getCurrentUserRole(): Promise<CurrentUserRoleResponse> {
  return request<CurrentUserRoleResponse>({
    url: '/api/customers/me/role',
    method: 'GET',
  });
}

export function listCustomerOwners(): Promise<CustomerOwnerListResponse> {
  return request<CustomerOwnerListResponse>({
    url: '/api/customers/owners',
    method: 'GET',
  });
}

export function batchAssignCustomers(
  data: BatchAssignCustomerRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: '/api/customers/batch-assign',
    method: 'POST',
    data,
  });
}

export function transferCustomer(
  customerId: string,
  data: TransferCustomerRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/customers/${customerId}/transfer`,
    method: 'POST',
    data,
  });
}

export function getUnassignedCount(): Promise<CustomerUnassignedCountResponse> {
  return request<CustomerUnassignedCountResponse>({
    url: '/api/customers/unassigned-count',
    method: 'GET',
  });
}
