import { request } from '@client/src/api';
import type {
  AutoDraftRequest,
  AutoDraftResponse,
  MyDailyReportItem,
  MyDailyReportListResponse,
  SaveDailyReportDraftRequest,
  SaveDailyReportDraftResponse,
  SubmitDailyReportRequest,
  SubmitDailyReportResponse,
  TeamDailyReportParams,
  TeamDailyReportResponse,
} from '@shared/api.interface';

export async function submitDailyReport(
  data: SubmitDailyReportRequest,
): Promise<SubmitDailyReportResponse> {
  return request<SubmitDailyReportResponse>({
    url: '/api/daily-reports',
    method: 'POST',
    data,
  });
}

export async function saveDailyReportDraft(
  data: SaveDailyReportDraftRequest,
): Promise<SaveDailyReportDraftResponse> {
  return request<SaveDailyReportDraftResponse>({
    url: '/api/daily-reports/draft',
    method: 'POST',
    data,
  });
}

export async function generateDailyReportDraft(
  data: AutoDraftRequest,
): Promise<AutoDraftResponse> {
  return request<AutoDraftResponse>({
    url: '/api/daily-reports/auto-draft',
    method: 'POST',
    data,
  });
}

export async function getMyDailyReports(): Promise<MyDailyReportListResponse> {
  return request<MyDailyReportListResponse>({
    url: '/api/daily-reports/mine',
    method: 'GET',
  });
}

export async function getMyDailyReportByDate(
  date: string,
): Promise<MyDailyReportItem | null> {
  return request<MyDailyReportItem | null>({
    url: '/api/daily-reports/mine/detail',
    method: 'GET',
    params: { date },
  });
}

export async function getTeamDailyReports(
  params: TeamDailyReportParams,
): Promise<TeamDailyReportResponse> {
  return request<TeamDailyReportResponse>({
    url: '/api/daily-reports/team',
    method: 'GET',
    params,
  });
}
