import { request } from '@client/src/api';
import type {
  AssignMemberRolesRequest,
  CreateRoleRequest,
  CreateRoleResponse,
  MemberListResponse,
  PermissionPointInfo,
  RoleListResponse,
  SuccessResponse,
  UpdateRoleRequest,
} from '@shared/api.interface';

export function listRoles(): Promise<RoleListResponse> {
  return request<RoleListResponse>({
    url: '/api/permission-admin/roles',
    method: 'GET',
  });
}

export function createRole(
  data: CreateRoleRequest,
): Promise<CreateRoleResponse> {
  return request<CreateRoleResponse>({
    url: '/api/permission-admin/roles',
    method: 'POST',
    data,
  });
}

export function updateRole(
  id: string,
  data: UpdateRoleRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/permission-admin/roles/${id}`,
    method: 'PATCH',
    data,
  });
}

export function deleteRole(id: string): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/permission-admin/roles/${id}`,
    method: 'DELETE',
  });
}

export function listMembers(): Promise<MemberListResponse> {
  return request<MemberListResponse>({
    url: '/api/permission-admin/members',
    method: 'GET',
  });
}

export function assignMemberRoles(
  userId: string,
  data: AssignMemberRolesRequest,
): Promise<SuccessResponse> {
  return request<SuccessResponse>({
    url: `/api/permission-admin/members/${userId}/roles`,
    method: 'POST',
    data,
  });
}

export function getPermissionPoints(): Promise<PermissionPointInfo[]> {
  return request<PermissionPointInfo[]>({
    url: '/api/permission-admin/permission-points',
    method: 'GET',
  });
}
