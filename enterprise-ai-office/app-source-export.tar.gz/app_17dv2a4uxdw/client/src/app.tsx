import React from 'react';
import { Route, Routes } from 'react-router-dom';

import Layout from './components/Layout';
import NotFound from './pages/NotFound/NotFound';
import WorkbenchPage from './pages/Workbench/WorkbenchPage';
import QuotationsPage from './pages/Quotations/QuotationsPage';
import CustomersPage from './pages/Customers/CustomersPage';
import CustomerDetailPage from './pages/Customers/CustomerDetailPage';
import ProjectsPage from './pages/Projects/ProjectsPage';
import ProjectDetailPage from './pages/Projects/ProjectDetailPage';
import DailyReportsPage from './pages/DailyReports/DailyReportsPage';
import PermissionsPage from './pages/Permissions/PermissionsPage';
import MasterProductsPage from './pages/MasterData/MasterProductsPage';
import MasterCategoriesPage from './pages/MasterData/MasterCategoriesPage';
import MasterCustomItemsPage from './pages/MasterData/MasterCustomItemsPage';
import MasterPricingRulesPage from './pages/MasterData/MasterPricingRulesPage';
import { MeetingMinutesPage } from './pages/MeetingMinutes/MeetingMinutesPage';
import { MinuteFormPage } from './pages/MeetingMinutes/MinuteFormPage';
import { MinuteDetailPage } from './pages/MeetingMinutes/MinuteDetailPage';

const RoutesComponent = () => {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<WorkbenchPage />} />
        <Route path="quotations" element={<QuotationsPage />} />
        <Route path="customers" element={<CustomersPage />} />
        <Route path="customers/:id" element={<CustomerDetailPage />} />
        <Route path="projects" element={<ProjectsPage />} />
        <Route path="projects/:id" element={<ProjectDetailPage />} />
        <Route path="daily-reports" element={<DailyReportsPage />} />
        <Route path="permissions" element={<PermissionsPage />} />
        <Route path="master-data/products" element={<MasterProductsPage />} />
        <Route path="master-data/categories" element={<MasterCategoriesPage />} />
        <Route path="master-data/custom-items" element={<MasterCustomItemsPage />} />
        <Route path="master-data/pricing-rules" element={<MasterPricingRulesPage />} />
        <Route path="meeting-minutes" element={<MeetingMinutesPage />} />
        <Route path="meeting-minutes/new" element={<MinuteFormPage />} />
        <Route path="meeting-minutes/:id" element={<MinuteDetailPage />} />
        <Route path="meeting-minutes/:id/edit" element={<MinuteFormPage />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default RoutesComponent;
