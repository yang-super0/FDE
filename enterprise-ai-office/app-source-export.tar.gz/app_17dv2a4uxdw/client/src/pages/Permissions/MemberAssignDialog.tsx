import React, { useEffect, useState } from 'react';
import { Button } from '@client/src/components/ui/button';
import { Checkbox } from '@client/src/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { UserSelect } from '@client/src/components/business-ui/user-select';
import type { MemberRoleInfo, RoleInfo } from '@shared/api.interface';

interface MemberAssignDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  member: MemberRoleInfo | null;
  roles: RoleInfo[];
  submitting: boolean;
  onSubmit: (userId: string, roleIds: string[]) => void;
}

const MemberAssignDialog: React.FC<MemberAssignDialogProps> = ({
  open,
  onOpenChange,
  member,
  roles,
  submitting,
  onSubmit,
}) => {
  const [selectedRoleIds, setSelectedRoleIds] = useState<string[]>([]);
  const [pickedUserId, setPickedUserId] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setSelectedRoleIds(member?.roleIds ?? []);
      setPickedUserId(null);
    }
  }, [open, member]);

  const isNewMember: boolean = !member || member.userId.length === 0;
  const effectiveUserId: string = isNewMember
    ? (pickedUserId ?? '')
    : member.userId;

  const assignableRoles: RoleInfo[] = roles.filter(
    (role: RoleInfo) => !role.isBuiltin,
  );

  const toggleRole = (roleId: string, checked: boolean | 'indeterminate') => {
    setSelectedRoleIds((prev: string[]) => {
      if (checked === true) {
        return prev.includes(roleId) ? prev : [...prev, roleId];
      }
      return prev.filter((item: string) => item !== roleId);
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl rounded-xl shadow-lg">
        <DialogHeader>
          <DialogTitle>分配角色</DialogTitle>
          <DialogDescription>
            {isNewMember
              ? '选择成员并分配角色，保存后立即生效（全量覆盖）'
              : `为成员 ${member?.name ?? ''} 分配角色，保存后立即生效（全量覆盖）`}
          </DialogDescription>
        </DialogHeader>
        {isNewMember ? (
          <div className="space-y-2">
            <p className="text-sm font-medium text-foreground">选择成员</p>
            <UserSelect
              value={pickedUserId}
              onChange={(value: string | null) => setPickedUserId(value)}
              placeholder="请搜索并选择成员"
            />
          </div>
        ) : null}
        <div className="max-h-[320px] space-y-2 overflow-y-auto rounded-lg border border-border p-4">
          {assignableRoles.length === 0 ? (
            <p className="py-4 text-center text-sm text-muted-foreground">
              暂无可分配的角色，请先新建角色
            </p>
          ) : null}
          {assignableRoles.map((role: RoleInfo) => {
            const checked: boolean = selectedRoleIds.includes(role.id);
            return (
              <label
                key={role.id}
                className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-2 transition-colors duration-200 hover:bg-accent"
              >
                <Checkbox
                  checked={checked}
                  onCheckedChange={(value: boolean | 'indeterminate') =>
                    toggleRole(role.id, value)
                  }
                />
                <span className="text-sm font-medium text-foreground">
                  {role.name}
                </span>
                <span className="text-xs text-muted-foreground">
                  {role.memberCount} 名成员
                </span>
              </label>
            );
          })}
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={submitting}
          >
            取消
          </Button>
          <Button
            onClick={() => onSubmit(effectiveUserId, selectedRoleIds)}
            disabled={submitting || effectiveUserId.length === 0}
          >
            {submitting ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default MemberAssignDialog;
