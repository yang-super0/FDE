import React, { useEffect, useState } from 'react';
import { Button } from '@client/src/components/ui/button';
import { Checkbox } from '@client/src/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import { PERMISSION_SUBJECT_META } from '@shared/permissions';
import type { PermissionPointInfo } from '@shared/api.interface';

const ACTION_LABELS: Record<string, string> = {
  read: '查看',
  operate: '操作',
  manage: '管理',
};

interface RoleFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mode: 'create' | 'edit';
  initialName: string;
  initialPermissionKeys: string[];
  permissionPoints: PermissionPointInfo[];
  submitting: boolean;
  onSubmit: (name: string, permissionKeys: string[]) => void;
}

const RoleFormDialog: React.FC<RoleFormDialogProps> = ({
  open,
  onOpenChange,
  mode,
  initialName,
  initialPermissionKeys,
  permissionPoints,
  submitting,
  onSubmit,
}) => {
  const [name, setName] = useState<string>('');
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (open) {
      setName(initialName);
      setSelectedKeys(initialPermissionKeys);
      setError('');
    }
  }, [open, initialName, initialPermissionKeys]);

  const toggleKey = (key: string, checked: boolean | 'indeterminate') => {
    setSelectedKeys((prev: string[]) => {
      if (checked === true) {
        return prev.includes(key) ? prev : [...prev, key];
      }
      return prev.filter((item: string) => item !== key);
    });
  };

  const handleSubmit = () => {
    const trimmedName: string = name.trim();
    if (!trimmedName) {
      setError('请输入角色名称');
      return;
    }
    setError('');
    onSubmit(trimmedName, selectedKeys);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl rounded-xl shadow-lg">
        <DialogHeader>
          <DialogTitle>{mode === 'create' ? '新建角色' : '编辑角色'}</DialogTitle>
          <DialogDescription>
            配置角色名称与权限点，保存后立即生效
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="role-name">角色名称</Label>
            <Input
              id="role-name"
              value={name}
              placeholder="请输入角色名称"
              onChange={(event: React.ChangeEvent<HTMLInputElement>) =>
                setName(event.target.value)
              }
            />
          </div>
          <div className="space-y-3">
            <Label>权限点</Label>
            <div className="max-h-[320px] space-y-4 overflow-y-auto rounded-lg border border-border p-4">
              {PERMISSION_SUBJECT_META.map(
                (meta: { subject: string; label: string }) => {
                  const points: PermissionPointInfo[] =
                    permissionPoints.filter(
                      (point: PermissionPointInfo) =>
                        point.subject === meta.subject,
                    );
                  if (points.length === 0) {
                    return null;
                  }
                  return (
                    <div key={meta.subject} className="space-y-2">
                      <p className="text-sm font-medium text-foreground">
                        {meta.label}
                      </p>
                      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                        {points.map((point: PermissionPointInfo) => {
                          const key: string = `${point.action}:${point.subject}`;
                          const checked: boolean = selectedKeys.includes(key);
                          return (
                            <label
                              key={point.id}
                              className="flex cursor-pointer items-start gap-2 rounded-lg px-2 py-1.5 transition-colors duration-200 hover:bg-accent"
                            >
                              <Checkbox
                                checked={checked}
                                onCheckedChange={(
                                  value: boolean | 'indeterminate',
                                ) => toggleKey(key, value)}
                              />
                              <span className="text-sm leading-5 text-foreground">
                                {ACTION_LABELS[point.action] ?? point.action}
                                <span className="text-muted-foreground">
                                  （{point.description}）
                                </span>
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  );
                },
              )}
            </div>
          </div>
          {error ? <p className="text-sm text-red-600">{error}</p> : null}
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={submitting}
          >
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={submitting}>
            {submitting ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default RoleFormDialog;
