import React, { useCallback, useEffect, useState } from 'react';
import {
  Building2,
  Loader2,
  Pencil,
  Plus,
  ShieldCheck,
  Trash2,
  Users,
} from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  assignMemberRoles,
  createRole,
  deleteRole,
  getPermissionPoints,
  listMembers,
  listRoles,
  updateRole,
} from '@client/src/api/permissions';
import { UserDisplay } from '@client/src/components/business-ui/user-display';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@client/src/components/ui/alert-dialog';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent, CardHeader } from '@client/src/components/ui/card';
import { PERMISSION_SUBJECT_META } from '@shared/permissions';
import type {
  MemberRoleInfo,
  PermissionPointInfo,
  RoleInfo,
} from '@shared/api.interface';
import MemberAssignDialog from './MemberAssignDialog';
import RoleFormDialog from './RoleFormDialog';

const ACTION_LABELS: Record<string, string> = {
  read: '查看',
  operate: '操作',
  manage: '管理',
};

interface PermissionGroup {
  subject: string;
  label: string;
  actions: string[];
}

function groupPermissions(permissionKeys: string[]): PermissionGroup[] {
  const groups: PermissionGroup[] = [];
  for (const meta of PERMISSION_SUBJECT_META) {
    const actions: string[] = [];
    for (const key of permissionKeys) {
      const [action, subject] = key.split(':');
      if (subject === meta.subject && action) {
        actions.push(ACTION_LABELS[action] ?? action);
      }
    }
    if (actions.length > 0) {
      groups.push({
        subject: meta.subject,
        label: meta.label,
        actions,
      });
    }
  }
  return groups;
}

interface RoleFormState {
  open: boolean;
  mode: 'create' | 'edit';
  role: RoleInfo | null;
}

const PermissionsPage: React.FC = () => {
  const [roles, setRoles] = useState<RoleInfo[]>([]);
  const [members, setMembers] = useState<MemberRoleInfo[]>([]);
  const [points, setPoints] = useState<PermissionPointInfo[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [roleForm, setRoleForm] = useState<RoleFormState>({
    open: false,
    mode: 'create',
    role: null,
  });
  const [deleteTarget, setDeleteTarget] = useState<RoleInfo | null>(null);
  const [assignTarget, setAssignTarget] = useState<MemberRoleInfo | null>(
    null,
  );

  const loadData = useCallback(async () => {
    setLoading(true);
    setErrorMessage('');
    try {
      const [roleRes, memberRes, pointRes] = await Promise.all([
        listRoles(),
        listMembers(),
        getPermissionPoints(),
      ]);
      setRoles(roleRes.items);
      setMembers(memberRes.items);
      setPoints(pointRes);
    } catch (error) {
      logger.error(String(error));
      setErrorMessage('加载权限管理数据失败，请稍后重试');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData();
  }, [loadData]);

  const handleRoleSubmit = async (
    name: string,
    permissionKeys: string[],
  ): Promise<void> => {
    setSubmitting(true);
    try {
      if (roleForm.mode === 'create') {
        await createRole({ name, permissionKeys });
        toast.success('角色创建成功');
      } else if (roleForm.role) {
        await updateRole(roleForm.role.id, { name, permissionKeys });
        toast.success('角色更新成功');
      }
      setRoleForm({ open: false, mode: 'create', role: null });
      await loadData();
    } catch (error) {
      logger.error(String(error));
      toast.error('保存角色失败，请稍后重试');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteConfirm = async (): Promise<void> => {
    if (!deleteTarget) {
      return;
    }
    const target: RoleInfo = deleteTarget;
    setDeleteTarget(null);
    try {
      await deleteRole(target.id);
      toast.success('角色删除成功');
      await loadData();
    } catch (error) {
      logger.error(String(error));
      const message: string =
        error instanceof Error && error.message
          ? error.message
          : '删除角色失败，请稍后重试';
      toast.error(message);
    }
  };

  const handleAssignSubmit = async (
    userId: string,
    roleIds: string[],
  ): Promise<void> => {
    if (!userId) {
      toast.error('请先选择成员');
      return;
    }
    setSubmitting(true);
    try {
      await assignMemberRoles(userId, { roleIds });
      toast.success('角色分配成功');
      setAssignTarget(null);
      await loadData();
    } catch (error) {
      logger.error(String(error));
      toast.error('分配角色失败，请稍后重试');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-[400px] items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
        <span className="ml-2 text-sm text-muted-foreground">加载中...</span>
      </div>
    );
  }

  if (errorMessage) {
    return (
      <div className="flex min-h-[400px] flex-col items-center justify-center gap-3">
        <p className="text-sm text-muted-foreground">{errorMessage}</p>
        <Button variant="outline" onClick={() => void loadData()}>
          重新加载
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1400px] space-y-8 p-6">
      <div className="space-y-1">
        <h1 className="text-xl font-semibold text-foreground">权限管理</h1>
        <p className="text-sm text-muted-foreground">
          管理平台角色与权限点位，为成员分配角色。角色与权限变更保存即生效。
        </p>
      </div>

      <section className="space-y-4" data-ai-section-type="card-list">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-primary" />
            <h2 className="text-base font-medium text-foreground">
              角色管理
            </h2>
          </div>
          <Button
            data-ai-section-type="button"
            onClick={() =>
              setRoleForm({ open: true, mode: 'create', role: null })
            }
          >
            <Plus className="mr-1 h-4 w-4" />
            新建角色
          </Button>
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {roles.map((role: RoleInfo) => {
            const groups: PermissionGroup[] = groupPermissions(
              role.permissions,
            );
            return (
              <Card key={role.id} className="rounded-lg shadow-sm">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-base font-semibold text-foreground">
                        {role.name}
                      </span>
                      {role.isBuiltin ? (
                        <Badge variant="default">内置</Badge>
                      ) : null}
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label={`编辑角色 ${role.name}`}
                        onClick={() =>
                          setRoleForm({ open: true, mode: 'edit', role })
                        }
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label={`删除角色 ${role.name}`}
                        onClick={() => setDeleteTarget(role)}
                      >
                        <Trash2 className="h-4 w-4 text-red-600" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    <span className="font-mono font-bold text-foreground">
                      {role.memberCount}
                    </span>
                    名成员
                  </div>
                  {groups.length === 0 ? (
                    <p className="text-xs text-muted-foreground">
                      暂未配置权限点
                    </p>
                  ) : (
                    <div className="space-y-2">
                      {groups.map((group: PermissionGroup) => (
                        <div
                          key={group.subject}
                          className="flex flex-wrap items-center gap-1.5"
                        >
                          <span className="text-xs text-muted-foreground">
                            {group.label}
                          </span>
                          {group.actions.map((action: string) => (
                            <Badge
                              key={`${group.subject}-${action}`}
                              variant="secondary"
                              className="rounded-full"
                            >
                              {action}
                            </Badge>
                          ))}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-primary" />
          <h2 className="text-base font-medium text-foreground">成员授权</h2>
        </div>
        <Card className="rounded-lg shadow-sm">
          <CardContent className="pt-6">
            {members.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-10">
                <Building2 className="h-8 w-8 text-muted-foreground/50" />
                <p className="text-sm text-muted-foreground">
                  暂无已授权成员，点击「分配角色」为成员授权
                </p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {members.map((member: MemberRoleInfo) => (
                  <div
                    key={member.userId}
                    className="flex h-12 flex-wrap items-center justify-between gap-2 px-1"
                  >
                    <div className="flex items-center gap-3">
                      <UserDisplay value={[member.userId]} size="small" />
                      {member.departmentName ? (
                        <span className="text-xs text-muted-foreground">
                          {member.departmentName}
                        </span>
                      ) : null}
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex flex-wrap items-center gap-1.5">
                        {member.roleNames.length === 0 ? (
                          <span className="text-xs text-muted-foreground">
                            未分配角色
                          </span>
                        ) : (
                          member.roleNames.map(
                            (roleName: string, index: number) => (
                              <Badge
                                key={`${member.userId}-${index}`}
                                variant="secondary"
                                className="rounded-full"
                              >
                                {roleName}
                              </Badge>
                            ),
                          )
                        )}
                      </div>
                      <Button
                        variant="outline"
                        data-ai-section-type="button"
                        onClick={() => setAssignTarget(member)}
                      >
                        分配角色
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <div className="mt-4 border-t border-border pt-4">
              <Button
                variant="outline"
                data-ai-section-type="button"
                onClick={() => setAssignTarget({
                  userId: '',
                  name: '',
                  avatar: '',
                  departmentName: null,
                  roleIds: [],
                  roleNames: [],
                })}
              >
                <Plus className="mr-1 h-4 w-4" />
                为其他成员分配角色
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>

      <RoleFormDialog
        open={roleForm.open}
        onOpenChange={(open: boolean) =>
          setRoleForm((prev: RoleFormState) => ({ ...prev, open }))
        }
        mode={roleForm.mode}
        initialName={roleForm.role?.name ?? ''}
        initialPermissionKeys={roleForm.role?.permissions ?? []}
        permissionPoints={points}
        submitting={submitting}
        onSubmit={(name: string, permissionKeys: string[]) =>
          void handleRoleSubmit(name, permissionKeys)
        }
      />

      <MemberAssignDialog
        open={assignTarget !== null}
        onOpenChange={(open: boolean) => {
          if (!open) {
            setAssignTarget(null);
          }
        }}
        member={assignTarget}
        roles={roles}
        submitting={submitting}
        onSubmit={(userId: string, roleIds: string[]) =>
          void handleAssignSubmit(userId, roleIds)
        }
      />

      <AlertDialog
        open={deleteTarget !== null}
        onOpenChange={(open: boolean) => {
          if (!open) {
            setDeleteTarget(null);
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除角色</AlertDialogTitle>
            <AlertDialogDescription>
              确定要删除角色「{deleteTarget?.name ?? ''}」吗？删除后该角色的权限配置将同时移除，且不可恢复。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDeleteConfirm()}>
              删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default PermissionsPage;
