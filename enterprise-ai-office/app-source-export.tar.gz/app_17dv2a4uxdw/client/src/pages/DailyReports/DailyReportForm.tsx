import React, { useEffect, useState } from 'react';
import dayjs from 'dayjs';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Calendar as CalendarIcon, CheckCircle2, LoaderCircle } from 'lucide-react';
import { Calendar } from '@client/src/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { Button } from '@client/src/components/ui/button';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import { cn } from '@client/src/lib/utils';
import type {
  DailyReportContentStructure,
  MyDailyReportItem,
  WorkDraftCategory,
} from '@shared/api.interface';
import DailyReportAutoSection from './DailyReportAutoSection';
import {
  getReportDateRangeText,
  isReportDateDisabled,
} from './daily-report-utils';

const dailyReportSchema = z.object({
  todayContent: z.string().trim().min(1, '今日工作内容不能为空'),
  tomorrowPlan: z.string(),
  risk: z.string(),
});

type DailyReportFormData = z.infer<typeof dailyReportSchema>;

export interface DailyReportFormValues {
  todayContent: string;
  tomorrowPlan: string;
  risk: string;
  contentStructure: DailyReportContentStructure | null;
}

interface DailyReportFormProps {
  date: string;
  existing: MyDailyReportItem | null;
  existingLoading: boolean;
  submitting: boolean;
  savingDraft: boolean;
  onDateChange: (date: string) => void;
  onSubmit: (values: DailyReportFormValues) => Promise<void>;
  onSaveDraft: (values: DailyReportFormValues) => Promise<void>;
}

const DailyReportForm: React.FC<DailyReportFormProps> = ({
  date,
  existing,
  existingLoading,
  submitting,
  savingDraft,
  onDateChange,
  onSubmit,
  onSaveDraft,
}) => {
  const [dateOpen, setDateOpen] = useState<boolean>(false);
  const [mode, setMode] = useState<'auto' | 'manual'>('auto');
  const [preview, setPreview] = useState<WorkDraftCategory[]>([]);

  const submitted: boolean = existing?.status === 'submitted';

  const form = useForm<DailyReportFormData>({
    resolver: zodResolver(dailyReportSchema),
    defaultValues: {
      todayContent: existing?.todayContent ?? '',
      tomorrowPlan: existing?.tomorrowPlan ?? '',
      risk: existing?.risk ?? '',
    },
  });

  useEffect(() => {
    form.reset({
      todayContent: existing?.todayContent ?? '',
      tomorrowPlan: existing?.tomorrowPlan ?? '',
      risk: existing?.risk ?? '',
    });
    setPreview(existing?.contentStructure?.categories ?? []);
    setMode(
      existing && existing.contentStructure?.categories.length
        ? 'auto'
        : 'manual',
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [existing, date]);

  const handleDateSelect = (selected: Date | undefined): void => {
    if (!selected) {
      return;
    }
    onDateChange(dayjs(selected).format('YYYY-MM-DD'));
    setDateOpen(false);
  };

  const collectValues = (data: DailyReportFormData): DailyReportFormValues => ({
    todayContent: data.todayContent.trim(),
    tomorrowPlan: data.tomorrowPlan.trim(),
    risk: data.risk.trim(),
    contentStructure:
      mode === 'auto' && preview.length > 0 ? { categories: preview } : null,
  });

  const handleSubmit = async (data: DailyReportFormData): Promise<void> => {
    await onSubmit(collectValues(data));
  };

  const handleSaveDraft = async (): Promise<void> => {
    const valid: boolean = await form.trigger('todayContent');
    if (!valid) {
      return;
    }
    await onSaveDraft(collectValues(form.getValues()));
  };

  const busy: boolean = submitting || savingDraft;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <div className="flex flex-wrap items-end gap-3">
          <div className="space-y-2">
            <span className="text-sm font-medium">
              日报日期 <span className="text-destructive">*</span>
            </span>
            <Popover open={dateOpen} onOpenChange={setDateOpen}>
              <PopoverTrigger asChild>
                <Button
                  type="button"
                  variant="outline"
                  className="justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 size-4" />
                  {date
                    ? dayjs(date).format('YYYY-MM-DD')
                    : getReportDateRangeText()}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={dayjs(date).toDate()}
                  onSelect={handleDateSelect}
                  disabled={isReportDateDisabled}
                />
              </PopoverContent>
            </Popover>
            <p className="text-xs text-muted-foreground">
              {getReportDateRangeText()}
            </p>
          </div>
          <div className="space-y-2">
            <span className="text-sm font-medium">填写方式</span>
            <div className="flex rounded-lg border p-0.5">
              {(
                [
                  { key: 'auto', label: '自动生成' },
                  { key: 'manual', label: '手动填写' },
                ] as Array<{ key: 'auto' | 'manual'; label: string }>
              ).map((option) => (
                <button
                  key={option.key}
                  type="button"
                  disabled={submitted}
                  onClick={() => setMode(option.key)}
                  className={cn(
                    'rounded-md px-3 py-1.5 text-sm transition-colors',
                    mode === option.key
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {submitted && (
          <div className="flex items-center gap-2 rounded-lg bg-[hsl(152_55%_96%)] p-3 text-sm text-[hsl(152_60%_42%)]">
            <CheckCircle2 className="size-4" />
            该日日报已提交，不可再次修改
          </div>
        )}

        {mode === 'auto' && (
          <DailyReportAutoSection
            date={date}
            disabled={submitted}
            loading={existingLoading}
            categories={preview}
            onCategoriesChange={setPreview}
            onGeneratedText={(text: string): void =>
              form.setValue('todayContent', text)
            }
          />
        )}

        <FormField
          control={form.control}
          name="todayContent"
          render={({ field }) => (
            <FormItem>
              <FormLabel>
                今日工作内容 <span className="text-destructive">*</span>
              </FormLabel>
              <FormControl>
                <Textarea
                  placeholder={
                    mode === 'auto'
                      ? '点击"自动生成草稿"汇总当日工作记录，可在此基础上编辑补充'
                      : '请记录今日完成的工作内容'
                  }
                  rows={6}
                  disabled={submitted}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="tomorrowPlan"
          render={({ field }) => (
            <FormItem>
              <FormLabel>明日计划</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="请记录明日工作计划（选填）"
                  rows={3}
                  disabled={submitted}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="risk"
          render={({ field }) => (
            <FormItem>
              <FormLabel>问题与风险</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="请记录遇到的问题与风险（选填）"
                  rows={3}
                  disabled={submitted}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {!submitted && (
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={() => void handleSaveDraft()}
              disabled={busy || existingLoading}
            >
              {savingDraft && <LoaderCircle className="size-4 animate-spin" />}
              保存草稿
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={busy || existingLoading}
            >
              {submitting && <LoaderCircle className="size-4 animate-spin" />}
              提交日报
            </Button>
          </div>
        )}
      </form>
    </Form>
  );
};

export default DailyReportForm;
