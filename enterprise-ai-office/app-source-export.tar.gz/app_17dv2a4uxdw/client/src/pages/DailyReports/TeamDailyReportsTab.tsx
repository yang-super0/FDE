import React, { useCallback, useEffect, useState } from 'react';
import dayjs from 'dayjs';
import {
  Calendar as CalendarIcon,
  LoaderCircle,
  Users,
} from 'lucide-react';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Calendar } from '@client/src/components/ui/calendar';
import {
  Card,
  CardContent,
  CardHeader,
} from '@client/src/components/ui/card';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { UserDisplay } from '@client/src/components/business-ui/user-display';
import { getTeamDailyReports } from '@client/src/api/daily-reports';
import type {
  TeamDailyReportItem,
  TeamDailyReportParams,
} from '@shared/api.interface';
import { getErrorMessage } from './daily-report-utils';

const ALL_MEMBERS: string = 'all';

interface ReportSectionProps {
  title: string;
  content: string | null;
}

const ReportSection: React.FC<ReportSectionProps> = ({ title, content }) => (
  <div className="rounded-lg bg-muted/50 p-3">
    <p className="text-xs font-medium text-muted-foreground">{title}</p>
    <p className="mt-1 whitespace-pre-wrap text-sm text-foreground">
      {content && content.trim().length > 0 ? content : '—'}
    </p>
  </div>
);

const TeamDailyReportsTab: React.FC = () => {
  const todayStr: string = dayjs().format('YYYY-MM-DD');
  const [date, setDate] = useState<string>(todayStr);
  const [memberId, setMemberId] = useState<string>(ALL_MEMBERS);
  const [items, setItems] = useState<TeamDailyReportItem[]>([]);
  const [memberOptions, setMemberOptions] = useState<TeamDailyReportItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [dateOpen, setDateOpen] = useState<boolean>(false);

  const loadTeam = useCallback(
    async (targetDate: string, targetMember: string): Promise<void> => {
      setLoading(true);
      setError(null);
      try {
        const params: TeamDailyReportParams =
          targetMember === ALL_MEMBERS
            ? { date: targetDate }
            : { date: targetDate, memberId: targetMember };
        const response = await getTeamDailyReports(params);
        setItems(response.items);
        if (targetMember === ALL_MEMBERS) {
          setMemberOptions(response.items);
        }
      } catch (loadError: unknown) {
        setError(getErrorMessage(loadError));
        setItems([]);
      } finally {
        setLoading(false);
      }
    },
    [],
  );

  useEffect(() => {
    void loadTeam(date, memberId);
  }, [date, memberId, loadTeam]);

  const handleDateSelect = (selected: Date | undefined): void => {
    if (!selected) {
      return;
    }
    setDate(dayjs(selected).format('YYYY-MM-DD'));
    setMemberId(ALL_MEMBERS);
    setDateOpen(false);
  };

  const memberFilterOptions: TeamDailyReportItem[] =
    memberId === ALL_MEMBERS
      ? memberOptions
      : memberOptions.length > 0
        ? memberOptions
        : items;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Popover open={dateOpen} onOpenChange={setDateOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-44 justify-start text-left font-normal">
              <CalendarIcon className="mr-2 size-4" />
              {dayjs(date).format('YYYY-MM-DD')}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={dayjs(date).toDate()}
              onSelect={handleDateSelect}
            />
          </PopoverContent>
        </Popover>
        <Select value={memberId} onValueChange={setMemberId}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="选择成员" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_MEMBERS}>全部成员</SelectItem>
            {memberFilterOptions.map((option: TeamDailyReportItem) => (
              <SelectItem key={option.userId} value={option.userId}>
                {option.userName || option.userId}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground">
          <LoaderCircle className="size-4 animate-spin" />
          加载中...
        </div>
      ) : error ? (
        <div className="space-y-3 py-16 text-center">
          <p className="text-sm text-[hsl(0_65%_52%)]">{error}</p>
          <Button
            type="button"
            variant="outline"
            onClick={() => void loadTeam(date, memberId)}
          >
            重试
          </Button>
        </div>
      ) : items.length === 0 ? (
        <div className="flex flex-col items-center gap-2 py-16 text-center">
          <Users className="size-8 text-muted-foreground/50" />
          <p className="text-sm text-muted-foreground">
            暂无团队成员日报数据，成员提交日报后将在此展示
          </p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {items.map((item: TeamDailyReportItem) => (
            <Card
              key={item.userId}
              className={!item.submitted ? 'border-[hsl(0_65%_52%_/_35%)]' : ''}
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                <UserDisplay value={[item.userId]} size="small" />
                <div className="flex items-center gap-2">
                  {item.submitted ? (
                    <>
                      <Badge className="bg-[hsl(152_55%_96%)] text-[hsl(152_60%_42%)]">
                        已提交
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {item.submittedAt
                          ? dayjs(item.submittedAt).format('HH:mm')
                          : ''}
                      </span>
                    </>
                  ) : (
                    <Badge className="bg-[hsl(0_60%_96%)] text-[hsl(0_65%_52%)]">
                      未提交
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-2">
                {item.submitted ? (
                  <>
                    <ReportSection title="今日工作" content={item.todayContent} />
                    <ReportSection title="明日计划" content={item.tomorrowPlan} />
                    <ReportSection title="问题与风险" content={item.risk} />
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    该成员当日尚未提交日报
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default TeamDailyReportsTab;
