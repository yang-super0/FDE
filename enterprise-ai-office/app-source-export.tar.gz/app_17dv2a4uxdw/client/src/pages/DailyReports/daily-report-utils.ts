import { isAxiosError } from 'axios';
import dayjs from 'dayjs';
import type { WorkDraftCategory } from '@shared/api.interface';

export const REPORT_DATE_RANGE_DAYS_BACK = 7;
export const REPORT_DATE_RANGE_DAYS_FORWARD = 3;

export function getReportDateRange(): { min: dayjs.Dayjs; max: dayjs.Dayjs } {
  const today: dayjs.Dayjs = dayjs().startOf('day');
  return {
    min: today.subtract(REPORT_DATE_RANGE_DAYS_BACK, 'day'),
    max: today.add(REPORT_DATE_RANGE_DAYS_FORWARD, 'day'),
  };
}

export function isReportDateDisabled(day: Date): boolean {
  const { min, max } = getReportDateRange();
  const target: dayjs.Dayjs = dayjs(day).startOf('day');
  return target.isBefore(min) || target.isAfter(max);
}

export function getReportDateRangeText(): string {
  return `可选最近${REPORT_DATE_RANGE_DAYS_BACK}天至未来${REPORT_DATE_RANGE_DAYS_FORWARD}天`;
}

export function getErrorMessage(error: unknown): string {
  if (isAxiosError(error)) {
    const data: unknown = error.response?.data;
    if (data && typeof data === 'object') {
      const payload = data as {
        message?: unknown;
        error?: { message?: unknown };
      };
      const candidate: unknown =
        payload.message ?? payload.error?.message;
      if (typeof candidate === 'string' && candidate.length > 0) {
        return candidate;
      }
      if (Array.isArray(candidate) && candidate.length > 0) {
        return candidate.join('；');
      }
    }
    return error.message || '请求失败，请稍后重试';
  }
  if (error instanceof Error && error.message) {
    return error.message;
  }
  return '请求失败，请稍后重试';
}

export function buildDraftText(categories: WorkDraftCategory[]): string {
  return categories
    .map((category: WorkDraftCategory) => {
      const lines: string[] = category.items.map(
        (item) =>
          `- ${item.time} ${item.relatedObject ? `${item.relatedObject}：` : ''}${item.summary}`,
      );
      return `【${category.type}】\n${lines.join('\n')}`;
    })
    .join('\n\n');
}
