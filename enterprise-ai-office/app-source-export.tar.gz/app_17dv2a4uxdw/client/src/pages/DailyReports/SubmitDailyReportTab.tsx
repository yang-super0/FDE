import React, { useCallback, useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Card, CardContent } from '@client/src/components/ui/card';
import {
  getMyDailyReportByDate,
  saveDailyReportDraft,
  submitDailyReport,
} from '@client/src/api/daily-reports';
import type {
  MyDailyReportItem,
  SaveDailyReportDraftRequest,
  SubmitDailyReportRequest,
} from '@shared/api.interface';
import DailyReportForm, {
  type DailyReportFormValues,
} from './DailyReportForm';
import { getErrorMessage } from './daily-report-utils';

interface SubmitDailyReportTabProps {
  date: string;
  onDateChange: (date: string) => void;
}

const SubmitDailyReportTab: React.FC<SubmitDailyReportTabProps> = ({
  date,
  onDateChange,
}) => {
  const [existing, setExisting] = useState<MyDailyReportItem | null>(null);
  const [existingLoading, setExistingLoading] = useState<boolean>(true);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [savingDraft, setSavingDraft] = useState<boolean>(false);

  const loadExisting = useCallback(async (): Promise<void> => {
    setExistingLoading(true);
    try {
      const report: MyDailyReportItem | null =
        await getMyDailyReportByDate(date);
      setExisting(report);
    } catch (loadError: unknown) {
      toast.error(getErrorMessage(loadError));
    } finally {
      setExistingLoading(false);
    }
  }, [date]);

  useEffect(() => {
    void loadExisting();
  }, [loadExisting]);

  const handleSubmit = async (values: DailyReportFormValues): Promise<void> => {
    setSubmitting(true);
    try {
      const payload: SubmitDailyReportRequest = {
        reportDate: date,
        todayContent: values.todayContent,
        tomorrowPlan: values.tomorrowPlan,
        risk: values.risk,
        contentStructure: values.contentStructure,
      };
      await submitDailyReport(payload);
      toast.success('日报提交成功');
      await loadExisting();
    } catch (submitError: unknown) {
      toast.error(getErrorMessage(submitError));
    } finally {
      setSubmitting(false);
    }
  };

  const handleSaveDraft = async (
    values: DailyReportFormValues,
  ): Promise<void> => {
    setSavingDraft(true);
    try {
      const payload: SaveDailyReportDraftRequest = {
        reportDate: date,
        todayContent: values.todayContent,
        tomorrowPlan: values.tomorrowPlan,
        risk: values.risk,
        contentStructure: values.contentStructure,
      };
      await saveDailyReportDraft(payload);
      toast.success('草稿已保存');
      await loadExisting();
    } catch (draftError: unknown) {
      toast.error(getErrorMessage(draftError));
    } finally {
      setSavingDraft(false);
    }
  };

  return (
    <Card className="mx-auto max-w-3xl">
      <CardContent className="pt-6">
        <DailyReportForm
          date={date}
          existing={existing}
          existingLoading={existingLoading}
          submitting={submitting}
          savingDraft={savingDraft}
          onDateChange={onDateChange}
          onSubmit={handleSubmit}
          onSaveDraft={handleSaveDraft}
        />
      </CardContent>
    </Card>
  );
};

export default SubmitDailyReportTab;
