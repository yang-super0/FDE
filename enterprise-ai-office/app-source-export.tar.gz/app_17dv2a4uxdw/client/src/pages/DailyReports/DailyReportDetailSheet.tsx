import React from 'react';
import dayjs from 'dayjs';
import { Badge } from '@client/src/components/ui/badge';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@client/src/components/ui/sheet';
import type {
  DailyReportStatus,
  MyDailyReportItem,
} from '@shared/api.interface';
import DailyReportDraftPreview from './DailyReportDraftPreview';

interface DailyReportDetailSheetProps {
  report: MyDailyReportItem | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const STATUS_META: Record<
  DailyReportStatus,
  { label: string; className: string }
> = {
  submitted: {
    label: '已提交',
    className: 'bg-[hsl(152_55%_96%)] text-[hsl(152_60%_42%)]',
  },
  draft: {
    label: '草稿',
    className: 'bg-[hsl(216_12%_94%)] text-[hsl(216_15%_45%)]',
  },
};

const DailyReportDetailSheet: React.FC<DailyReportDetailSheetProps> = ({
  report,
  open,
  onOpenChange,
}) => {
  if (!report) {
    return null;
  }
  const meta = STATUS_META[report.status];
  const categories = report.contentStructure?.categories ?? [];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-xl">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <span className="font-mono">{report.reportDate} 日报</span>
            <Badge className={meta.className}>{meta.label}</Badge>
          </SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-5">
          {categories.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium">工作内容汇总（按类别）</h4>
              <DailyReportDraftPreview categories={categories} />
            </div>
          )}

          <div className="space-y-2">
            <h4 className="text-sm font-medium">今日工作内容</h4>
            <p className="whitespace-pre-wrap rounded-lg border p-3 text-sm leading-relaxed">
              {report.todayContent}
            </p>
          </div>

          {report.tomorrowPlan && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium">明日计划</h4>
              <p className="whitespace-pre-wrap rounded-lg border p-3 text-sm leading-relaxed">
                {report.tomorrowPlan}
              </p>
            </div>
          )}

          {report.risk && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium">问题与风险</h4>
              <p className="whitespace-pre-wrap rounded-lg border p-3 text-sm leading-relaxed">
                {report.risk}
              </p>
            </div>
          )}

          <p className="text-xs text-muted-foreground">
            创建时间：{dayjs(report.createdAt).format('YYYY-MM-DD HH:mm')}
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default DailyReportDetailSheet;
