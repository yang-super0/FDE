import React, { useState } from 'react';
import { toast } from 'sonner';
import { LoaderCircle, Sparkles } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import { generateDailyReportDraft } from '@client/src/api/daily-reports';
import type { WorkDraftCategory } from '@shared/api.interface';
import DailyReportDraftPreview from './DailyReportDraftPreview';
import { buildDraftText, getErrorMessage } from './daily-report-utils';

interface DailyReportAutoSectionProps {
  date: string;
  disabled: boolean;
  loading: boolean;
  categories: WorkDraftCategory[];
  onCategoriesChange: (categories: WorkDraftCategory[]) => void;
  onGeneratedText: (text: string) => void;
}

const DailyReportAutoSection: React.FC<DailyReportAutoSectionProps> = ({
  date,
  disabled,
  loading,
  categories,
  onCategoriesChange,
  onGeneratedText,
}) => {
  const [generating, setGenerating] = useState<boolean>(false);

  const handleGenerate = async (): Promise<void> => {
    setGenerating(true);
    try {
      const response = await generateDailyReportDraft({ reportDate: date });
      onCategoriesChange(response.categories);
      if (response.categories.length > 0) {
        onGeneratedText(buildDraftText(response.categories));
        toast.success('已根据当日工作记录生成草稿，可编辑后提交');
      } else {
        toast.info('当日暂无可汇总的工作记录，可切换手动填写');
      }
    } catch (generateError: unknown) {
      toast.error(getErrorMessage(generateError));
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-2">
        <span className="text-sm font-medium">工作记录汇总预览</span>
        {!disabled && (
          <Button
            type="button"
            variant="secondary"
            size="sm"
            onClick={() => void handleGenerate()}
            disabled={generating || loading}
          >
            {generating ? (
              <LoaderCircle className="size-4 animate-spin" />
            ) : (
              <Sparkles className="size-4" />
            )}
            自动生成草稿
          </Button>
        )}
      </div>
      {loading || generating ? (
        <div className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">
          加载中...
        </div>
      ) : (
        <DailyReportDraftPreview categories={categories} />
      )}
    </div>
  );
};

export default DailyReportAutoSection;
