import React, { useCallback, useState } from 'react';
import dayjs from 'dayjs';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@client/src/components/ui/tabs';
import SubmitDailyReportTab from './SubmitDailyReportTab';
import MyDailyReportsTab from './MyDailyReportsTab';
import TeamDailyReportsTab from './TeamDailyReportsTab';

const DailyReportsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<string>('submit');
  const [selectedDate, setSelectedDate] = useState<string>(
    dayjs().format('YYYY-MM-DD'),
  );

  const handleEditDraft = useCallback((date: string): void => {
    setSelectedDate(date);
    setActiveTab('submit');
  }, []);

  return (
    <div className="mx-auto max-w-[1400px] space-y-6 p-6">
      <div>
        <h1 className="text-xl font-semibold text-foreground">员工日报</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          基于当日工作记录自动生成日报草稿，确认后提交
        </p>
      </div>
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="submit">提交日报</TabsTrigger>
          <TabsTrigger value="mine">我的日报</TabsTrigger>
          <TabsTrigger value="team">团队日报</TabsTrigger>
        </TabsList>
        <TabsContent value="submit" className="mt-4">
          <SubmitDailyReportTab
            date={selectedDate}
            onDateChange={setSelectedDate}
          />
        </TabsContent>
        <TabsContent value="mine" className="mt-4">
          <MyDailyReportsTab onEditDraft={handleEditDraft} />
        </TabsContent>
        <TabsContent value="team" className="mt-4">
          <TeamDailyReportsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default DailyReportsPage;
