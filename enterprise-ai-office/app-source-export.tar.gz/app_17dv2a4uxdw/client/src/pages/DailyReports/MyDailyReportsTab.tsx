import React, { useCallback, useEffect, useState } from 'react';
import dayjs from 'dayjs';
import { ClipboardList, Pencil, RefreshCw } from 'lucide-react';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@client/src/components/ui/card';
import { cn } from '@client/src/lib/utils';
import { getMyDailyReports } from '@client/src/api/daily-reports';
import type {
  DailyReportStatus,
  MyDailyReportItem,
} from '@shared/api.interface';
import DailyReportDetailSheet from './DailyReportDetailSheet';
import { getErrorMessage } from './daily-report-utils';

interface MyDailyReportsTabProps {
  onEditDraft: (date: string) => void;
}

const STATUS_META: Record<
  DailyReportStatus,
  { label: string; className: string }
> = {
  submitted: {
    label: '已提交',
    className: 'bg-[hsl(152_55%_96%)] text-[hsl(152_60%_42%)]',
  },
  draft: {
    label: '草稿',
    className: 'bg-[hsl(216_12%_94%)] text-[hsl(216_15%_45%)]',
  },
};

const MyDailyReportsTab: React.FC<MyDailyReportsTabProps> = ({
  onEditDraft,
}) => {
  const [reports, setReports] = useState<MyDailyReportItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [detailReport, setDetailReport] = useState<MyDailyReportItem | null>(
    null,
  );

  const loadReports = useCallback(async (): Promise<void> => {
    setLoading(true);
    setError(null);
    try {
      const response = await getMyDailyReports();
      setReports(response.items);
    } catch (loadError: unknown) {
      setError(getErrorMessage(loadError));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadReports();
  }, [loadReports]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-base">我的日报记录</CardTitle>
        <Button
          type="button"
          variant="ghost"
          size="icon"
          onClick={() => void loadReports()}
          disabled={loading}
        >
          <RefreshCw className={cn('size-4', loading && 'animate-spin')} />
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="py-10 text-center text-sm text-muted-foreground">
            加载中...
          </div>
        ) : error ? (
          <div className="space-y-3 py-10 text-center">
            <p className="text-sm text-[hsl(0_65%_52%)]">{error}</p>
            <Button
              type="button"
              variant="outline"
              onClick={() => void loadReports()}
            >
              重试
            </Button>
          </div>
        ) : reports.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-10 text-center">
            <ClipboardList className="size-8 text-muted-foreground/50" />
            <p className="text-sm text-muted-foreground">
              暂无日报记录，去"提交日报"标签页创建第一篇日报吧
            </p>
          </div>
        ) : (
          <ul className="space-y-2">
            {reports.map((report: MyDailyReportItem) => {
              const meta = STATUS_META[report.status];
              return (
                <li
                  key={report.id}
                  className="rounded-lg border border-border p-3 transition-colors hover:bg-accent/60"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-medium">
                        {report.reportDate}
                      </span>
                      <Badge className={meta.className}>{meta.label}</Badge>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="mr-2 text-xs text-muted-foreground">
                        {dayjs(report.createdAt).format('MM-DD HH:mm')} 创建
                      </span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => setDetailReport(report)}
                      >
                        查看
                      </Button>
                      {report.status === 'draft' && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => onEditDraft(report.reportDate)}
                        >
                          <Pencil className="size-3.5" />
                          编辑
                        </Button>
                      )}
                    </div>
                  </div>
                  <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                    {report.todayContent}
                  </p>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
      <DailyReportDetailSheet
        report={detailReport}
        open={detailReport !== null}
        onOpenChange={(open: boolean): void => {
          if (!open) {
            setDetailReport(null);
          }
        }}
      />
    </Card>
  );
};

export default MyDailyReportsTab;
