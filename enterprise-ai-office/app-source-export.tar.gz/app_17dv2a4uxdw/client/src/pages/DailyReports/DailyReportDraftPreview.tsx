import React from 'react';
import { Badge } from '@client/src/components/ui/badge';
import type { WorkDraftCategory } from '@shared/api.interface';

interface DailyReportDraftPreviewProps {
  categories: WorkDraftCategory[];
}

const DailyReportDraftPreview: React.FC<DailyReportDraftPreviewProps> = ({
  categories,
}) => {
  if (categories.length === 0) {
    return (
      <div className="rounded-lg border border-dashed p-4 text-center text-sm text-muted-foreground">
        当日暂无工作记录，可手动填写
      </div>
    );
  }
  return (
    <div className="space-y-3">
      {categories.map((category: WorkDraftCategory) => (
        <div
          key={category.type}
          className="rounded-lg border border-border bg-accent/40 p-3"
        >
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-primary">
              {category.type}
            </Badge>
            <span className="text-xs text-muted-foreground">
              {category.items.length} 条记录
            </span>
          </div>
          <ul className="mt-2 space-y-1.5">
            {category.items.map((item, index: number) => (
              <li
                key={`${category.type}-${index}`}
                className="flex flex-wrap items-baseline gap-x-2 text-sm"
              >
                <span className="font-mono text-xs text-muted-foreground">
                  {item.time}
                </span>
                {item.relatedObject && (
                  <span className="text-xs font-medium text-foreground">
                    {item.relatedObject}
                  </span>
                )}
                <span className="text-muted-foreground">{item.summary}</span>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default DailyReportDraftPreview;
