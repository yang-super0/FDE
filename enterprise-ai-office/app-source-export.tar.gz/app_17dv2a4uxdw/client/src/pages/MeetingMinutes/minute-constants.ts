import type {
  MeetingActionStatus,
  MeetingSource,
  MeetingType,
} from '@shared/api.interface';

export const MEETING_TYPES: MeetingType[] = [
  '客户拜访',
  '内部会议',
  '项目评审',
  '其他',
];

export const MEETING_TYPE_STYLES: Record<MeetingType, string> = {
  客户拜访:
    'border-transparent bg-[hsl(217_40%_95%)] text-[hsl(217_70%_40%)]',
  内部会议:
    'border-transparent bg-[hsl(216_12%_94%)] text-[hsl(216_15%_45%)]',
  项目评审:
    'border-transparent bg-[hsl(38_80%_96%)] text-[hsl(38_85%_38%)]',
  其他: 'border-transparent bg-[hsl(216_12%_94%)] text-[hsl(216_15%_50%)]',
};

export const MEETING_SOURCES: MeetingSource[] = [
  '手动录入',
  'AI生成',
  '飞书妙记导入',
];

export const MEETING_SOURCE_STYLES: Record<MeetingSource, string> = {
  手动录入:
    'border-transparent bg-[hsl(216_12%_94%)] text-[hsl(216_15%_45%)]',
  AI生成:
    'border-transparent bg-[hsl(217_40%_95%)] text-[hsl(217_70%_40%)]',
  飞书妙记导入:
    'border-transparent bg-[hsl(152_55%_96%)] text-[hsl(152_60%_32%)]',
};

export const ACTION_STATUSES: MeetingActionStatus[] = [
  '未开始',
  '进行中',
  '已完成',
];

export const ACTION_STATUS_STYLES: Record<MeetingActionStatus, string> = {
  未开始:
    'border-transparent bg-[hsl(216_12%_94%)] text-[hsl(216_15%_45%)]',
  进行中:
    'border-transparent bg-[hsl(38_80%_96%)] text-[hsl(38_85%_38%)]',
  已完成:
    'border-transparent bg-[hsl(152_55%_96%)] text-[hsl(152_60%_32%)]',
};
