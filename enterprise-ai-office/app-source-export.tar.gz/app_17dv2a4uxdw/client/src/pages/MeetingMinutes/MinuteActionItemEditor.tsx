import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { ProjectDateField } from '@client/src/pages/Projects/ProjectDateField';
import { ACTION_STATUSES } from '@client/src/pages/MeetingMinutes/minute-constants';
import type { MeetingActionItem } from '@shared/api.interface';

interface MinuteActionItemEditorProps {
  value: MeetingActionItem[];
  onChange: (items: MeetingActionItem[]) => void;
}

export const MinuteActionItemEditor: React.FC<MinuteActionItemEditorProps> = ({
  value,
  onChange,
}) => {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label>待办事项</Label>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          data-ai-section-type="button"
          onClick={() =>
            onChange([
              ...value,
              { content: '', assignee: '', dueDate: '', status: '未开始' },
            ])
          }
        >
          <Plus className="mr-1 size-4" />
          添加待办
        </Button>
      </div>
      {value.length === 0 ? (
        <p className="text-xs text-muted-foreground">暂无待办事项</p>
      ) : (
        <div className="space-y-3">
          {value.map((item, index) => (
            <div key={index} className="space-y-2 rounded-lg border p-3">
              <div className="flex items-center gap-2">
                <Input
                  value={item.content}
                  placeholder="待办内容 *"
                  onChange={(event) => {
                    const next = [...value];
                    next[index] = { ...item, content: event.target.value };
                    onChange(next);
                  }}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => onChange(value.filter((_it, idx) => idx !== index))}
                >
                  <Trash2 className="size-4 text-muted-foreground" />
                </Button>
              </div>
              <div className="grid grid-cols-1 gap-2 md:grid-cols-3">
                <Input
                  value={item.assignee}
                  placeholder="负责人"
                  onChange={(event) => {
                    const next = [...value];
                    next[index] = { ...item, assignee: event.target.value };
                    onChange(next);
                  }}
                />
                <ProjectDateField
                  value={item.dueDate}
                  onChange={(date) => {
                    const next = [...value];
                    next[index] = { ...item, dueDate: date };
                    onChange(next);
                  }}
                  placeholder="截止时间"
                />
                <Select
                  value={item.status}
                  onValueChange={(status) => {
                    const next = [...value];
                    next[index] = {
                      ...item,
                      status: status as MeetingActionItem['status'],
                    };
                    onChange(next);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="状态" />
                  </SelectTrigger>
                  <SelectContent>
                    {ACTION_STATUSES.map((status) => (
                      <SelectItem key={status} value={status}>
                        {status}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
