import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@client/src/components/ui/tabs';
import { listCustomers } from '@client/src/api/customers';
import {
  createMeetingMinute,
  getMeetingMinuteDetail,
  updateMeetingMinute,
} from '@client/src/api/meeting-minutes';
import { AiGeneratePanel } from '@client/src/pages/MeetingMinutes/AiGeneratePanel';
import type { AiExtractResult } from '@client/src/pages/MeetingMinutes/AiGeneratePanel';
import {
  EMPTY_FORM_STATE,
  MinuteFormFields,
} from '@client/src/pages/MeetingMinutes/MinuteFormFields';
import type {
  CustomerOption,
  MinuteFormState,
} from '@client/src/pages/MeetingMinutes/MinuteFormFields';
import type {
  CustomerListResponse,
  MeetingSource,
  SaveMeetingMinuteRequest,
} from '@shared/api.interface';

export const MinuteFormPage: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEdit: boolean = Boolean(id);
  const [form, setForm] = useState<MinuteFormState>(EMPTY_FORM_STATE);
  const [customers, setCustomers] = useState<CustomerOption[]>([]);
  const [loading, setLoading] = useState<boolean>(isEdit);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [aiApplied, setAiApplied] = useState<boolean>(false);
  const [customerMatchHint, setCustomerMatchHint] = useState<string>('');
  const [originalSource, setOriginalSource] = useState<MeetingSource>('手动录入');

  useEffect(() => {
    const fetchCustomers = async (): Promise<void> => {
      try {
        const res: CustomerListResponse = await listCustomers({
          page: 1,
          pageSize: 50,
        });
        setCustomers(
          res.items.map((item) => ({ id: item.id, name: item.name })),
        );
      } catch {
        toast.error('加载客户列表失败');
      }
    };
    void fetchCustomers();
  }, []);

  useEffect(() => {
    if (!id) return;
    const fetchDetail = async (): Promise<void> => {
      try {
        const detail = await getMeetingMinuteDetail(id);
        setForm({
          title: detail.title,
          meetingDate: detail.meetingDate,
          meetingType: detail.meetingType,
          customerId: detail.customerId ?? '',
          attendees: detail.attendees,
          keyTopics: detail.keyTopics,
          actionItems: detail.actionItems,
          decisions: detail.decisions,
        });
        setOriginalSource(detail.source);
      } catch {
        toast.error('加载纪要失败');
      } finally {
        setLoading(false);
      }
    };
    void fetchDetail();
  }, [id]);

  const matchCustomerByName = useCallback(
    (customerName: string): string => {
      const normalize = (name: string): string =>
        name.replace(/[\s【】\[\]（）()]/g, '');
      const target: string = normalize(customerName);
      if (target.length < 2) {
        return '';
      }
      const matched: CustomerOption | undefined = customers.find(
        (option: CustomerOption) => {
          const name: string = normalize(option.name);
          return name.includes(target) || target.includes(name);
        },
      );
      return matched?.id ?? '';
    },
    [customers],
  );

  const handleAiApply = (result: AiExtractResult): void => {
    const matchedCustomerId: string = result.customerName
      ? matchCustomerByName(result.customerName)
      : '';
    setForm((prev) => ({
      ...prev,
      title: result.title,
      meetingType: result.meetingType,
      customerId: matchedCustomerId || prev.customerId,
      attendees: result.attendees,
      keyTopics: result.keyTopics,
      actionItems: result.actionItems,
      decisions: result.decisions,
    }));
    setCustomerMatchHint(
      result.customerName && !matchedCustomerId
        ? `未匹配到客户「${result.customerName}」，可手动选择`
        : '',
    );
    setAiApplied(true);
  };

  const handleSubmit = async (): Promise<void> => {
    if (!form.title.trim()) {
      toast.error('请填写会议标题');
      return;
    }
    if (!form.meetingDate) {
      toast.error('请选择会议日期');
      return;
    }
    for (const attendee of form.attendees) {
      if (!attendee.name.trim() || !attendee.role.trim()) {
        toast.error('参会人姓名与角色不能为空');
        return;
      }
    }
    for (const item of form.actionItems) {
      if (!item.content.trim()) {
        toast.error('待办事项内容不能为空');
        return;
      }
    }
    const body: SaveMeetingMinuteRequest = {
      title: form.title.trim(),
      meetingDate: form.meetingDate,
      meetingType: form.meetingType,
      customerId: form.customerId || null,
      attendees: form.attendees,
      keyTopics: form.keyTopics.filter((topic) => topic.trim().length > 0),
      actionItems: form.actionItems,
      decisions: form.decisions,
      source: isEdit ? originalSource : aiApplied ? 'AI生成' : '手动录入',
    };
    setSubmitting(true);
    try {
      if (isEdit && id) {
        await updateMeetingMinute(id, body);
        toast.success('纪要已更新');
        navigate(`/meeting-minutes/${id}`);
      } else {
        const res = await createMeetingMinute(body);
        toast.success('纪要创建成功');
        navigate(`/meeting-minutes/${res.id}`);
      }
    } catch {
      toast.error(isEdit ? '更新失败，请重试' : '创建失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24 text-muted-foreground">
        <Loader2 className="mr-2 size-4 animate-spin" />
        加载中...
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4">
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate('/meeting-minutes')}
        >
          <ArrowLeft className="size-4" />
        </Button>
        <h1 className="text-xl font-semibold">
          {isEdit ? '编辑会议纪要' : '新建会议纪要'}
        </h1>
      </div>

      <Card>
        <CardContent className="p-6">
          {isEdit ? (
            <MinuteFormFields
              value={form}
              onChange={setForm}
              customers={customers}
            />
          ) : (
            <Tabs defaultValue="manual">
              <TabsList>
                <TabsTrigger value="manual">手动录入</TabsTrigger>
                <TabsTrigger value="ai">AI 生成</TabsTrigger>
              </TabsList>
              <TabsContent value="manual" className="mt-4">
                <MinuteFormFields
                  value={form}
                  onChange={setForm}
                  customers={customers}
                />
              </TabsContent>
              <TabsContent value="ai" className="mt-4 space-y-4">
                <AiGeneratePanel onApply={handleAiApply} />
                {aiApplied && (
                  <div className="rounded-lg bg-accent p-4">
                    <p className="mb-4 text-sm font-medium text-accent-foreground">
                      AI 生成结果（可编辑后保存）
                    </p>
                    <MinuteFormFields
                      value={form}
                      onChange={setForm}
                      customers={customers}
                      customerHint={customerMatchHint}
                      onCustomerHintDismiss={() => setCustomerMatchHint('')}
                    />
                  </div>
                )}
              </TabsContent>
            </Tabs>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => navigate('/meeting-minutes')}>
          取消
        </Button>
        <Button
          data-ai-section-type="button"
          disabled={submitting}
          onClick={() => {
            void handleSubmit();
          }}
        >
          {submitting ? '保存中...' : '保存'}
        </Button>
      </div>
    </div>
  );
};
