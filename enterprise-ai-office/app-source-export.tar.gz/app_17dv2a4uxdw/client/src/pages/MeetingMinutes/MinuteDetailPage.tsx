import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import dayjs from 'dayjs';
import { ArrowLeft, Loader2, Pencil, Trash2, Users } from 'lucide-react';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@client/src/components/ui/alert-dialog';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import {
  deleteMeetingMinute,
  getMeetingMinuteDetail,
} from '@client/src/api/meeting-minutes';
import {
  ACTION_STATUS_STYLES,
  MEETING_SOURCE_STYLES,
  MEETING_TYPE_STYLES,
} from '@client/src/pages/MeetingMinutes/minute-constants';
import type { MeetingMinuteDetail } from '@shared/api.interface';

export const MinuteDetailPage: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [detail, setDetail] = useState<MeetingMinuteDetail | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [deleting, setDeleting] = useState<boolean>(false);

  const fetchDetail = useCallback(async (): Promise<void> => {
    if (!id) return;
    setLoading(true);
    try {
      const res: MeetingMinuteDetail = await getMeetingMinuteDetail(id);
      setDetail(res);
    } catch {
      toast.error('加载纪要失败');
      navigate('/meeting-minutes');
    } finally {
      setLoading(false);
    }
  }, [id, navigate]);

  useEffect(() => {
    void fetchDetail();
  }, [fetchDetail]);

  const handleDelete = async (): Promise<void> => {
    if (!id) return;
    setDeleting(true);
    try {
      await deleteMeetingMinute(id);
      toast.success('纪要已删除');
      navigate('/meeting-minutes');
    } catch {
      toast.error('删除失败，请重试');
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24 text-muted-foreground">
        <Loader2 className="mr-2 size-4 animate-spin" />
        加载中...
      </div>
    );
  }

  if (!detail) {
    return (
      <div className="py-24 text-center text-muted-foreground">
        会议纪要不存在
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <div className="flex items-center gap-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate('/meeting-minutes')}
        >
          <ArrowLeft className="size-4" />
        </Button>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-xl font-semibold">{detail.title}</h1>
          <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
            <span>{detail.meetingDate}</span>
            <Badge
              variant="outline"
              className={MEETING_TYPE_STYLES[detail.meetingType] ?? ''}
            >
              {detail.meetingType}
            </Badge>
            <Badge
              variant="outline"
              className={MEETING_SOURCE_STYLES[detail.source] ?? ''}
            >
              {detail.source}
            </Badge>
            <span>创建人：{detail.createdBy}</span>
            <span>
              更新于 {dayjs(detail.updatedAt).format('YYYY-MM-DD HH:mm')}
            </span>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate(`/meeting-minutes/${detail.id}/edit`)}
          >
            <Pencil className="mr-1 size-3.5" />
            编辑
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Trash2 className="mr-1 size-3.5 text-destructive" />
                删除
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>确认删除该会议纪要？</AlertDialogTitle>
                <AlertDialogDescription>
                  删除后不可恢复，关联客户的跟进时间线中也将不再展示该纪要。
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>取消</AlertDialogCancel>
                <AlertDialogAction
                  disabled={deleting}
                  onClick={() => {
                    void handleDelete();
                  }}
                >
                  删除
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="text-sm text-muted-foreground">关联客户</div>
          {detail.customerId ? (
            <button
              type="button"
              className="mt-1 text-sm font-medium text-primary hover:underline"
              onClick={() => navigate(`/customers/${detail.customerId}`)}
            >
              {detail.customerName ?? '查看客户'}
            </button>
          ) : (
            <p className="mt-1 text-sm">未关联客户</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="mb-3 flex items-center gap-2 text-sm font-semibold">
            <Users className="size-4 text-primary" />
            参会人
          </div>
          {detail.attendees.length === 0 ? (
            <p className="text-sm text-muted-foreground">暂无参会人记录</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {detail.attendees.map((attendee, index) => (
                <Badge key={index} variant="secondary" className="px-3 py-1">
                  {attendee.name}
                  <span className="ml-1 text-muted-foreground">
                    {attendee.role}
                  </span>
                </Badge>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="mb-3 text-sm font-semibold">核心议题</div>
          {detail.keyTopics.length === 0 ? (
            <p className="text-sm text-muted-foreground">暂无核心议题记录</p>
          ) : (
            <ul className="list-disc space-y-1 pl-5 text-sm">
              {detail.keyTopics.map((topic, index) => (
                <li key={index}>{topic}</li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="mb-3 text-sm font-semibold">待办事项</div>
          {detail.actionItems.length === 0 ? (
            <p className="text-sm text-muted-foreground">暂无待办事项</p>
          ) : (
            <div className="space-y-2">
              {detail.actionItems.map((item, index) => (
                <div
                  key={index}
                  className="flex flex-wrap items-center gap-2 rounded-lg border p-3 text-sm"
                >
                  <span className="min-w-0 flex-1 break-words">
                    {item.content}
                  </span>
                  {item.assignee && (
                    <span className="text-muted-foreground">
                      负责人：{item.assignee}
                    </span>
                  )}
                  {item.dueDate && (
                    <span className="text-muted-foreground">
                      截止：{item.dueDate}
                    </span>
                  )}
                  <Badge
                    variant="outline"
                    className={ACTION_STATUS_STYLES[item.status] ?? ''}
                  >
                    {item.status}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="mb-3 text-sm font-semibold">关键决策</div>
          {detail.decisions ? (
            <p className="whitespace-pre-wrap text-sm">{detail.decisions}</p>
          ) : (
            <p className="text-sm text-muted-foreground">暂无关键决策记录</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
