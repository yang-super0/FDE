import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CalendarDays, Plus } from 'lucide-react';
import {
  Table,
  type TableColumnsType,
} from '@lark-apaas/client-toolkit/antd-table';
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@client/src/components/ui/empty';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { listCustomers } from '@client/src/api/customers';
import { listMeetingMinutes } from '@client/src/api/meeting-minutes';
import { ProjectDateField } from '@client/src/pages/Projects/ProjectDateField';
import {
  MEETING_TYPES,
  MEETING_TYPE_STYLES,
  MEETING_SOURCE_STYLES,
} from '@client/src/pages/MeetingMinutes/minute-constants';
import type {
  CustomerListResponse,
  MeetingMinuteListItem,
  MeetingMinuteListParams,
  MeetingMinuteListResponse,
  MeetingType,
} from '@shared/api.interface';

interface CustomerOption {
  id: string;
  name: string;
}

export const MeetingMinutesPage: React.FC = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState<MeetingMinuteListItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);
  const [loading, setLoading] = useState<boolean>(true);
  const [customers, setCustomers] = useState<CustomerOption[]>([]);
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [meetingType, setMeetingType] = useState<string>('');
  const [customerId, setCustomerId] = useState<string>('');

  const fetchList = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const params: MeetingMinuteListParams = { page, pageSize };
      if (startDate) params.startDate = startDate;
      if (endDate) params.endDate = endDate;
      if (meetingType) params.meetingType = meetingType as MeetingType;
      if (customerId) params.customerId = customerId;
      const res: MeetingMinuteListResponse = await listMeetingMinutes(params);
      setItems(res.items);
      setTotal(res.total);
    } catch {
      setItems([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, startDate, endDate, meetingType, customerId]);

  useEffect(() => {
    void fetchList();
  }, [fetchList]);

  useEffect(() => {
    const fetchCustomers = async (): Promise<void> => {
      try {
        const res: CustomerListResponse = await listCustomers({
          page: 1,
          pageSize: 50,
        });
        setCustomers(
          res.items.map((item) => ({ id: item.id, name: item.name })),
        );
      } catch {
        setCustomers([]);
      }
    };
    void fetchCustomers();
  }, []);

  const columns: TableColumnsType<MeetingMinuteListItem> = [
    {
      title: '会议标题',
      dataIndex: 'title',
      width: 280,
      render: (title: string, record: MeetingMinuteListItem) => (
        <button
          type="button"
          className="text-left font-medium text-primary hover:underline"
          onClick={() => navigate(`/meeting-minutes/${record.id}`)}
        >
          {title}
        </button>
      ),
    },
    { title: '会议日期', dataIndex: 'meetingDate', width: 120 },
    {
      title: '会议类型',
      dataIndex: 'meetingType',
      width: 120,
      render: (type: MeetingType) => (
        <Badge variant="outline" className={MEETING_TYPE_STYLES[type]}>
          {type}
        </Badge>
      ),
    },
    {
      title: '关联客户',
      dataIndex: 'customerName',
      width: 220,
      render: (name: string | null) => name ?? '-',
    },
    {
      title: '来源',
      dataIndex: 'source',
      width: 120,
      render: (source: MeetingMinuteListItem['source']) => (
        <Badge
          variant="outline"
          className={MEETING_SOURCE_STYLES[source] ?? ''}
        >
          {source}
        </Badge>
      ),
    },
    { title: '创建人', dataIndex: 'createdBy', width: 120 },
    {
      title: '操作',
      key: 'actions',
      width: 100,
      render: (_: unknown, record: MeetingMinuteListItem) => (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate(`/meeting-minutes/${record.id}`)}
        >
          查看
        </Button>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-xl font-semibold">会议纪要</h1>
        <p className="text-sm text-muted-foreground">
          记录会议结论与待办，关联客户自动进入跟进时间线
        </p>
        <Button
          className="ml-auto"
          data-ai-section-type="button"
          onClick={() => navigate('/meeting-minutes/new')}
        >
          <Plus className="mr-2 size-4" />
          新建纪要
        </Button>
      </div>

      <div className="flex flex-wrap items-end gap-3">
        <div className="w-40 space-y-1">
          <p className="text-xs text-muted-foreground">开始日期</p>
          <ProjectDateField
            value={startDate}
            onChange={(date) => {
              setStartDate(date);
              setPage(1);
            }}
            placeholder="开始日期"
          />
        </div>
        <div className="w-40 space-y-1">
          <p className="text-xs text-muted-foreground">结束日期</p>
          <ProjectDateField
            value={endDate}
            onChange={(date) => {
              setEndDate(date);
              setPage(1);
            }}
            placeholder="结束日期"
          />
        </div>
        <div className="w-40 space-y-1">
          <p className="text-xs text-muted-foreground">会议类型</p>
          <Select
            value={meetingType || 'all'}
            onValueChange={(value) => {
              setMeetingType(value === 'all' ? '' : value);
              setPage(1);
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="全部类型" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部类型</SelectItem>
              {MEETING_TYPES.map((type) => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="w-56 space-y-1">
          <p className="text-xs text-muted-foreground">关联客户</p>
          <Select
            value={customerId || 'all'}
            onValueChange={(value) => {
              setCustomerId(value === 'all' ? '' : value);
              setPage(1);
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="全部客户" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部客户</SelectItem>
              {customers.map((item) => (
                <SelectItem key={item.id} value={item.id}>
                  {item.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table
            columns={columns}
            dataSource={items}
            loading={loading}
            rowKey="id"
            scroll={{ x: 1100 }}
            pagination={{
              current: page,
              pageSize,
              total,
              showSizeChanger: true,
              onChange: (nextPage: number, nextPageSize: number) => {
                setPage(nextPage);
                setPageSize(nextPageSize);
              },
            }}
            locale={{
              emptyText: (
                <Empty>
                  <EmptyHeader>
                    <EmptyMedia variant="icon">
                      <CalendarDays className="size-6" />
                    </EmptyMedia>
                    <EmptyTitle>暂无会议纪要</EmptyTitle>
                    <EmptyDescription>
                      调整筛选条件，或点击「新建纪要」创建第一条会议纪要
                    </EmptyDescription>
                  </EmptyHeader>
                </Empty>
              ),
            }}
          />
        </CardContent>
      </Card>
    </div>
  );
};
