import React from 'react';
import dayjs from 'dayjs';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { ProjectDateField } from '@client/src/pages/Projects/ProjectDateField';
import { MinuteActionItemEditor } from '@client/src/pages/MeetingMinutes/MinuteActionItemEditor';
import {
  MEETING_TYPES,
} from '@client/src/pages/MeetingMinutes/minute-constants';
import type {
  MeetingActionItem,
  MeetingAttendee,
  MeetingType,
} from '@shared/api.interface';

export interface CustomerOption {
  id: string;
  name: string;
}

export interface MinuteFormState {
  title: string;
  meetingDate: string;
  meetingType: MeetingType;
  customerId: string;
  attendees: MeetingAttendee[];
  keyTopics: string[];
  actionItems: MeetingActionItem[];
  decisions: string;
}

export const EMPTY_FORM_STATE: MinuteFormState = {
  title: '',
  meetingDate: dayjs().format('YYYY-MM-DD'),
  meetingType: '内部会议',
  customerId: '',
  attendees: [],
  keyTopics: [],
  actionItems: [],
  decisions: '',
};

interface MinuteFormFieldsProps {
  value: MinuteFormState;
  onChange: (next: MinuteFormState) => void;
  customers: CustomerOption[];
  customerHint?: string;
  onCustomerHintDismiss?: () => void;
}

export const MinuteFormFields: React.FC<MinuteFormFieldsProps> = ({
  value,
  onChange,
  customers,
  customerHint,
  onCustomerHintDismiss,
}) => {
  const patch = (partial: Partial<MinuteFormState>): void => {
    onChange({ ...value, ...partial });
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="minute-title">会议标题 *</Label>
          <Input
            id="minute-title"
            value={value.title}
            maxLength={200}
            placeholder="请输入会议标题"
            onChange={(event) => patch({ title: event.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label>会议日期 *</Label>
          <ProjectDateField
            value={value.meetingDate}
            onChange={(date) => patch({ meetingDate: date })}
            placeholder="选择会议日期"
          />
        </div>
        <div className="space-y-2">
          <Label>会议类型 *</Label>
          <Select
            value={value.meetingType}
            onValueChange={(type) => patch({ meetingType: type as MeetingType })}
          >
            <SelectTrigger>
              <SelectValue placeholder="选择会议类型" />
            </SelectTrigger>
            <SelectContent>
              {MEETING_TYPES.map((type) => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2 md:col-span-2">
          <Label>关联客户（可选）</Label>
          <Select
            value={value.customerId || 'none'}
            onValueChange={(id) => {
              patch({ customerId: id === 'none' ? '' : id });
              onCustomerHintDismiss?.();
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="选择关联客户" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">不关联客户</SelectItem>
              {customers.map((item) => (
                <SelectItem key={item.id} value={item.id}>
                  {item.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {customerHint ? (
            <p className="text-xs text-[hsl(38_85%_48%)]">{customerHint}</p>
          ) : null}
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label>参会人</Label>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            data-ai-section-type="button"
            onClick={() =>
              patch({ attendees: [...value.attendees, { name: '', role: '' }] })
            }
          >
            <Plus className="mr-1 size-4" />
            添加参会人
          </Button>
        </div>
        {value.attendees.length === 0 ? (
          <p className="text-xs text-muted-foreground">暂无参会人</p>
        ) : (
          <div className="space-y-2">
            {value.attendees.map((attendee, index) => (
              <div key={index} className="flex items-center gap-2">
                <Input
                  value={attendee.name}
                  placeholder="姓名"
                  onChange={(event) => {
                    const next = [...value.attendees];
                    next[index] = { ...attendee, name: event.target.value };
                    patch({ attendees: next });
                  }}
                />
                <Input
                  value={attendee.role}
                  placeholder="角色，如：销售 / 客户方负责人"
                  onChange={(event) => {
                    const next = [...value.attendees];
                    next[index] = { ...attendee, role: event.target.value };
                    patch({ attendees: next });
                  }}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() =>
                    patch({
                      attendees: value.attendees.filter(
                        (_item, idx) => idx !== index,
                      ),
                    })
                  }
                >
                  <Trash2 className="size-4 text-muted-foreground" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label>核心议题</Label>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            data-ai-section-type="button"
            onClick={() => patch({ keyTopics: [...value.keyTopics, ''] })}
          >
            <Plus className="mr-1 size-4" />
            添加议题
          </Button>
        </div>
        {value.keyTopics.length === 0 ? (
          <p className="text-xs text-muted-foreground">暂无核心议题</p>
        ) : (
          <div className="space-y-2">
            {value.keyTopics.map((topic, index) => (
              <div key={index} className="flex items-center gap-2">
                <Input
                  value={topic}
                  placeholder="请输入议题内容"
                  onChange={(event) => {
                    const next = [...value.keyTopics];
                    next[index] = event.target.value;
                    patch({ keyTopics: next });
                  }}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() =>
                    patch({
                      keyTopics: value.keyTopics.filter(
                        (_item, idx) => idx !== index,
                      ),
                    })
                  }
                >
                  <Trash2 className="size-4 text-muted-foreground" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      <MinuteActionItemEditor
        value={value.actionItems}
        onChange={(items) => patch({ actionItems: items })}
      />

      <div className="space-y-2">
        <Label htmlFor="minute-decisions">关键决策</Label>
        <Textarea
          id="minute-decisions"
          value={value.decisions}
          rows={4}
          placeholder="记录本次会议达成的关键决策"
          onChange={(event) => patch({ decisions: event.target.value })}
        />
      </div>
    </div>
  );
};
