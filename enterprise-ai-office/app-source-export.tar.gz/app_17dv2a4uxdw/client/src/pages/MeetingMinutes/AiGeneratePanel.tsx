import React, { useState } from 'react';
import dayjs from 'dayjs';
import { Sparkles } from 'lucide-react';
import { capabilityClient } from '@lark-apaas/client-toolkit';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { Button } from '@client/src/components/ui/button';
import { Textarea } from '@client/src/components/ui/textarea';
import type {
  MeetingActionItem,
  MeetingAttendee,
  MeetingType,
} from '@shared/api.interface';
import { MEETING_TYPES } from './minute-constants';

export interface AiExtractResult {
  title: string;
  meetingType: MeetingType;
  customerName: string;
  attendees: MeetingAttendee[];
  keyTopics: string[];
  actionItems: MeetingActionItem[];
  decisions: string;
}

interface AiGeneratePanelProps {
  onApply: (result: AiExtractResult) => void;
}

interface TextToJsonOutput {
  attendees: string;
  key_topics: string;
  action_items: string;
  decisions: string;
  title?: string;
  meeting_type?: string;
  customer_name?: string;
}

const MINUTES_LINK_PATTERN: RegExp = /\/minutes\/[a-zA-Z0-9]{10,}/u;

function parseJsonArray(raw: unknown): unknown[] {
  if (Array.isArray(raw)) return raw;
  if (typeof raw === 'string' && raw.trim().length > 0) {
    try {
      const parsed: unknown = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
}

function toAttendees(raw: unknown): MeetingAttendee[] {
  return parseJsonArray(raw)
    .map((item: unknown) => {
      const record = item as Record<string, unknown>;
      return {
        name: String(record.name ?? '').trim(),
        role: String(record.role ?? '').trim(),
      };
    })
    .filter((item: MeetingAttendee) => item.name.length > 0);
}

function toTopics(raw: unknown): string[] {
  return parseJsonArray(raw)
    .map((item: unknown) =>
      typeof item === 'string' ? item.trim() : String(item ?? '').trim(),
    )
    .filter((topic: string) => topic.length > 0);
}

function normalizeDueDateYear(dueDate: string): string {
  const trimmed: string = dueDate.trim();
  if (!/^\d{4}-\d{1,2}-\d{1,2}$/u.test(trimmed)) {
    return trimmed;
  }
  const currentYear: number = dayjs().year();
  const [yearPart, ...rest]: string[] = trimmed.split('-');
  if (Number(yearPart) === currentYear) {
    return trimmed;
  }
  return `${currentYear}-${rest.join('-')}`;
}

function extractCustomerNameFromText(text: string): string {
  const pattern: RegExp =
    /[一-龥A-Za-z0-9]{2,15}(公司|集团|工程|科技|股份|银行|研究院|事务所)/gu;
  const matches: string[] = text.match(pattern) ?? [];
  const sorted: string[] = [...matches].sort(
    (a: string, b: string) => b.length - a.length,
  );
  return sorted[0] ?? '';
}

function toMeetingType(raw: unknown, hasCustomer: boolean): MeetingType {
  const candidate: string = String(raw ?? '').trim();
  if (MEETING_TYPES.includes(candidate as MeetingType)) {
    return candidate as MeetingType;
  }
  return hasCustomer ? '客户拜访' : '内部会议';
}

function toActionItems(raw: unknown): MeetingActionItem[] {
  return parseJsonArray(raw).map((item: unknown) => {
    const record = item as Record<string, unknown>;
    const status = String(record.status ?? '');
    return {
      content: String(record.content ?? '').trim(),
      assignee: String(record.assignee ?? '').trim(),
      dueDate: normalizeDueDateYear(
        String(record.due_date ?? record.dueDate ?? ''),
      ),
      status: ['未开始', '进行中', '已完成'].includes(status)
        ? (status as MeetingActionItem['status'])
        : '未开始',
    };
  });
}

export const AiGeneratePanel: React.FC<AiGeneratePanelProps> = ({
  onApply,
}) => {
  const [meetingText, setMeetingText] = useState<string>('');
  const [generating, setGenerating] = useState<boolean>(false);

  const handleGenerate = async (): Promise<void> => {
    if (!meetingText.trim()) {
      toast.error('请先输入沟通要点内容');
      return;
    }
    if (MINUTES_LINK_PATTERN.test(meetingText)) {
      toast.error(
        '检测到飞书妙记链接：当前暂不支持直接导入链接，请在飞书妙记中复制转写文本后粘贴到此处',
        { duration: 6000 },
      );
      return;
    }
    setGenerating(true);
    try {
      const todayText: string = dayjs().format('YYYY-MM-DD');
      const inputText: string = `[今天日期是${todayText}，所有相对日期请基于该日期计算。]\n${meetingText}`;
      const output = await capabilityClient
        .load('meeting_minutes_ai_extract_1')
        .call<TextToJsonOutput>('textToJson', { meeting_text: inputText });
      const keyTopics: string[] = toTopics(output.key_topics);
      const aiTitle: string = String(output.title ?? '').trim();
      const aiCustomerName: string = String(output.customer_name ?? '').trim();
      const customerName: string =
        aiCustomerName || extractCustomerNameFromText(meetingText);
      const result: AiExtractResult = {
        title:
          aiTitle ||
          (keyTopics.length > 0 ? `关于${keyTopics[0]}的会议` : ''),
        meetingType: toMeetingType(output.meeting_type, customerName.length > 0),
        customerName,
        attendees: toAttendees(output.attendees),
        keyTopics,
        actionItems: toActionItems(output.action_items),
        decisions: output.decisions ?? '',
      };
      onApply(result);
      toast.success('AI 结构化生成完成，请核对后保存');
    } catch (error) {
      logger.error(`AI 结构化生成失败: ${String(error)}`);
      toast.error('AI 结构化生成失败，请重试');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-3">
      <Textarea
        value={meetingText}
        onChange={(event) => setMeetingText(event.target.value)}
        rows={8}
        placeholder="粘贴一段沟通要点，例如：2026年9月10日拜访杭州云启科技，参会人王阳阳（销售）、陈总（客户方采购总监）。讨论了防撞墙台车的报价方案，客户确认选用FZQ-12型号。待办：王阳阳在9月13日前提交正式报价..."
      />
      <Button
        data-ai-section-type="button"
        onClick={() => {
          void handleGenerate();
        }}
        disabled={generating}
      >
        <Sparkles className="mr-2 size-4" />
        {generating ? 'AI 正在结构化生成...' : 'AI 结构化生成'}
      </Button>
      <p className="text-xs text-muted-foreground">
        AI 将自动提取标题、会议类型、关联客户、参会人、核心议题、待办事项（含负责人与截止时间）、关键决策，生成后可编辑后再保存；支持粘贴飞书妙记转写文本，自动结构化提取（暂不支持直接粘贴妙记链接）
      </p>
    </div>
  );
};
