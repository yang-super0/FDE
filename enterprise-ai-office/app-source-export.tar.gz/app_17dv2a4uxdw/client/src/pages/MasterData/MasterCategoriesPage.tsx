import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { FolderTree, Plus, Search } from 'lucide-react';
import type {
  BaseDataStatus,
  CustomCategoryNode,
  CustomCategoryTreeResponse,
} from '@shared/api.interface';
import {
  listCategoryTree,
  updateCategoryStatus,
} from '@client/src/api/master-data';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@client/src/components/ui/empty';
import { Input } from '@client/src/components/ui/input';
import { getApiErrorMessage, MasterDataStatusBadge } from './MasterDataShared';
import MasterCategoryDialog from './MasterCategoryDialog';

interface FlatCategoryRow {
  node: CustomCategoryNode;
  level: number;
}

function flattenTree(
  nodes: CustomCategoryNode[],
  level: number,
): FlatCategoryRow[] {
  const rows: FlatCategoryRow[] = [];
  for (const node of nodes) {
    rows.push({ node, level });
    if (node.children.length > 0) {
      rows.push(...flattenTree(node.children, level + 1));
    }
  }
  return rows;
}

const MasterCategoriesPage: React.FC = () => {
  const [keyword, setKeyword] = useState<string>('');
  const [items, setItems] = useState<CustomCategoryNode[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [editing, setEditing] = useState<CustomCategoryNode | null>(null);
  const [defaultParentId, setDefaultParentId] = useState<string | undefined>(
    undefined,
  );

  const fetchTree = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const res: CustomCategoryTreeResponse = await listCategoryTree(
        keyword.trim() || undefined,
      );
      setItems(res.items);
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error('分类列表加载失败');
    } finally {
      setLoading(false);
    }
  }, [keyword]);

  useEffect(() => {
    void fetchTree();
  }, [fetchTree]);

  const rows: FlatCategoryRow[] = useMemo(
    () => flattenTree(items, 0),
    [items],
  );

  const handleToggleStatus = async (
    record: CustomCategoryNode,
  ): Promise<void> => {
    const target: BaseDataStatus =
      record.status === 'active' ? 'disabled' : 'active';
    try {
      await updateCategoryStatus(record.id, { status: target });
      toast.success(target === 'disabled' ? '分类已停用' : '分类已启用');
      void fetchTree();
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(getApiErrorMessage(error, '操作失败'));
    }
  };

  return (
    <div className="mx-auto max-w-[1400px] space-y-4 p-6">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative w-64">
          <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
          <Input
            className="pl-8"
            placeholder="搜索分类名称"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === 'Enter') {
                void fetchTree();
              }
            }}
          />
        </div>
        <Button
          className="ml-auto"
          data-ai-section-type="button"
          onClick={() => {
            setEditing(null);
            setDefaultParentId(undefined);
            setDialogOpen(true);
          }}
        >
          <Plus className="mr-2 size-4" />
          新增分类
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 text-center text-sm text-muted-foreground">
              加载中...
            </div>
          ) : rows.length === 0 ? (
            <Empty>
              <EmptyHeader>
                <EmptyMedia variant="icon">
                  <FolderTree className="size-6" />
                </EmptyMedia>
                <EmptyTitle>暂无分类</EmptyTitle>
                <EmptyDescription>
                  调整搜索关键词，或点击「新增分类」创建第一个分类
                </EmptyDescription>
              </EmptyHeader>
            </Empty>
          ) : (
            <div>
              {rows.map(({ node, level }: FlatCategoryRow) => (
                <div
                  key={node.id}
                  className="flex h-12 items-center gap-4 border-b px-4 last:border-b-0"
                  style={{ paddingLeft: 16 + level * 24 }}
                >
                  <div
                    className={`flex-1 truncate text-sm ${
                      node.status === 'disabled'
                        ? 'text-muted-foreground'
                        : ''
                    }`}
                  >
                    {node.name}
                  </div>
                  <div className="w-16 text-right font-mono text-xs text-muted-foreground">
                    {node.sortOrder}
                  </div>
                  <div className="w-16">
                    <MasterDataStatusBadge status={node.status} />
                  </div>
                  <div className="flex w-48 items-center justify-end gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setEditing(null);
                        setDefaultParentId(node.id);
                        setDialogOpen(true);
                      }}
                    >
                      添加子分类
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setEditing(node);
                        setDefaultParentId(undefined);
                        setDialogOpen(true);
                      }}
                    >
                      编辑
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className={
                        node.status === 'active'
                          ? 'text-[hsl(0_65%_52%)]'
                          : 'text-[hsl(152_60%_42%)]'
                      }
                      onClick={() => void handleToggleStatus(node)}
                    >
                      {node.status === 'active' ? '停用' : '启用'}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <MasterCategoryDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editing={editing}
        defaultParentId={defaultParentId}
        onSaved={() => {
          void fetchTree();
        }}
      />
    </div>
  );
};

export default MasterCategoriesPage;
