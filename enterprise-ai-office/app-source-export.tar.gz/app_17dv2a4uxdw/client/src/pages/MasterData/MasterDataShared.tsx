import React from 'react';
import { Badge } from '@client/src/components/ui/badge';
import type { BaseDataStatus } from '@shared/api.interface';

export const STATUS_LABEL: Record<BaseDataStatus, string> = {
  active: '启用',
  disabled: '停用',
};

export const MasterDataStatusBadge: React.FC<{ status: BaseDataStatus }> = ({
  status,
}) => {
  if (status === 'active') {
    return (
      <Badge className="border-transparent bg-[hsl(152_55%_96%)] text-[hsl(152_60%_42%)]">
        {STATUS_LABEL.active}
      </Badge>
    );
  }
  return (
    <Badge className="border-transparent bg-[hsl(216_12%_94%)] text-[hsl(216_15%_55%)]">
      {STATUS_LABEL.disabled}
    </Badge>
  );
};

export function formatAmount(value: number): string {
  return `¥${value.toLocaleString('zh-CN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function getApiErrorMessage(error: unknown, fallback: string): string {
  if (error && typeof error === 'object') {
    const err = error as {
      response?: { data?: { error?: { message?: string } } };
      message?: string;
    };
    const apiMessage: string | undefined = err.response?.data?.error?.message;
    if (apiMessage) {
      return apiMessage;
    }
    if (err.message) {
      return err.message;
    }
  }
  return fallback;
}
