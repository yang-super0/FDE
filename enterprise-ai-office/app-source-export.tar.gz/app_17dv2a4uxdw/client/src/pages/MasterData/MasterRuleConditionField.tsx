import React from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  SCENE_CUSTOM,
  SCENE_OPTIONS,
  type SceneOption,
} from './master-pricing-rule-config';

interface MasterRuleConditionFieldProps {
  scene: string;
  onSceneChange: (scene: string) => void;
  customConditionsText: string;
  onCustomConditionsTextChange: (text: string) => void;
}

const MasterRuleConditionField: React.FC<MasterRuleConditionFieldProps> = ({
  scene,
  onSceneChange,
  customConditionsText,
  onCustomConditionsTextChange,
}) => {
  return (
    <div className="space-y-1.5 rounded-lg bg-accent p-3">
      <div className="text-sm font-medium">条件配置 *</div>
      <Select value={scene} onValueChange={onSceneChange}>
        <SelectTrigger>
          <SelectValue placeholder="选择触发条件" />
        </SelectTrigger>
        <SelectContent>
          {SCENE_OPTIONS.map((option: SceneOption) => (
            <SelectItem key={option.value} value={option.value}>
              {option.label}
            </SelectItem>
          ))}
          <SelectItem value={SCENE_CUSTOM}>自定义 JSON</SelectItem>
        </SelectContent>
      </Select>
      {scene === SCENE_CUSTOM ? (
        <Textarea
          className="mt-2 font-mono text-xs"
          rows={4}
          value={customConditionsText}
          onChange={(e) => onCustomConditionsTextChange(e.target.value)}
          placeholder='{"project_environment": "coastal", "required": true}'
        />
      ) : (
        <div className="text-xs text-muted-foreground">
          创建报价选择对应项目场景时，该定制项将被强制选入并按此金额加价
        </div>
      )}
    </div>
  );
};

export default MasterRuleConditionField;
