import React, { useCallback, useEffect, useState } from 'react';
import dayjs from 'dayjs';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Table,
  type TableColumnsType,
} from '@lark-apaas/client-toolkit/antd-table';
import { Plus, Search, Wrench } from 'lucide-react';
import type {
  BaseDataStatus,
  CustomCategoryOption,
  CustomCategoryOptionsResponse,
  CustomItemAdminItem,
  CustomItemAdminListParams,
  CustomItemAdminListResponse,
} from '@shared/api.interface';
import {
  listCategoryOptions,
  listCustomItemsAdmin,
  updateCustomItemStatus,
} from '@client/src/api/master-data';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@client/src/components/ui/empty';
import { Input } from '@client/src/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  formatAmount,
  getApiErrorMessage,
  MasterDataStatusBadge,
} from './MasterDataShared';
import MasterCustomItemDialog from './MasterCustomItemDialog';

const ALL_VALUE: string = '__all__';
const DEFAULT_PAGE_SIZE: number = 20;

const PRICE_TYPE_LABEL: Record<string, string> = {
  fixed: '固定价',
  percent: '百分比',
};

const MasterCustomItemsPage: React.FC = () => {
  const [keyword, setKeyword] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>(ALL_VALUE);
  const [statusFilter, setStatusFilter] = useState<string>(ALL_VALUE);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(DEFAULT_PAGE_SIZE);
  const [items, setItems] = useState<CustomItemAdminItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);
  const [categoryOptions, setCategoryOptions] = useState<CustomCategoryOption[]>([]);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [editing, setEditing] = useState<CustomItemAdminItem | null>(null);

  const fetchCategoryOptions = useCallback(async (): Promise<void> => {
    try {
      const res: CustomCategoryOptionsResponse = await listCategoryOptions();
      setCategoryOptions(res.items);
    } catch (error: unknown) {
      logger.error(String(error));
    }
  }, []);

  useEffect(() => {
    void fetchCategoryOptions();
  }, [fetchCategoryOptions]);


  const fetchList = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const params: CustomItemAdminListParams = {
        page,
        pageSize,
        keyword: keyword.trim() || undefined,
        status:
          statusFilter === ALL_VALUE
            ? undefined
            : (statusFilter as BaseDataStatus),
        categoryId: categoryFilter === ALL_VALUE ? undefined : categoryFilter,
      };
      const res: CustomItemAdminListResponse = await listCustomItemsAdmin(params);
      setItems(res.items);
      setTotal(res.total);
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error('定制项列表加载失败');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, keyword, statusFilter, categoryFilter]);

  useEffect(() => void fetchList(), [fetchList]);

  const handleToggleStatus = async (
    record: CustomItemAdminItem,
  ): Promise<void> => {
    const target: BaseDataStatus = record.status === 'active' ? 'disabled' : 'active';
    try {
      await updateCustomItemStatus(record.id, { status: target });
      toast.success(target === 'disabled' ? '定制项已停用' : '定制项已启用');
      void fetchList();
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(getApiErrorMessage(error, '操作失败'));
    }
  };

  const columns: TableColumnsType<CustomItemAdminItem> = [
    {
      title: '定制项名称',
      dataIndex: 'name',
      width: 220,
      fixed: 'left',
      ellipsis: true,
    },
    { title: '所属分类', dataIndex: 'categoryName', width: 160 },
    {
      title: '默认价',
      dataIndex: 'defaultPrice',
      width: 140,
      align: 'right',
      render: (value: number) => (
        <span className="font-mono">{formatAmount(value)}</span>
      ),
    },
    {
      title: '计价方式',
      dataIndex: 'priceType',
      width: 110,
      render: (value: string) => PRICE_TYPE_LABEL[value] ?? value,
    },
    {
      title: '单位',
      dataIndex: 'unit',
      width: 90,
      render: (value: string | null) => value || '—',
    },
    {
      title: '状态',
      dataIndex: 'status',
      width: 100,
      render: (status: BaseDataStatus) => (
        <MasterDataStatusBadge status={status} />
      ),
    },
    {
      title: '更新时间',
      dataIndex: 'updatedAt',
      width: 170,
      render: (value: string) => dayjs(value).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: '操作',
      key: 'action',
      fixed: 'right',
      width: 160,
      render: (_: unknown, record: CustomItemAdminItem) => (
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => { setEditing(record); setDialogOpen(true); }}
          >
            编辑
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className={
              record.status === 'active'
                ? 'text-[hsl(0_65%_52%)]'
                : 'text-[hsl(152_60%_42%)]'
            }
            onClick={() => void handleToggleStatus(record)}
          >
            {record.status === 'active' ? '停用' : '启用'}
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="mx-auto max-w-[1400px] space-y-4 p-6">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative w-64">
          <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
          <Input
            className="pl-8"
            placeholder="搜索定制项名称"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === 'Enter') {
                setPage(1);
                void fetchList();
              }
            }}
          />
        </div>
        <Select
          value={categoryFilter}
          onValueChange={(value: string) => { setCategoryFilter(value); setPage(1); }}
        >
          <SelectTrigger className="w-44">
            <SelectValue placeholder="分类" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_VALUE}>全部分类</SelectItem>
            {categoryOptions.map((option: CustomCategoryOption) => (
              <SelectItem key={option.id} value={option.id}>
                {option.fullName}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={statusFilter}
          onValueChange={(value: string) => { setStatusFilter(value); setPage(1); }}
        >
          <SelectTrigger className="w-32">
            <SelectValue placeholder="状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_VALUE}>全部状态</SelectItem>
            <SelectItem value="active">启用</SelectItem>
            <SelectItem value="disabled">停用</SelectItem>
          </SelectContent>
        </Select>
        <Button
          className="ml-auto"
          data-ai-section-type="button"
          onClick={() => { setEditing(null); setDialogOpen(true); }}
        >
          <Plus className="mr-2 size-4" />
          新增定制项
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table
            columns={columns}
            dataSource={items}
            loading={loading}
            rowKey="id"
            scroll={{ x: 1150, y: 500 }}
            pagination={{
              current: page,
              pageSize,
              total,
              showSizeChanger: true,
              onChange: (nextPage: number, nextPageSize: number) => {
                setPage(nextPage);
                setPageSize(nextPageSize);
              },
            }}
            locale={{
              emptyText: (
                <Empty>
                  <EmptyHeader>
                    <EmptyMedia variant="icon">
                      <Wrench className="size-6" />
                    </EmptyMedia>
                    <EmptyTitle>暂无定制项</EmptyTitle>
                    <EmptyDescription>
                      调整筛选条件，或点击「新增定制项」创建第一个定制项
                    </EmptyDescription>
                  </EmptyHeader>
                </Empty>
              ),
            }}
          />
        </CardContent>
      </Card>

      <MasterCustomItemDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editing={editing}
        onSaved={() => void fetchList()}
      />
    </div>
  );
};

export default MasterCustomItemsPage;
