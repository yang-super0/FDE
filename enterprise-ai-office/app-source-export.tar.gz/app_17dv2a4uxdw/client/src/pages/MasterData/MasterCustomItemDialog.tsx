import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type {
  CustomCategoryOption,
  CustomItemAdminItem,
} from '@shared/api.interface';
import {
  createCustomItem,
  listCategoryOptions,
  updateCustomItem,
} from '@client/src/api/master-data';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Textarea } from '@client/src/components/ui/textarea';
import { getApiErrorMessage } from './MasterDataShared';

interface MasterCustomItemDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editing: CustomItemAdminItem | null;
  onSaved: () => void;
}

const MasterCustomItemDialog: React.FC<MasterCustomItemDialogProps> = ({
  open,
  onOpenChange,
  editing,
  onSaved,
}) => {
  const [name, setName] = useState<string>('');
  const [categoryId, setCategoryId] = useState<string>('');
  const [defaultPrice, setDefaultPrice] = useState<string>('');
  const [priceType, setPriceType] = useState<string>('fixed');
  const [unit, setUnit] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [categoryOptions, setCategoryOptions] = useState<CustomCategoryOption[]>(
    [],
  );
  const [submitting, setSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (!open) {
      return;
    }
    const loadOptions = async (): Promise<void> => {
      try {
        const res = await listCategoryOptions();
        setCategoryOptions(res.items);
      } catch (error: unknown) {
        logger.error(String(error));
        toast.error(getApiErrorMessage(error, '分类加载失败'));
      }
    };
    void loadOptions();
    if (editing) {
      setName(editing.name);
      setCategoryId(editing.categoryId);
      setDefaultPrice(String(editing.defaultPrice));
      setPriceType(editing.priceType);
      setUnit(editing.unit ?? '');
      setDescription(editing.description ?? '');
    } else {
      setName('');
      setCategoryId('');
      setDefaultPrice('');
      setPriceType('fixed');
      setUnit('');
      setDescription('');
    }
  }, [open, editing]);

  const handleSubmit = async (): Promise<void> => {
    if (!name.trim()) {
      toast.error('请填写定制项名称');
      return;
    }
    if (!categoryId) {
      toast.error('请选择所属分类');
      return;
    }
    const price: number = Number(defaultPrice);
    if (!Number.isFinite(price) || price < 0) {
      toast.error('请填写有效的默认价');
      return;
    }

    setSubmitting(true);
    try {
      if (editing) {
        await updateCustomItem(editing.id, {
          name: name.trim(),
          categoryId,
          defaultPrice: price,
          priceType,
          unit: unit.trim() || undefined,
          description: description || undefined,
        });
        toast.success('定制项已更新');
      } else {
        await createCustomItem({
          name: name.trim(),
          categoryId,
          defaultPrice: price,
          priceType,
          unit: unit.trim() || undefined,
          description: description || undefined,
        });
        toast.success('定制项已创建');
      }
      onOpenChange(false);
      onSaved();
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(getApiErrorMessage(error, '保存失败'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{editing ? '编辑定制项' : '新增定制项'}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="text-sm font-medium">名称 *</div>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="定制项名称"
              />
            </div>
            <div className="space-y-1.5">
              <div className="text-sm font-medium">所属分类 *</div>
              <Select value={categoryId} onValueChange={setCategoryId}>
                <SelectTrigger>
                  <SelectValue placeholder="选择分类" />
                </SelectTrigger>
                <SelectContent>
                  {categoryOptions.map((option: CustomCategoryOption) => (
                    <SelectItem key={option.id} value={option.id}>
                      {option.fullName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <div className="text-sm font-medium">默认价（元）*</div>
              <Input
                value={defaultPrice}
                onChange={(e) => setDefaultPrice(e.target.value)}
                placeholder="0.00"
                inputMode="decimal"
              />
            </div>
            <div className="space-y-1.5">
              <div className="text-sm font-medium">计价方式 *</div>
              <Select value={priceType} onValueChange={setPriceType}>
                <SelectTrigger>
                  <SelectValue placeholder="计价方式" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="fixed">固定价</SelectItem>
                  <SelectItem value="percent">百分比</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <div className="text-sm font-medium">单位</div>
              <Input
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="如 套 / 米 / 项"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <div className="text-sm font-medium">描述</div>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="定制项描述"
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={() => void handleSubmit()} disabled={submitting}>
            {submitting ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default MasterCustomItemDialog;
