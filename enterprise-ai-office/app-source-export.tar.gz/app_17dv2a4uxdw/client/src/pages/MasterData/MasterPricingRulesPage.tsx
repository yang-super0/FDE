import React, { useCallback, useEffect, useState } from 'react';
import dayjs from 'dayjs';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Table,
  type TableColumnsType,
} from '@lark-apaas/client-toolkit/antd-table';
import { BadgePercent, Plus, Search } from 'lucide-react';
import type {
  BaseDataStatus,
  PricingRuleAdminItem,
  PricingRuleAdminListParams,
  PricingRuleAdminListResponse,
  PricingRuleType,
} from '@shared/api.interface';
import {
  listPricingRulesAdmin,
  updatePricingRuleStatus,
} from '@client/src/api/master-data';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@client/src/components/ui/empty';
import { Input } from '@client/src/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  formatAmount,
  getApiErrorMessage,
  MasterDataStatusBadge,
} from './MasterDataShared';
import MasterPricingRuleDialog from './MasterPricingRuleDialog';

const ALL_STATUS: string = '__all__';
const ALL_TYPE: string = '__all__';
const DEFAULT_PAGE_SIZE: number = 20;

const RULE_TYPE_META: Record<
  string,
  { label: string; className: string }
> = {
  standard: {
    label: '普通加价',
    className:
      'border-transparent bg-[hsl(217_40%_95%)] text-[hsl(217_70%_40%)]',
  },
  conditional: {
    label: '条件加价',
    className:
      'border-transparent bg-[hsl(38_80%_96%)] text-[hsl(38_85%_48%)]',
  },
  package: {
    label: '套餐组合',
    className:
      'border-transparent bg-[hsl(152_55%_96%)] text-[hsl(152_60%_42%)]',
  },
  base_price: {
    label: '基础价',
    className:
      'border-transparent bg-[hsl(216_12%_94%)] text-[hsl(216_15%_45%)]',
  },
};

function formatConditions(
  conditions: Record<string, string | number | boolean> | null,
): string {
  if (!conditions) {
    return '—';
  }
  if (conditions.project_environment === 'coastal') {
    return '项目场景 = 沿海项目';
  }
  if (conditions.road_type === 'expressway') {
    return '道路类型 = 高速项目';
  }
  return Object.entries(conditions)
    .map(([key, value]: [string, string | number | boolean]) =>
      key === 'required' ? '必选' : `${key} = ${String(value)}`,
    )
    .join('；');
}

const MasterPricingRulesPage: React.FC = () => {
  const [keyword, setKeyword] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>(ALL_STATUS);
  const [typeFilter, setTypeFilter] = useState<string>(ALL_TYPE);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(DEFAULT_PAGE_SIZE);
  const [items, setItems] = useState<PricingRuleAdminItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [editing, setEditing] = useState<PricingRuleAdminItem | null>(null);

  const fetchList = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const params: PricingRuleAdminListParams = {
        page,
        pageSize,
        keyword: keyword.trim() || undefined,
        status:
          statusFilter === ALL_STATUS
            ? undefined
            : (statusFilter as BaseDataStatus),
        ruleType:
          typeFilter === ALL_TYPE
            ? undefined
            : (typeFilter as PricingRuleType),
      };
      const res: PricingRuleAdminListResponse =
        await listPricingRulesAdmin(params);
      setItems(res.items);
      setTotal(res.total);
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error('定价规则列表加载失败');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, keyword, statusFilter, typeFilter]);

  useEffect(() => {
    void fetchList();
  }, [fetchList]);

  const handleToggleStatus = async (
    record: PricingRuleAdminItem,
  ): Promise<void> => {
    const target: BaseDataStatus =
      record.status === 'active' ? 'disabled' : 'active';
    try {
      await updatePricingRuleStatus(record.id, { status: target });
      toast.success(target === 'disabled' ? '规则已停用' : '规则已启用');
      void fetchList();
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(getApiErrorMessage(error, '操作失败'));
    }
  };

  const columns: TableColumnsType<PricingRuleAdminItem> = [
    {
      title: '规则名称',
      dataIndex: 'name',
      width: 180,
      fixed: 'left',
      ellipsis: true,
    },
    {
      title: '规则类型',
      dataIndex: 'ruleType',
      width: 110,
      render: (ruleType: string) => {
        const meta = RULE_TYPE_META[ruleType] ?? {
          label: ruleType || '未知',
          className:
            'border-transparent bg-[hsl(216_12%_94%)] text-[hsl(216_15%_45%)]',
        };
        return <Badge className={meta.className}>{meta.label}</Badge>;
      },
    },
    { title: '产品', dataIndex: 'productName', width: 200 },
    {
      title: '定制项',
      dataIndex: 'customItemName',
      width: 160,
      render: (value: string | null) => value || '—',
    },
    {
      title: '加价金额',
      dataIndex: 'priceAdjustment',
      width: 140,
      align: 'right',
      render: (value: number) => (
        <span className="font-mono">{formatAmount(value)}</span>
      ),
    },
    {
      title: '条件',
      dataIndex: 'conditions',
      width: 200,
      render: (
        conditions: Record<string, string | number | boolean> | null,
      ) => (
        <span className="text-muted-foreground">
          {formatConditions(conditions)}
        </span>
      ),
    },
    {
      title: '优先级',
      dataIndex: 'priority',
      width: 90,
      align: 'center',
    },
    {
      title: '状态',
      dataIndex: 'status',
      width: 90,
      render: (status: BaseDataStatus) => (
        <MasterDataStatusBadge status={status} />
      ),
    },
    {
      title: '更新时间',
      dataIndex: 'updatedAt',
      width: 170,
      render: (value: string) => dayjs(value).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: '操作',
      key: 'action',
      fixed: 'right',
      width: 160,
      render: (_: unknown, record: PricingRuleAdminItem) => (
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setEditing(record);
              setDialogOpen(true);
            }}
          >
            编辑
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className={
              record.status === 'active'
                ? 'text-[hsl(0_65%_52%)]'
                : 'text-[hsl(152_60%_42%)]'
            }
            onClick={() => void handleToggleStatus(record)}
          >
            {record.status === 'active' ? '停用' : '启用'}
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="mx-auto max-w-[1400px] space-y-4 p-6">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative w-64">
          <Search className="absolute left-2.5 top-2.5 size-4 text-muted-foreground" />
          <Input
            className="pl-8"
            placeholder="搜索产品 / 定制项 / 描述"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === 'Enter') {
                setPage(1);
                void fetchList();
              }
            }}
          />
        </div>
        <Select
          value={typeFilter}
          onValueChange={(value: string) => {
            setTypeFilter(value);
            setPage(1);
          }}
        >
          <SelectTrigger className="w-36">
            <SelectValue placeholder="规则类型" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_TYPE}>全部类型</SelectItem>
            <SelectItem value="base_price">基础价</SelectItem>
            <SelectItem value="standard">普通加价</SelectItem>
            <SelectItem value="conditional">条件加价</SelectItem>
            <SelectItem value="package">套餐组合</SelectItem>
          </SelectContent>
        </Select>
        <Select
          value={statusFilter}
          onValueChange={(value: string) => {
            setStatusFilter(value);
            setPage(1);
          }}
        >
          <SelectTrigger className="w-32">
            <SelectValue placeholder="状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_STATUS}>全部状态</SelectItem>
            <SelectItem value="active">启用</SelectItem>
            <SelectItem value="disabled">停用</SelectItem>
          </SelectContent>
        </Select>
        <Button
          className="ml-auto"
          data-ai-section-type="button"
          onClick={() => {
            setEditing(null);
            setDialogOpen(true);
          }}
        >
          <Plus className="mr-2 size-4" />
          新增定价规则
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table
            columns={columns}
            dataSource={items}
            loading={loading}
            rowKey="id"
            scroll={{ x: 1500, y: 500 }}
            pagination={{
              current: page,
              pageSize,
              total,
              showSizeChanger: true,
              onChange: (nextPage: number, nextPageSize: number) => {
                setPage(nextPage);
                setPageSize(nextPageSize);
              },
            }}
            locale={{
              emptyText: (
                <Empty>
                  <EmptyHeader>
                    <EmptyMedia variant="icon">
                      <BadgePercent className="size-6" />
                    </EmptyMedia>
                    <EmptyTitle>暂无定价规则</EmptyTitle>
                    <EmptyDescription>
                      调整筛选条件，或点击「新增定价规则」创建第一条规则
                    </EmptyDescription>
                  </EmptyHeader>
                </Empty>
              ),
            }}
          />
        </CardContent>
      </Card>

      <MasterPricingRuleDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        editing={editing}
        onSaved={() => {
          void fetchList();
        }}
      />
    </div>
  );
};

export default MasterPricingRulesPage;
