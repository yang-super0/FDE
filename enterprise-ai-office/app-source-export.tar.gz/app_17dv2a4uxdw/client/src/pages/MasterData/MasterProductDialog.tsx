import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Trash2 } from 'lucide-react';
import type { ProductAdminItem } from '@shared/api.interface';
import {
  createProduct,
  updateProduct,
} from '@client/src/api/master-data';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import { getApiErrorMessage } from './MasterDataShared';

interface SpecRow {
  key: string;
  value: string;
}

interface MasterProductDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editing: ProductAdminItem | null;
  onSaved: () => void;
}

const MasterProductDialog: React.FC<MasterProductDialogProps> = ({
  open,
  onOpenChange,
  editing,
  onSaved,
}) => {
  const [productCode, setProductCode] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [category, setCategory] = useState<string>('');
  const [basePrice, setBasePrice] = useState<string>('');
  const [specRows, setSpecRows] = useState<SpecRow[]>([]);
  const [description, setDescription] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (!open) {
      return;
    }
    if (editing) {
      setProductCode(editing.productCode);
      setName(editing.name);
      setCategory(editing.category ?? '');
      setBasePrice(String(editing.basePrice));
      setDescription(editing.description ?? '');
      const entries: SpecRow[] = editing.spec
        ? Object.entries(editing.spec).map(([key, value]) => ({
            key,
            value: String(value),
          }))
        : [];
      setSpecRows(entries);
    } else {
      setProductCode('');
      setName('');
      setCategory('');
      setBasePrice('');
      setSpecRows([]);
      setDescription('');
    }
  }, [open, editing]);

  const handleSubmit = async (): Promise<void> => {
    if (!productCode.trim() || !name.trim()) {
      toast.error('请填写产品编码和名称');
      return;
    }
    const price: number = Number(basePrice);
    if (!Number.isFinite(price) || price < 0) {
      toast.error('请填写有效的基础价');
      return;
    }
    const spec: Record<string, string> = {};
    for (const row of specRows) {
      if (row.key.trim()) {
        spec[row.key.trim()] = row.value;
      }
    }

    setSubmitting(true);
    try {
      if (editing) {
        await updateProduct(editing.id, {
          productCode: productCode.trim(),
          name: name.trim(),
          category: category.trim() || undefined,
          basePrice: price,
          spec,
          description: description || undefined,
        });
        toast.success('产品已更新');
      } else {
        await createProduct({
          productCode: productCode.trim(),
          name: name.trim(),
          category: category.trim() || undefined,
          basePrice: price,
          spec: Object.keys(spec).length > 0 ? spec : undefined,
          description: description || undefined,
        });
        toast.success('产品已创建');
      }
      onOpenChange(false);
      onSaved();
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(getApiErrorMessage(error, '保存失败'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{editing ? '编辑产品' : '新增产品'}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="text-sm font-medium">产品编码 *</div>
              <Input
                value={productCode}
                onChange={(e) => setProductCode(e.target.value)}
                placeholder="如 FZQ-20"
              />
            </div>
            <div className="space-y-1.5">
              <div className="text-sm font-medium">产品名称 *</div>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="产品名称"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="text-sm font-medium">产品分类</div>
              <Input
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="如 防撞墙台车"
              />
            </div>
            <div className="space-y-1.5">
              <div className="text-sm font-medium">基础价（元）*</div>
              <Input
                value={basePrice}
                onChange={(e) => setBasePrice(e.target.value)}
                placeholder="0.00"
                inputMode="decimal"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium">规格参数（spec）</div>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() =>
                  setSpecRows((rows: SpecRow[]) => [
                    ...rows,
                    { key: '', value: '' },
                  ])
                }
              >
                添加参数
              </Button>
            </div>
            {specRows.length === 0 ? (
              <div className="rounded-lg border border-dashed p-3 text-center text-xs text-muted-foreground">
                暂无规格参数，可添加键值对（如 span: 12m）
              </div>
            ) : (
              <div className="space-y-2">
                {specRows.map((row: SpecRow, index: number) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      className="flex-1"
                      value={row.key}
                      placeholder="参数名"
                      onChange={(e) =>
                        setSpecRows((rows: SpecRow[]) =>
                          rows.map((r: SpecRow, i: number) =>
                            i === index ? { ...r, key: e.target.value } : r,
                          ),
                        )
                      }
                    />
                    <Input
                      className="flex-1"
                      value={row.value}
                      placeholder="参数值"
                      onChange={(e) =>
                        setSpecRows((rows: SpecRow[]) =>
                          rows.map((r: SpecRow, i: number) =>
                            i === index ? { ...r, value: e.target.value } : r,
                          ),
                        )
                      }
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() =>
                        setSpecRows((rows: SpecRow[]) =>
                          rows.filter((_: SpecRow, i: number) => i !== index),
                        )
                      }
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="space-y-1.5">
            <div className="text-sm font-medium">描述</div>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="产品描述"
              rows={3}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={() => void handleSubmit()} disabled={submitting}>
            {submitting ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default MasterProductDialog;
