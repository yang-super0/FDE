import type { PricingRuleType } from '@shared/api.interface';

export interface ProductOption {
  id: string;
  name: string;
  productCode: string;
}

export interface CustomItemOption {
  id: string;
  name: string;
}

export interface SceneOption {
  value: string;
  label: string;
  conditions: Record<string, string | number | boolean> | null;
}

export const RULE_TYPE_OPTIONS: Array<{
  value: PricingRuleType;
  label: string;
}> = [
  { value: 'base_price', label: '基础价' },
  { value: 'standard', label: '普通加价' },
  { value: 'conditional', label: '条件加价' },
  { value: 'package', label: '套餐组合' },
];

export const SCENE_COASTAL: string = 'coastal';
export const SCENE_EXPRESSWAY: string = 'expressway';
export const SCENE_CUSTOM: string = 'custom';

export const SCENE_OPTIONS: SceneOption[] = [
  {
    value: SCENE_COASTAL,
    label: '沿海项目（项目场景=沿海）',
    conditions: { project_environment: 'coastal', required: true },
  },
  {
    value: SCENE_EXPRESSWAY,
    label: '高速项目（道路类型=高速）',
    conditions: { road_type: 'expressway', required: true },
  },
];

export function detectScene(
  conditions: Record<string, string | number | boolean> | null,
): string {
  if (!conditions) {
    return SCENE_CUSTOM;
  }
  if (conditions.project_environment === 'coastal') {
    return SCENE_COASTAL;
  }
  if (conditions.road_type === 'expressway') {
    return SCENE_EXPRESSWAY;
  }
  return SCENE_CUSTOM;
}
