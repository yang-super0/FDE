import React, { useState } from 'react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type {
  PricingRuleAdminItem,
  PricingRuleType,
} from '@shared/api.interface';
import {
  createPricingRule,
  updatePricingRule,
} from '@client/src/api/master-data';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { getApiErrorMessage } from './MasterDataShared';
import MasterRuleConditionField from './MasterRuleConditionField';
import {
  RULE_TYPE_OPTIONS,
  SCENE_CUSTOM,
  SCENE_OPTIONS,
  type CustomItemOption,
  type ProductOption,
  type SceneOption,
} from './master-pricing-rule-config';
import { usePricingRuleForm } from './usePricingRuleForm';

interface MasterPricingRuleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editing: PricingRuleAdminItem | null;
  onSaved: () => void;
}

const MasterPricingRuleDialog: React.FC<MasterPricingRuleDialogProps> = ({
  open,
  onOpenChange,
  editing,
  onSaved,
}) => {
  const form = usePricingRuleForm({ open, editing });
  const [submitting, setSubmitting] = useState<boolean>(false);

  const buildConditions = ():
    | { ok: true; conditions: Record<string, string | number | boolean> | null }
    | { ok: false } => {
    if (form.ruleType !== 'conditional') {
      return { ok: true, conditions: null };
    }
    if (form.scene === SCENE_CUSTOM) {
      if (!form.customConditionsText.trim()) {
        toast.error('请填写条件 JSON');
        return { ok: false };
      }
      try {
        const parsed: unknown = JSON.parse(form.customConditionsText);
        if (
          parsed === null ||
          typeof parsed !== 'object' ||
          Array.isArray(parsed)
        ) {
          toast.error('条件必须是 JSON 对象');
          return { ok: false };
        }
        return {
          ok: true,
          conditions: parsed as Record<string, string | number | boolean>,
        };
      } catch {
        toast.error('条件 JSON 格式不正确');
        return { ok: false };
      }
    }
    const option: SceneOption | undefined = SCENE_OPTIONS.find(
      (o: SceneOption) => o.value === form.scene,
    );
    return { ok: true, conditions: option?.conditions ?? null };
  };

  const handleSubmit = async (): Promise<void> => {
    if (!form.name.trim()) {
      toast.error('请输入规则名称');
      return;
    }
    if (!form.productId) {
      toast.error('请选择产品');
      return;
    }
    if (
      form.ruleType !== 'package' &&
      form.ruleType !== 'base_price' &&
      !form.customItemId
    ) {
      toast.error('该规则类型必须选择定制项');
      return;
    }
    const price: number = Number(form.priceAdjustment);
    if (!Number.isFinite(price)) {
      toast.error('请填写有效的加价金额');
      return;
    }
    const priorityValue: number = Number(form.priority);
    if (!Number.isFinite(priorityValue) || priorityValue < 0) {
      toast.error('请填写有效的优先级');
      return;
    }
    const built = buildConditions();
    if (!built.ok) {
      return;
    }

    const customItemIdValue: string | null =
      form.ruleType === 'base_price' ? null : form.customItemId || null;
    setSubmitting(true);
    try {
      if (editing) {
        await updatePricingRule(editing.id, {
          name: form.name.trim(),
          productId: form.productId,
          customItemId: customItemIdValue,
          ruleType: form.ruleType,
          priceAdjustment: price,
          conditions: built.conditions,
          priority: priorityValue,
          description: form.description || undefined,
        });
        toast.success('定价规则已更新');
      } else {
        await createPricingRule({
          name: form.name.trim(),
          productId: form.productId,
          customItemId: customItemIdValue ?? undefined,
          ruleType: form.ruleType,
          priceAdjustment: price,
          conditions: built.conditions ?? undefined,
          priority: priorityValue,
          description: form.description || undefined,
        });
        toast.success('定价规则已创建');
      }
      onOpenChange(false);
      onSaved();
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(getApiErrorMessage(error, '保存失败'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {editing ? '编辑定价规则' : '新增定价规则'}
          </DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="space-y-1.5">
            <div className="text-sm font-medium">规则名称 *</div>
            <Input
              value={form.name}
              onChange={(e) => form.setName(e.target.value)}
              placeholder="请输入规则名称，如：FZQ-12加长1米加价"
              maxLength={200}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="text-sm font-medium">规则类型 *</div>
              <Select
                value={form.ruleType}
                onValueChange={(value: string) =>
                  form.setRuleType(value as PricingRuleType)
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="选择规则类型" />
                </SelectTrigger>
                <SelectContent>
                  {RULE_TYPE_OPTIONS.map(
                    (option: { value: PricingRuleType; label: string }) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ),
                  )}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <div className="text-sm font-medium">产品 *</div>
              <Select value={form.productId} onValueChange={form.setProductId}>
                <SelectTrigger>
                  <SelectValue placeholder="选择产品（仅启用）" />
                </SelectTrigger>
                <SelectContent>
                  {form.productOptions.map((option: ProductOption) => (
                    <SelectItem key={option.id} value={option.id}>
                      {option.name}（{option.productCode}）
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="text-sm font-medium">
                定制项
                {form.ruleType === 'package' || form.ruleType === 'base_price'
                  ? ''
                  : ' *'}
              </div>
              {form.ruleType === 'base_price' ? (
                <div className="flex h-9 items-center rounded-md border border-dashed border-border px-3 text-xs text-muted-foreground">
                  基础价规则不需要关联定制项
                </div>
              ) : (
                <Select
                  value={form.customItemId || undefined}
                  onValueChange={form.setCustomItemId}
                >
                  <SelectTrigger>
                    <SelectValue
                      placeholder={
                        form.ruleType === 'package'
                          ? '可选（套餐可不选）'
                          : '选择定制项（仅启用）'
                      }
                    />
                  </SelectTrigger>
                  <SelectContent>
                    {form.itemOptions.map((option: CustomItemOption) => (
                      <SelectItem key={option.id} value={option.id}>
                        {option.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
            <div className="space-y-1.5">
              <div className="text-sm font-medium">
                {form.ruleType === 'package'
                  ? '套餐价调整（元）*'
                  : '加价金额（元）*'}
              </div>
              <Input
                value={form.priceAdjustment}
                onChange={(e) => form.setPriceAdjustment(e.target.value)}
                placeholder="0.00"
                inputMode="decimal"
              />
            </div>
          </div>
          {form.ruleType === 'conditional' ? (
            <MasterRuleConditionField
              scene={form.scene}
              onSceneChange={form.setScene}
              customConditionsText={form.customConditionsText}
              onCustomConditionsTextChange={form.setCustomConditionsText}
            />
          ) : null}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="text-sm font-medium">优先级 *</div>
              <Input
                value={form.priority}
                onChange={(e) => form.setPriority(e.target.value)}
                placeholder="0"
                inputMode="numeric"
              />
            </div>
            <div className="space-y-1.5">
              <div className="text-sm font-medium">描述</div>
              <Input
                value={form.description}
                onChange={(e) => form.setDescription(e.target.value)}
                placeholder="规则说明"
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={() => void handleSubmit()} disabled={submitting}>
            {submitting ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default MasterPricingRuleDialog;
