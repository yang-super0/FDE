import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type {
  PricingRuleAdminItem,
  PricingRuleType,
} from '@shared/api.interface';
import { listCustomItemOptions } from '@client/src/api/master-data';
import { listProducts } from '@client/src/api/products';
import {
  detectScene,
  SCENE_COASTAL,
  SCENE_CUSTOM,
  type CustomItemOption,
  type ProductOption,
} from './master-pricing-rule-config';

interface UsePricingRuleFormOptions {
  open: boolean;
  editing: PricingRuleAdminItem | null;
}

export function usePricingRuleForm(options: UsePricingRuleFormOptions) {
  const { open, editing } = options;
  const [name, setName] = useState<string>('');
  const [ruleType, setRuleType] = useState<PricingRuleType>('standard');
  const [productId, setProductId] = useState<string>('');
  const [customItemId, setCustomItemId] = useState<string>('');
  const [priceAdjustment, setPriceAdjustment] = useState<string>('');
  const [priority, setPriority] = useState<string>('0');
  const [description, setDescription] = useState<string>('');
  const [scene, setScene] = useState<string>(SCENE_COASTAL);
  const [customConditionsText, setCustomConditionsText] = useState<string>('');
  const [productOptions, setProductOptions] = useState<ProductOption[]>([]);
  const [itemOptions, setItemOptions] = useState<CustomItemOption[]>([]);

  useEffect(() => {
    if (!open) {
      return;
    }
    void (async () => {
      try {
        const [productsRes, itemsRes] = await Promise.all([
          listProducts(),
          listCustomItemOptions(),
        ]);
        setProductOptions(productsRes.items);
        setItemOptions(itemsRes.items);
      } catch (error: unknown) {
        logger.error(String(error));
        toast.error('下拉选项加载失败');
      }
    })();
    if (editing) {
      setName(editing.name);
      setRuleType(editing.ruleType);
      setProductId(editing.productId);
      setCustomItemId(editing.customItemId ?? '');
      setPriceAdjustment(String(editing.priceAdjustment));
      setPriority(String(editing.priority));
      setDescription(editing.description ?? '');
      const detected: string = detectScene(editing.conditions);
      setScene(detected);
      setCustomConditionsText(
        detected === SCENE_CUSTOM && editing.conditions
          ? JSON.stringify(editing.conditions, null, 2)
          : '',
      );
    } else {
      setName('');
      setRuleType('standard');
      setProductId('');
      setCustomItemId('');
      setPriceAdjustment('');
      setPriority('0');
      setDescription('');
      setScene(SCENE_COASTAL);
      setCustomConditionsText('');
    }
  }, [open, editing]);

  return {
    name,
    setName,
    ruleType,
    setRuleType,
    productId,
    setProductId,
    customItemId,
    setCustomItemId,
    priceAdjustment,
    setPriceAdjustment,
    priority,
    setPriority,
    description,
    setDescription,
    scene,
    setScene,
    customConditionsText,
    setCustomConditionsText,
    productOptions,
    itemOptions,
  };
}
