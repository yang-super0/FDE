import React, { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type {
  CustomCategoryNode,
  CustomCategoryOption,
  CustomCategoryOptionsResponse,
} from '@shared/api.interface';
import {
  createCategory,
  listCategoryOptions,
  updateCategory,
} from '@client/src/api/master-data';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { getApiErrorMessage } from './MasterDataShared';

const NONE_PARENT: string = '__none__';

interface MasterCategoryDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editing: CustomCategoryNode | null;
  defaultParentId?: string;
  onSaved: () => void;
}

const MasterCategoryDialog: React.FC<MasterCategoryDialogProps> = ({
  open,
  onOpenChange,
  editing,
  defaultParentId,
  onSaved,
}) => {
  const [name, setName] = useState<string>('');
  const [parentId, setParentId] = useState<string>(NONE_PARENT);
  const [sortOrder, setSortOrder] = useState<string>('0');
  const [options, setOptions] = useState<CustomCategoryOption[]>([]);
  const [submitting, setSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (!open) {
      return;
    }
    if (editing) {
      setName(editing.name);
      setParentId(editing.parentId ?? NONE_PARENT);
      setSortOrder(String(editing.sortOrder));
    } else {
      setName('');
      setParentId(defaultParentId ?? NONE_PARENT);
      setSortOrder('0');
    }
    const loadOptions = async (): Promise<void> => {
      try {
        const res: CustomCategoryOptionsResponse =
          await listCategoryOptions();
        setOptions(res.items);
      } catch (error: unknown) {
        logger.error(String(error));
        toast.error(getApiErrorMessage(error, '上级分类加载失败'));
      }
    };
    void loadOptions();
  }, [open, editing, defaultParentId]);

  const visibleOptions: CustomCategoryOption[] = editing
    ? options.filter((option: CustomCategoryOption) => option.id !== editing.id)
    : options;

  const handleSubmit = async (): Promise<void> => {
    if (!name.trim()) {
      toast.error('请填写分类名称');
      return;
    }
    const order: number = Number(sortOrder);
    if (!Number.isFinite(order)) {
      toast.error('请填写有效的排序号');
      return;
    }

    setSubmitting(true);
    try {
      if (editing) {
        await updateCategory(editing.id, {
          name: name.trim(),
          parentId: parentId === NONE_PARENT ? null : parentId,
          sortOrder: order,
        });
        toast.success('分类已更新');
      } else {
        await createCategory({
          name: name.trim(),
          parentId: parentId === NONE_PARENT ? undefined : parentId,
          sortOrder: order,
        });
        toast.success('分类已创建');
      }
      onOpenChange(false);
      onSaved();
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(getApiErrorMessage(error, '保存失败'));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{editing ? '编辑分类' : '新增分类'}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="space-y-1.5">
            <div className="text-sm font-medium">分类名称 *</div>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="如 尺寸规格"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="text-sm font-medium">上级分类</div>
              <Select value={parentId} onValueChange={setParentId}>
                <SelectTrigger>
                  <SelectValue placeholder="请选择上级分类" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={NONE_PARENT}>无（顶级分类）</SelectItem>
                  {visibleOptions.map((option: CustomCategoryOption) => (
                    <SelectItem key={option.id} value={option.id}>
                      {option.fullName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <div className="text-sm font-medium">排序号</div>
              <Input
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value)}
                placeholder="0"
                inputMode="numeric"
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button onClick={() => void handleSubmit()} disabled={submitting}>
            {submitting ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default MasterCategoryDialog;
