import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Pencil, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Card } from '@client/src/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { Progress } from '@client/src/components/ui/progress';
import { Input } from '@client/src/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { UserDisplay } from '@client/src/components/business-ui/user-display';
import { UserSelect } from '@client/src/components/business-ui/user-select';
import {
  addProjectMembers,
  fetchProjectDetail,
  updateProject,
  updateProjectStatus,
} from '@client/src/api/projects';
import type { ProjectDetail, ProjectStatus } from '@shared/api.interface';
import {
  PROJECT_STATUS_META,
  PROJECT_STATUS_OPTIONS,
} from './projectStatusMeta';
import { ProjectTaskSection } from './ProjectDetailPageComponentA';
import { CustomerPicker } from './CustomerPicker';

interface AddMembersDialogProps {
  projectId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAdded: () => void;
}

const AddMembersDialog: React.FC<AddMembersDialogProps> = ({
  projectId,
  open,
  onOpenChange,
  onAdded,
}) => {
  const [memberIds, setMemberIds] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (open) {
      setMemberIds([]);
    }
  }, [open]);

  const handleSubmit = async (): Promise<void> => {
    if (memberIds.length === 0) {
      toast.error('请先选择要添加的成员');
      return;
    }
    setSubmitting(true);
    try {
      await addProjectMembers(projectId, { memberIds });
      toast.success('成员添加成功');
      onOpenChange(false);
      onAdded();
    } catch {
      toast.error('成员添加失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl rounded-xl shadow-lg">
        <DialogHeader>
          <DialogTitle>添加成员</DialogTitle>
          <DialogDescription>
            搜索并选择要加入项目的成员，已在项目中的成员会自动跳过
          </DialogDescription>
        </DialogHeader>
        <UserSelect
          multiple
          value={memberIds}
          onChange={(value: string[]) => setMemberIds(value)}
          placeholder="请选择成员"
        />
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button disabled={submitting} onClick={() => void handleSubmit()}>
            {submitting ? '添加中...' : '确认添加'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

interface CustomerEditDialogProps {
  projectId: string;
  open: boolean;
  initialCustomerId: string | null;
  onOpenChange: (open: boolean) => void;
  onUpdated: () => void;
}

const CustomerEditDialog: React.FC<CustomerEditDialogProps> = ({
  projectId,
  open,
  initialCustomerId,
  onOpenChange,
  onUpdated,
}) => {
  const [customerId, setCustomerId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (open) {
      setCustomerId(initialCustomerId);
    }
  }, [open, initialCustomerId]);

  const handleSubmit = async (): Promise<void> => {
    setSubmitting(true);
    try {
      await updateProject(projectId, { customerId });
      toast.success(customerId ? '关联客户已更新' : '已清除关联客户');
      onOpenChange(false);
      onUpdated();
    } catch {
      toast.error('关联客户更新失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl rounded-xl shadow-lg">
        <DialogHeader>
          <DialogTitle>编辑关联客户</DialogTitle>
          <DialogDescription>
            搜索并选择要关联的客户，选择「清除关联」可解除关联
          </DialogDescription>
        </DialogHeader>
        <CustomerPicker
          value={customerId}
          onChange={setCustomerId}
          placeholder="请选择关联客户（可搜索）"
          allowClear
        />
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button disabled={submitting} onClick={() => void handleSubmit()}>
            {submitting ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

interface ProgressEditDialogProps {
  projectId: string;
  open: boolean;
  initialProgress: number;
  onOpenChange: (open: boolean) => void;
  onUpdated: () => void;
}

const ProgressEditDialog: React.FC<ProgressEditDialogProps> = ({
  projectId,
  open,
  initialProgress,
  onOpenChange,
  onUpdated,
}) => {
  const [value, setValue] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  useEffect(() => {
    if (open) {
      setValue(String(initialProgress));
      setError('');
    }
  }, [open, initialProgress]);

  const handleSubmit = async (): Promise<void> => {
    const trimmed: string = value.trim();
    const parsed: number = Number(trimmed);
    if (trimmed === '' || !Number.isInteger(parsed)) {
      setError('请输入整数');
      return;
    }
    if (parsed < 0 || parsed > 100) {
      setError('进度范围为 0-100');
      return;
    }
    setSubmitting(true);
    try {
      await updateProject(projectId, { progress: parsed });
      toast.success('项目进度已更新');
      onOpenChange(false);
      onUpdated();
    } catch {
      toast.error('进度更新失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl rounded-xl shadow-lg">
        <DialogHeader>
          <DialogTitle>更新进度</DialogTitle>
          <DialogDescription>
            输入项目当前进度（0-100 的整数），任务完成情况不会自动影响项目进度
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Input
              type="number"
              min={0}
              max={100}
              step={1}
              value={value}
              onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
                setValue(event.target.value);
                setError('');
              }}
              className="w-32"
            />
            <span className="text-sm text-muted-foreground">%</span>
          </div>
          {error ? (
            <p className="text-xs text-destructive">{error}</p>
          ) : null}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            取消
          </Button>
          <Button disabled={submitting} onClick={() => void handleSubmit()}>
            {submitting ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

const ProjectDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [detail, setDetail] = useState<ProjectDetail | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [addMembersOpen, setAddMembersOpen] = useState<boolean>(false);
  const [customerEditOpen, setCustomerEditOpen] = useState<boolean>(false);
  const [progressEditOpen, setProgressEditOpen] = useState<boolean>(false);

  const loadDetail = useCallback(async (): Promise<void> => {
    if (!id) {
      return;
    }
    try {
      const data: ProjectDetail = await fetchProjectDetail(id);
      setDetail(data);
    } catch {
      toast.error('项目详情加载失败');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    void loadDetail();
  }, [loadDetail]);

  const handleStatusChange = async (status: ProjectStatus): Promise<void> => {
    if (!id || !detail) {
      return;
    }
    try {
      await updateProjectStatus(id, { status });
      toast.success('项目阶段已更新');
      await loadDetail();
    } catch {
      toast.error('阶段更新失败，请重试');
    }
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-[1400px] p-6 text-sm text-muted-foreground">
        加载中...
      </div>
    );
  }

  if (!detail || !id) {
    return (
      <div className="mx-auto max-w-[1400px] space-y-4 p-6">
        <Button variant="ghost" onClick={() => navigate('/projects')}>
          <ArrowLeft className="mr-1 h-4 w-4" />
          返回项目列表
        </Button>
        <Card className="p-6 text-sm text-muted-foreground">
          项目不存在或已被删除
        </Card>
      </div>
    );
  }

  const statusMeta = PROJECT_STATUS_META[detail.status];
  const memberIds: string[] = detail.members.map(
    (member) => member.userId,
  );

  return (
    <div className="mx-auto max-w-[1400px] space-y-4 p-6">
      <div className="flex flex-wrap items-center gap-3">
        <Button variant="ghost" size="sm" onClick={() => navigate('/projects')}>
          <ArrowLeft className="mr-1 h-4 w-4" />
          返回
        </Button>
        <h1 className="truncate text-xl font-bold">{detail.name}</h1>
        <Badge variant="outline" className={statusMeta.badgeClass}>
          {statusMeta.label}
        </Badge>
      </div>

      <Card className="p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0 flex-1 space-y-3">
            <div className="grid grid-cols-1 gap-x-8 gap-y-2 text-sm sm:grid-cols-2 lg:grid-cols-3">
              <div>
                <span className="text-muted-foreground">负责人：</span>
                <span className="font-medium">{detail.ownerName}</span>
              </div>
              <div>
                <span className="text-muted-foreground">起止日期：</span>
                <span className="font-mono">
                  {detail.startDate} ~ {detail.endDate}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">进度：</span>
                <Progress value={detail.progress} className="w-32" />
                <span className="font-mono text-xs text-muted-foreground">
                  {detail.progress}%
                </span>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  data-ai-section-type="button"
                  onClick={() => setProgressEditOpen(true)}
                >
                  更新进度
                </Button>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">关联客户：</span>
                {detail.customerId && detail.customerName ? (
                  <button
                    type="button"
                    className="font-medium text-primary hover:underline"
                    onClick={() => navigate(`/customers/${detail.customerId}`)}
                  >
                    {detail.customerName}
                  </button>
                ) : (
                  <span className="text-muted-foreground">未关联</span>
                )}
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="size-6"
                  data-ai-section-type="button"
                  onClick={() => setCustomerEditOpen(true)}
                >
                  <Pencil className="size-3.5" />
                </Button>
              </div>
            </div>
            <div className="text-sm">
              <span className="text-muted-foreground">项目说明：</span>
              <span className="break-words">
                {detail.description || '暂无说明'}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">项目阶段</span>
            <Select
              value={detail.status}
              onValueChange={(value: string) =>
                void handleStatusChange(value as ProjectStatus)
              }
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PROJECT_STATUS_OPTIONS.map((status: ProjectStatus) => (
                  <SelectItem key={status} value={status}>
                    {PROJECT_STATUS_META[status].label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </Card>

      <ProjectTaskSection
        projectId={id}
        members={detail.members}
        onProgressChanged={loadDetail}
      />

      <Card className="p-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h3 className="text-base font-semibold">
            项目成员
            <span className="ml-2 font-mono text-sm text-muted-foreground">
              {detail.members.length}
            </span>
          </h3>
          <Button
            variant="outline"
            size="sm"
            data-ai-section-type="button"
            onClick={() => setAddMembersOpen(true)}
          >
            <UserPlus className="mr-1 h-4 w-4" />
            添加成员
          </Button>
        </div>
        {memberIds.length > 0 ? (
          <UserDisplay value={memberIds} size="medium" />
        ) : (
          <p className="text-sm text-muted-foreground">暂无成员</p>
        )}
      </Card>

      <AddMembersDialog
        projectId={id}
        open={addMembersOpen}
        onOpenChange={setAddMembersOpen}
        onAdded={() => void loadDetail()}
      />

      <CustomerEditDialog
        projectId={id}
        open={customerEditOpen}
        initialCustomerId={detail.customerId}
        onOpenChange={setCustomerEditOpen}
        onUpdated={() => void loadDetail()}
      />

      <ProgressEditDialog
        projectId={id}
        open={progressEditOpen}
        initialProgress={detail.progress}
        onOpenChange={setProgressEditOpen}
        onUpdated={() => void loadDetail()}
      />
    </div>
  );
};

export default ProjectDetailPage;
