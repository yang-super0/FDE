import React from 'react';
import dayjs from 'dayjs';
import { Calendar as CalendarIcon } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import { Calendar } from '@client/src/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { cn } from '@client/src/lib/utils';

interface ProjectDateFieldProps {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
}

/** 日期选择：Calendar + Popover，对外值为 YYYY-MM-DD 字符串 */
export const ProjectDateField: React.FC<ProjectDateFieldProps> = ({
  value,
  onChange,
  placeholder,
}) => {
  const selected: Date | undefined = value ? dayjs(value).toDate() : undefined;
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          className={cn(
            'w-full justify-start text-left font-normal',
            !value && 'text-muted-foreground',
          )}
        >
          <CalendarIcon className="mr-2 h-4 w-4" />
          {value || placeholder}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={selected}
          onSelect={(date: Date | undefined) =>
            onChange(date ? dayjs(date).format('YYYY-MM-DD') : '')
          }
        />
      </PopoverContent>
    </Popover>
  );
};
