import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { toast } from 'sonner';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import { Input } from '@client/src/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { createProjectTask } from '@client/src/api/projects';
import type {
  CreateProjectTaskRequest,
  ProjectMemberInfo,
} from '@shared/api.interface';
import { ProjectDateField } from './ProjectDateField';

const createTaskSchema = z.object({
  taskName: z.string().min(1, '请输入任务名称'),
  assigneeId: z.string().min(1, '请选择负责人'),
  dueDate: z.string().min(1, '请选择截止日期'),
});

type CreateTaskFormData = z.infer<typeof createTaskSchema>;

interface CreateTaskDialogProps {
  projectId: string;
  members: ProjectMemberInfo[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => void;
}

export const CreateTaskDialog: React.FC<CreateTaskDialogProps> = ({
  projectId,
  members,
  open,
  onOpenChange,
  onCreated,
}) => {
  const [submitting, setSubmitting] = useState<boolean>(false);
  const form = useForm<CreateTaskFormData>({
    resolver: zodResolver(createTaskSchema),
    defaultValues: { taskName: '', assigneeId: '', dueDate: '' },
  });

  const handleOpenChange = (nextOpen: boolean): void => {
    if (!nextOpen) {
      form.reset();
    }
    onOpenChange(nextOpen);
  };

  const handleSubmit = async (data: CreateTaskFormData): Promise<void> => {
    setSubmitting(true);
    try {
      const payload: CreateProjectTaskRequest = {
        taskName: data.taskName.trim(),
        assigneeId: data.assigneeId,
        dueDate: data.dueDate,
      };
      await createProjectTask(projectId, payload);
      toast.success('任务创建成功');
      form.reset();
      onOpenChange(false);
      onCreated();
    } catch {
      toast.error('任务创建失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-2xl rounded-xl shadow-lg">
        <DialogHeader>
          <DialogTitle>新建任务</DialogTitle>
          <DialogDescription>负责人需从项目成员中选择</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit((data) => void handleSubmit(data))}
            className="space-y-4"
          >
            <FormField
              control={form.control}
              name="taskName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    任务名称 <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="请输入任务名称" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex flex-wrap gap-4">
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>
                      截止日期 <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <ProjectDateField
                        value={field.value}
                        onChange={field.onChange}
                        placeholder="请选择截止日期"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="assigneeId"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>
                      负责人 <span className="text-destructive">*</span>
                    </FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      value={field.value || undefined}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="请选择负责人" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {members.map((member: ProjectMemberInfo) => (
                          <SelectItem key={member.userId} value={member.userId}>
                            {member.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
              >
                取消
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? '创建中...' : '创建任务'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};
