import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Table,
  type TableColumnsType,
} from '@lark-apaas/client-toolkit/antd-table';
import { Plus } from 'lucide-react';
import dayjs from 'dayjs';
import { toast } from 'sonner';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Card } from '@client/src/components/ui/card';
import { Progress } from '@client/src/components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { fetchProjects } from '@client/src/api/projects';
import type {
  ProjectListItem,
  ProjectStatus,
} from '@shared/api.interface';
import {
  PROJECT_STATUS_META,
  PROJECT_STATUS_OPTIONS,
} from './projectStatusMeta';
import { CreateProjectDialog } from './ProjectsPageComponentA';

type StatusFilter = ProjectStatus | 'all';

const NEARING_DUE_DAYS: number = 7;
const NEARING_DUE_PROGRESS: number = 80;

const getDelayTag = (
  record: ProjectListItem
): 'overdue' | 'nearing' | null => {
  if (record.status === 'completed') {
    return null;
  }
  const today: string = dayjs().format('YYYY-MM-DD');
  if (record.endDate < today) {
    return 'overdue';
  }
  if (
    dayjs(record.endDate).diff(dayjs(today), 'day') <= NEARING_DUE_DAYS &&
    record.progress < NEARING_DUE_PROGRESS
  ) {
    return 'nearing';
  }
  return null;
};

const ProjectsPage: React.FC = () => {
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [items, setItems] = useState<ProjectListItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [createOpen, setCreateOpen] = useState<boolean>(false);

  const loadData = useCallback(async (status?: ProjectStatus) => {
    setLoading(true);
    try {
      const res = await fetchProjects(status ? { status } : {});
      setItems(res.items);
      setTotal(res.total);
    } catch {
      toast.error('项目列表加载失败');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadData(statusFilter === 'all' ? undefined : statusFilter);
  }, [statusFilter, loadData]);

  const columns: TableColumnsType<ProjectListItem> = [
    {
      title: '项目名称',
      dataIndex: 'name',
      key: 'name',
      fixed: 'left',
      width: 240,
      render: (name: string, record: ProjectListItem) => (
        <Link
          to={`/projects/${record.id}`}
          className="font-medium text-primary hover:underline"
        >
          {name}
        </Link>
      ),
    },
    { title: '负责人', dataIndex: 'ownerName', key: 'ownerName', width: 120 },
    {
      title: '关联客户',
      dataIndex: 'customerName',
      key: 'customerName',
      width: 220,
      render: (name: string | null, record: ProjectListItem) =>
        name && record.customerId ? (
          <Link
            to={`/customers/${record.customerId}`}
            className="text-primary hover:underline"
          >
            {name}
          </Link>
        ) : (
          <span className="text-muted-foreground">-</span>
        ),
    },
    { title: '开始日期', dataIndex: 'startDate', key: 'startDate', width: 130 },
    { title: '结束日期', dataIndex: 'endDate', key: 'endDate', width: 130 },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 110,
      render: (status: ProjectStatus, record: ProjectListItem) => {
        const meta = PROJECT_STATUS_META[status];
        const delayTag = getDelayTag(record);
        return (
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={meta.badgeClass}>
              {meta.label}
            </Badge>
            {delayTag === 'overdue' ? (
              <Badge className="bg-[hsl(0_60%_96%)] text-[hsl(0_65%_52%)]">
                已延期
              </Badge>
            ) : null}
            {delayTag === 'nearing' ? (
              <Badge className="bg-[hsl(38_80%_96%)] text-[hsl(38_85%_48%)]">
                即将延期
              </Badge>
            ) : null}
          </div>
        );
      },
    },
    {
      title: '进度',
      dataIndex: 'progress',
      key: 'progress',
      width: 200,
      render: (progress: number) => (
        <div className="flex items-center gap-2">
          <Progress value={progress} className="w-32" />
          <span className="font-mono text-xs text-muted-foreground">
            {progress}%
          </span>
        </div>
      ),
    },
  ];

  return (
    <div className="mx-auto max-w-[1400px] space-y-4 p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">项目管理</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            共 <span className="font-mono font-semibold">{total}</span> 个项目
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <Select
            value={statusFilter}
            onValueChange={(value: string) =>
              setStatusFilter(value as StatusFilter)
            }
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="全部状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              {PROJECT_STATUS_OPTIONS.map((status: ProjectStatus) => (
                <SelectItem key={status} value={status}>
                  {PROJECT_STATUS_META[status].label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            data-ai-section-type="button"
            onClick={() => setCreateOpen(true)}
          >
            <Plus className="mr-1 h-4 w-4" />
            新建项目
          </Button>
        </div>
      </div>

      <Card className="p-4">
        <Table<ProjectListItem>
          rowKey="id"
          columns={columns}
          dataSource={items}
          loading={loading}
          scroll={{ x: 1220, y: 500 }}
          pagination={false}
        />
      </Card>

      <CreateProjectDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreated={() =>
          void loadData(statusFilter === 'all' ? undefined : statusFilter)
        }
      />
    </div>
  );
};

export default ProjectsPage;
