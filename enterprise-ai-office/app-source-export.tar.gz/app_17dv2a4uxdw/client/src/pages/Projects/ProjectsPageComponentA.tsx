import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { toast } from 'sonner';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import { UserSelect } from '@client/src/components/business-ui/user-select';
import { createProject } from '@client/src/api/projects';
import type { CreateProjectRequest } from '@shared/api.interface';
import { ProjectDateField } from './ProjectDateField';
import { CustomerPicker } from './CustomerPicker';

const createProjectSchema = z
  .object({
    name: z.string().min(1, '请输入项目名称'),
    startDate: z.string().min(1, '请选择开始日期'),
    endDate: z.string().min(1, '请选择结束日期'),
    description: z.string().optional(),
    ownerId: z.string().min(1, '请选择负责人'),
    memberIds: z.array(z.string()),
    customerId: z.string().nullable(),
  })
  .refine(
    (data) => {
      if (!data.startDate || !data.endDate) {
        return true;
      }
      return data.endDate >= data.startDate;
    },
    { message: '结束日期不能早于开始日期', path: ['endDate'] },
  );

type CreateProjectFormData = z.infer<typeof createProjectSchema>;

interface CreateProjectDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onCreated: () => void;
}

export const CreateProjectDialog: React.FC<CreateProjectDialogProps> = ({
  open,
  onOpenChange,
  onCreated,
}) => {
  const [submitting, setSubmitting] = useState<boolean>(false);
  const form = useForm<CreateProjectFormData>({
    resolver: zodResolver(createProjectSchema),
    defaultValues: {
      name: '',
      startDate: '',
      endDate: '',
      description: '',
      ownerId: '',
      memberIds: [],
      customerId: null,
    },
  });

  const handleOpenChange = (nextOpen: boolean): void => {
    if (!nextOpen) {
      form.reset();
    }
    onOpenChange(nextOpen);
  };

  const handleSubmit = async (data: CreateProjectFormData): Promise<void> => {
    setSubmitting(true);
    try {
      const payload: CreateProjectRequest = {
        name: data.name.trim(),
        startDate: data.startDate,
        endDate: data.endDate,
        description: data.description?.trim() || undefined,
        ownerId: data.ownerId,
        memberIds: data.memberIds,
        customerId: data.customerId ?? null,
      };
      await createProject(payload);
      toast.success('项目创建成功');
      form.reset();
      onOpenChange(false);
      onCreated();
    } catch {
      toast.error('项目创建失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-2xl rounded-xl shadow-lg">
        <DialogHeader>
          <DialogTitle>新建项目</DialogTitle>
          <DialogDescription>
            填写项目基本信息，创建后项目默认为「未开始」状态
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit((data) => void handleSubmit(data))}
            className="space-y-4"
          >
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    项目名称 <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input placeholder="请输入项目名称" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex flex-wrap gap-4">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>
                      开始日期 <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <ProjectDateField
                        value={field.value}
                        onChange={field.onChange}
                        placeholder="请选择开始日期"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormLabel>
                      结束日期 <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <ProjectDateField
                        value={field.value}
                        onChange={field.onChange}
                        placeholder="请选择结束日期"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="ownerId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    负责人 <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <UserSelect
                      value={field.value || null}
                      onChange={(value: string | null) =>
                        field.onChange(value ?? '')
                      }
                      placeholder="请选择负责人"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="memberIds"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>项目成员</FormLabel>
                  <FormControl>
                    <UserSelect
                      multiple
                      value={field.value}
                      onChange={(value: string[]) => field.onChange(value)}
                      placeholder="请选择项目成员"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="customerId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>关联客户</FormLabel>
                  <FormControl>
                    <CustomerPicker
                      value={field.value}
                      onChange={field.onChange}
                      placeholder="请选择关联客户（可搜索，选填）"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>项目说明</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="请输入项目说明（选填）"
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleOpenChange(false)}
              >
                取消
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? '创建中...' : '创建项目'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};
