import React, { useEffect, useMemo, useState } from 'react';
import { Check, ChevronsUpDown, SearchX } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@client/src/components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@client/src/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { listCustomers } from '@client/src/api/customers';
import type {
  CustomerListItem,
  CustomerListResponse,
} from '@shared/api.interface';

interface CustomerPickerProps {
  value: string | null;
  onChange: (value: string | null) => void;
  placeholder?: string;
  allowClear?: boolean;
}

export const CustomerPicker: React.FC<CustomerPickerProps> = ({
  value,
  onChange,
  placeholder = '请选择关联客户',
  allowClear = false,
}) => {
  const [open, setOpen] = useState<boolean>(false);
  const [customers, setCustomers] = useState<CustomerListItem[]>([]);

  useEffect(() => {
    const fetchCustomers = async (): Promise<void> => {
      try {
        const res: CustomerListResponse = await listCustomers({
          page: 1,
          pageSize: 50,
        });
        setCustomers(res.items);
      } catch {
        toast.error('客户列表加载失败');
      }
    };
    void fetchCustomers();
  }, []);

  const selectedName: string = useMemo(() => {
    const found: CustomerListItem | undefined = customers.find(
      (item: CustomerListItem) => item.id === value,
    );
    return found?.name ?? '';
  }, [customers, value]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between font-normal"
        >
          <span className={value ? '' : 'text-muted-foreground'}>
            {value ? selectedName || placeholder : placeholder}
          </span>
          <ChevronsUpDown className="ml-2 size-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0" align="start">
        <Command>
          <CommandInput placeholder="搜索客户名称..." />
          <CommandList>
            <CommandEmpty className="flex flex-col items-center gap-1 py-4 text-sm text-muted-foreground">
              <SearchX className="size-4" />
              未找到匹配的客户
            </CommandEmpty>
            <CommandGroup>
              {allowClear ? (
                <CommandItem
                  value="__clear__"
                  onSelect={() => {
                    onChange(null);
                    setOpen(false);
                  }}
                  className="text-muted-foreground"
                >
                  清除关联
                </CommandItem>
              ) : null}
              {customers.map((item: CustomerListItem) => (
                <CommandItem
                  key={item.id}
                  value={item.name}
                  onSelect={() => {
                    onChange(item.id);
                    setOpen(false);
                  }}
                >
                  <Check
                    className={
                      value === item.id ? 'mr-2 size-4' : 'mr-2 size-4 opacity-0'
                    }
                  />
                  {item.name}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};
