import type { ProjectStatus } from '@shared/api.interface';

export interface ProjectStatusMeta {
  label: string;
  badgeClass: string;
}

/** 状态语义色取自 AGENTS.md：已完成绿 / 延期红 / 未开始灰 / 进行中主色 */
export const PROJECT_STATUS_META: Record<ProjectStatus, ProjectStatusMeta> = {
  not_started: {
    label: '未开始',
    badgeClass:
      'border-transparent bg-[hsl(216_12%_94%)] text-[hsl(216_15%_40%)]',
  },
  in_progress: {
    label: '进行中',
    badgeClass: 'border-transparent bg-primary text-primary-foreground',
  },
  completed: {
    label: '已完成',
    badgeClass:
      'border-transparent bg-[hsl(152_55%_96%)] text-[hsl(152_60%_35%)]',
  },
  delayed: {
    label: '延期',
    badgeClass: 'border-transparent bg-[hsl(0_60%_96%)] text-[hsl(0_65%_45%)]',
  },
};

export const PROJECT_STATUS_OPTIONS: ProjectStatus[] = [
  'not_started',
  'in_progress',
  'completed',
  'delayed',
];
