import React, { useCallback, useEffect, useState } from 'react';
import {
  Table,
  type TableColumnsType,
} from '@lark-apaas/client-toolkit/antd-table';
import { CheckCircle2, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Card } from '@client/src/components/ui/card';
import {
  fetchProjectTasks,
  updateProjectTask,
} from '@client/src/api/projects';
import type {
  ProjectMemberInfo,
  ProjectTaskItem,
  ProjectTaskStatus,
} from '@shared/api.interface';
import { CreateTaskDialog } from './ProjectDetailPageComponentB';

const TASK_PENDING_CLASS: string =
  'border-transparent bg-[hsl(216_12%_94%)] text-[hsl(216_15%_40%)]';

interface ProjectTaskSectionProps {
  projectId: string;
  members: ProjectMemberInfo[];
  onProgressChanged: () => Promise<void>;
}

export const ProjectTaskSection: React.FC<ProjectTaskSectionProps> = ({
  projectId,
  members,
  onProgressChanged,
}) => {
  const [tasks, setTasks] = useState<ProjectTaskItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [createOpen, setCreateOpen] = useState<boolean>(false);
  const [completingId, setCompletingId] = useState<string | null>(null);

  const loadTasks = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const res = await fetchProjectTasks(projectId);
      setTasks(res.items);
    } catch {
      toast.error('任务列表加载失败');
    } finally {
      setLoading(false);
    }
  }, [projectId]);

  useEffect(() => {
    void loadTasks();
  }, [loadTasks]);

  const handleComplete = async (taskId: string): Promise<void> => {
    setCompletingId(taskId);
    try {
      await updateProjectTask(projectId, taskId, { status: 'completed' });
      toast.success('任务已完成');
      await loadTasks();
      await onProgressChanged();
    } catch {
      toast.error('操作失败，请重试');
    } finally {
      setCompletingId(null);
    }
  };

  const completedCount: number = tasks.filter(
    (task: ProjectTaskItem) => task.status === 'completed',
  ).length;

  const columns: TableColumnsType<ProjectTaskItem> = [
    {
      title: '任务名称',
      dataIndex: 'taskName',
      key: 'taskName',
      render: (name: string, record: ProjectTaskItem) => (
        <span
          className={
            record.status === 'completed'
              ? 'text-muted-foreground line-through'
              : 'font-medium'
          }
        >
          {name}
        </span>
      ),
    },
    {
      title: '负责人',
      dataIndex: 'assigneeName',
      key: 'assigneeName',
      width: 140,
    },
    { title: '截止日期', dataIndex: 'dueDate', key: 'dueDate', width: 130 },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      width: 110,
      render: (status: ProjectTaskStatus) =>
        status === 'completed' ? (
          <span className="inline-flex items-center gap-1 text-sm text-[hsl(152_60%_42%)]">
            <CheckCircle2 className="h-4 w-4" />
            已完成
          </span>
        ) : (
          <Badge variant="outline" className={TASK_PENDING_CLASS}>
            待办
          </Badge>
        ),
    },
    {
      title: '操作',
      key: 'action',
      width: 120,
      render: (_: unknown, record: ProjectTaskItem) =>
        record.status === 'pending' ? (
          <Button
            size="sm"
            variant="outline"
            disabled={completingId === record.id}
            onClick={() => void handleComplete(record.id)}
          >
            标记完成
          </Button>
        ) : (
          <span className="text-xs text-muted-foreground">—</span>
        ),
    },
  ];

  return (
    <Card className="p-6">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h3 className="text-base font-semibold">
          任务管理
          <span className="ml-2 font-mono text-sm text-muted-foreground">
            {completedCount}/{tasks.length}
          </span>
        </h3>
        <Button
          size="sm"
          data-ai-section-type="button"
          onClick={() => setCreateOpen(true)}
        >
          <Plus className="mr-1 h-4 w-4" />
          新建任务
        </Button>
      </div>
      <Table<ProjectTaskItem>
        rowKey="id"
        columns={columns}
        dataSource={tasks}
        loading={loading}
        scroll={{ y: 400 }}
        pagination={false}
      />
      <CreateTaskDialog
        projectId={projectId}
        members={members}
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreated={() => {
          void loadTasks();
          void onProgressChanged();
        }}
      />
    </Card>
  );
};
