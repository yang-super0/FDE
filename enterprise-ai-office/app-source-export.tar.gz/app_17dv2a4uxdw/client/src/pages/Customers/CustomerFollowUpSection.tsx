import React, { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Plus } from 'lucide-react';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { createFollowUp, listFollowUps } from '@client/src/api/customers';
import type { FollowUpItem } from '@shared/api.interface';

const METHOD_OPTIONS: string[] = [
  '电话',
  '拜访',
  '线上会议',
  '微信/邮件',
  '其他',
];

const formatDate = (iso: string): string => iso.slice(0, 10);

interface CustomerFollowUpSectionProps {
  customerId: string;
}

const CustomerFollowUpSection: React.FC<CustomerFollowUpSectionProps> = ({
  customerId,
}) => {
  const [followUps, setFollowUps] = useState<FollowUpItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [followOpen, setFollowOpen] = useState<boolean>(false);
  const [followMethod, setFollowMethod] = useState<string>('电话');
  const [followContent, setFollowContent] = useState<string>('');
  const [followDate, setFollowDate] = useState<string>('');
  const [followSubmitting, setFollowSubmitting] = useState<boolean>(false);

  const loadFollowUps = async (): Promise<void> => {
    try {
      const res = await listFollowUps(customerId);
      setFollowUps(res.items);
    } catch (err) {
      logger.error(`Load follow ups failed: ${String(err)}`);
      setFollowUps([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadFollowUps();
  }, [customerId]);

  const submitFollowUp = async (): Promise<void> => {
    if (!followContent.trim()) {
      return;
    }
    setFollowSubmitting(true);
    try {
      await createFollowUp(customerId, {
        method: followMethod,
        content: followContent.trim(),
        nextFollowAt: followDate || undefined,
      });
      setFollowOpen(false);
      setFollowContent('');
      setFollowDate('');
      setFollowMethod('电话');
      await loadFollowUps();
    } catch (err) {
      logger.error(`Add follow up failed: ${String(err)}`);
    } finally {
      setFollowSubmitting(false);
    }
  };

  return (
    <div className="rounded-lg border bg-card p-6 lg:col-span-2">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-semibold">跟进时间线</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setFollowOpen(true)}
          data-testid="follow-up-add-btn"
        >
          <Plus className="mr-1 h-4 w-4" /> 添加跟进
        </Button>
      </div>
      {loading ? (
        <div className="py-12 text-center text-[hsl(216_15%_50%)]">
          加载中...
        </div>
      ) : followUps.length === 0 ? (
        <div className="py-12 text-center text-[hsl(216_15%_50%)]">
          暂无跟进记录，点击「添加跟进」记录第一条
        </div>
      ) : (
        <div className="space-y-4" data-testid="follow-up-timeline">
          {followUps.map((item: FollowUpItem) => (
            <div key={item.id} className="flex gap-3">
              <div className="flex flex-col items-center">
                <span className="mt-1.5 h-2.5 w-2.5 rounded-full bg-[hsl(217_70%_52%)]" />
                <span className="w-px flex-1 bg-[hsl(216_18%_88%)]" />
              </div>
              <div className="flex-1 pb-4">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge
                    variant="outline"
                    className="font-normal text-[hsl(216_15%_50%)]"
                  >
                    {item.method}
                  </Badge>
                  <span className="text-xs text-[hsl(216_15%_50%)]">
                    {formatDate(item.createdAt)}
                  </span>
                  <span className="text-xs text-[hsl(216_15%_50%)]">
                    {item.operatorName}
                  </span>
                </div>
                <p className="mt-2 whitespace-pre-wrap text-sm">
                  {item.content}
                </p>
                {item.nextFollowAt && (
                  <p className="mt-1 text-xs text-[hsl(38_85%_48%)]">
                    下次跟进：{formatDate(item.nextFollowAt)}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog
        open={followOpen}
        onOpenChange={(nextOpen: boolean) => {
          if (!nextOpen) {
            setFollowOpen(false);
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>添加跟进记录</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="mb-2 block">跟进方式</Label>
              <Select value={followMethod} onValueChange={setFollowMethod}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="选择跟进方式" />
                </SelectTrigger>
                <SelectContent>
                  {METHOD_OPTIONS.map((method: string) => (
                    <SelectItem key={method} value={method}>
                      {method}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-2 block">
                跟进内容 <span className="text-[hsl(0_65%_52%)]">*</span>
              </Label>
              <textarea
                className="min-h-24 w-full rounded-md border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(217_70%_52%)]"
                value={followContent}
                onChange={(e) => setFollowContent(e.target.value)}
                placeholder="请输入跟进内容"
              />
            </div>
            <div>
              <Label className="mb-2 block">下次跟进时间</Label>
              <Input
                type="date"
                value={followDate}
                onChange={(e) => setFollowDate(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setFollowOpen(false)}
              disabled={followSubmitting}
            >
              取消
            </Button>
            <Button
              onClick={() => void submitFollowUp()}
              disabled={followSubmitting || !followContent.trim()}
            >
              {followSubmitting ? '提交中...' : '提交'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CustomerFollowUpSection;
