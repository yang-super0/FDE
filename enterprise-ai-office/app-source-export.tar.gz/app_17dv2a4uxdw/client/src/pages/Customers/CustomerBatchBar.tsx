import React, { useState } from 'react';
import { Button } from '@client/src/components/ui/button';
import { UserSelect } from '@client/src/components/business-ui/user-select';
import OwnerQuickSelect from './OwnerQuickSelect';

interface CustomerBatchBarProps {
  selectedCount: number;
  submitting: boolean;
  onAssign: (ownerId: string) => Promise<void>;
  onClearSelection: () => void;
}

const CustomerBatchBar: React.FC<CustomerBatchBarProps> = ({
  selectedCount,
  submitting,
  onAssign,
  onClearSelection,
}) => {
  const [ownerId, setOwnerId] = useState<string | null>(null);

  const handleAssign = async (): Promise<void> => {
    if (!ownerId) {
      return;
    }
    await onAssign(ownerId);
    setOwnerId(null);
  };

  if (selectedCount === 0) {
    return null;
  }

  return (
    <div
      className="flex flex-wrap items-center gap-3 rounded-lg border border-[hsl(217_70%_52%/0.25)] bg-[hsl(217_40%_95%)] px-4 py-3"
      data-testid="customer-batch-bar"
    >
      <span className="text-sm">
        已选择 <span className="font-semibold">{selectedCount}</span> 个客户
      </span>
      <div className="w-56">
        <UserSelect
          value={ownerId}
          onChange={setOwnerId}
          placeholder="选择负责人"
          disabled={submitting}
        />
      </div>
      <div className="w-48">
        <OwnerQuickSelect
          value={ownerId}
          onChange={setOwnerId}
          placeholder="或从已有负责人选择"
          disabled={submitting}
        />
      </div>
      <Button
        size="sm"
        onClick={() => void handleAssign()}
        disabled={!ownerId || submitting}
        data-ai-section-type="button"
        data-testid="batch-assign-confirm"
      >
        {submitting ? '分配中...' : '批量分配'}
      </Button>
      <Button
        size="sm"
        variant="ghost"
        onClick={onClearSelection}
        disabled={submitting}
      >
        取消选择
      </Button>
    </div>
  );
};

export default CustomerBatchBar;
