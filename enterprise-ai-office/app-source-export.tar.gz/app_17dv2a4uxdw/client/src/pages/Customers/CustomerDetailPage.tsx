import React, { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeftRight,
  MessageSquare,
  Phone,
  Plus,
  User,
} from 'lucide-react';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import {
  getCurrentUserRole,
  getCustomerDetail,
  listCustomerProjects,
  listCustomerQuotations,
} from '@client/src/api/customers';
import type {
  CustomerDetail,
  CustomerQuotationItem,
  ProjectListItem,
} from '@shared/api.interface';
import CustomerFollowUpSection from './CustomerFollowUpSection';
import CustomerFormDialog from './CustomerFormDialog';
import CustomerTransferDialog from './CustomerTransferDialog';

const QUOTATION_STATUS_MAP: Record<
  string,
  { label: string; className: string }
> = {
  draft: {
    label: '草稿',
    className: 'bg-[hsl(216_12%_94%)] text-[hsl(216_15%_55%)]',
  },
  pending: {
    label: '待确认',
    className: 'bg-[hsl(38_80%_96%)] text-[hsl(38_85%_48%)]',
  },
  confirmed: {
    label: '已确认',
    className: 'bg-[hsl(152_55%_96%)] text-[hsl(152_60%_42%)]',
  },
  closed: {
    label: '已关闭',
    className: 'bg-[hsl(0_60%_96%)] text-[hsl(0_65%_52%)]',
  },
};

const PROJECT_STATUS_MAP: Record<
  string,
  { label: string; className: string }
> = {
  not_started: {
    label: '未开始',
    className: 'bg-[hsl(216_12%_94%)] text-[hsl(216_15%_55%)]',
  },
  in_progress: {
    label: '进行中',
    className: 'bg-[hsl(217_40%_95%)] text-[hsl(217_70%_40%)]',
  },
  completed: {
    label: '已完成',
    className: 'bg-[hsl(152_55%_96%)] text-[hsl(152_60%_42%)]',
  },
  delayed: {
    label: '已延期',
    className: 'bg-[hsl(38_80%_96%)] text-[hsl(38_85%_48%)]',
  },
};

const CustomerDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [customer, setCustomer] = useState<CustomerDetail | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [notFound, setNotFound] = useState<boolean>(false);
  const [quotations, setQuotations] = useState<CustomerQuotationItem[]>([]);
  const [projects, setProjects] = useState<ProjectListItem[]>([]);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [editOpen, setEditOpen] = useState<boolean>(false);
  const [transferOpen, setTransferOpen] = useState<boolean>(false);

  const loadDetail = async (): Promise<void> => {
    if (!id) {
      return;
    }
    try {
      const res: CustomerDetail = await getCustomerDetail(id);
      setCustomer(res);
      setNotFound(false);
    } catch (err) {
      logger.error(`Load customer detail failed: ${String(err)}`);
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  const loadRelated = async (): Promise<void> => {
    if (!id) {
      return;
    }
    try {
      const [quotationRes, projectRes] = await Promise.all([
        listCustomerQuotations(id),
        listCustomerProjects(id),
      ]);
      setQuotations(quotationRes.items);
      setProjects(projectRes.items);
    } catch (err) {
      logger.error(`Load customer related data failed: ${String(err)}`);
    }
  };

  useEffect(() => {
    void loadDetail();
    void loadRelated();
    getCurrentUserRole()
      .then((res) => setIsAdmin(res.isAdmin))
      .catch((err: unknown) =>
        logger.error(`Load current user role failed: ${String(err)}`),
      );
  }, [id]);

  if (loading) {
    return (
      <div className="py-20 text-center text-[hsl(216_15%_50%)]">
        加载中...
      </div>
    );
  }

  if (notFound || !customer) {
    return (
      <div className="py-20 text-center">
        <p className="text-[hsl(216_15%_50%)]">客户不存在或已被删除</p>
        <Button
          variant="outline"
          className="mt-4"
          onClick={() => navigate('/customers')}
        >
          返回客户列表
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">{customer.name}</h1>
          <p className="mt-1 text-sm text-[hsl(216_15%_50%)]">
            {customer.industry || '未设置行业'}
          </p>
        </div>
        <Button variant="outline" onClick={() => setEditOpen(true)}>
          编辑客户
        </Button>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-1">
          <div className="rounded-lg border bg-card p-6">
            <h2 className="mb-4 font-semibold">基本信息</h2>
            <div className="space-y-4 text-sm">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 shrink-0 text-[hsl(216_15%_50%)]" />
                <span className="text-[hsl(216_15%_50%)]">负责人：</span>
                <span className="flex items-center gap-2">
                  {customer.ownerId !== null && customer.ownerName ? (
                    <span>{customer.ownerName}</span>
                  ) : (
                    <Badge className="bg-[hsl(216_12%_94%)] font-normal text-[hsl(216_15%_55%)]">
                      未分配
                    </Badge>
                  )}
                  {isAdmin && (
                    <button
                      type="button"
                      className="text-[hsl(216_15%_50%)] transition-colors hover:text-[hsl(217_70%_52%)]"
                      onClick={() => setTransferOpen(true)}
                      title="转移客户"
                      data-testid="detail-transfer-btn"
                    >
                      <ArrowLeftRight className="h-3.5 w-3.5" />
                    </button>
                  )}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 shrink-0 text-[hsl(216_15%_50%)]" />
                <span className="text-[hsl(216_15%_50%)]">联系人：</span>
                <span>{customer.contactName || '-'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 shrink-0 text-[hsl(216_15%_50%)]" />
                <span className="text-[hsl(216_15%_50%)]">联系电话：</span>
                <span>{customer.contactPhone || '-'}</span>
              </div>
              <div className="flex items-start gap-2">
                <MessageSquare className="mt-0.5 h-4 w-4 shrink-0 text-[hsl(216_15%_50%)]" />
                <span className="text-[hsl(216_15%_50%)]">地址：</span>
                <span>{customer.address || '-'}</span>
              </div>
            </div>
          </div>

          <div className="rounded-lg border bg-card p-6">
            <h2 className="mb-4 font-semibold">
              关联报价单（{quotations.length}）
            </h2>
            {quotations.length === 0 ? (
              <p className="text-sm text-[hsl(216_15%_50%)]">
                暂无关联报价单
              </p>
            ) : (
              <div className="space-y-3">
                {quotations.map((item: CustomerQuotationItem) => {
                  const status = QUOTATION_STATUS_MAP[item.status];
                  return (
                    <div
                      key={item.id}
                      className="cursor-pointer rounded-lg border p-3 transition-colors hover:bg-[hsl(217_40%_95%)]"
                      onClick={() => navigate('/quotations')}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">
                          {item.quotationNo}
                        </span>
                        {status ? (
                          <Badge className={status.className}>
                            {status.label}
                          </Badge>
                        ) : null}
                      </div>
                      <p className="mt-1 text-sm text-[hsl(216_15%_50%)]">
                        ¥{Number(item.totalAmount).toLocaleString()}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="rounded-lg border bg-card p-6">
            <h2 className="mb-4 font-semibold">
              关联项目（{projects.length}）
            </h2>
            {projects.length === 0 ? (
              <p className="text-sm text-[hsl(216_15%_50%)]">暂无关联项目</p>
            ) : (
              <div className="space-y-3">
                {projects.map((item: ProjectListItem) => {
                  const status = PROJECT_STATUS_MAP[item.status];
                  return (
                    <div
                      key={item.id}
                      className="cursor-pointer rounded-lg border p-3 transition-colors hover:bg-[hsl(217_40%_95%)]"
                      onClick={() => navigate(`/projects/${item.id}`)}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">
                          {item.name}
                        </span>
                        {status ? (
                          <Badge className={status.className}>
                            {status.label}
                          </Badge>
                        ) : null}
                      </div>
                      <p className="mt-1 text-sm text-[hsl(216_15%_50%)]">
                        {item.startDate} ~ {item.endDate}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        <CustomerFollowUpSection customerId={customer.id} />
      </div>

      <CustomerFormDialog
        open={editOpen}
        customer={customer}
        isAdmin={isAdmin}
        currentUserId={null}
        onClose={() => setEditOpen(false)}
        onSaved={() => {
          setEditOpen(false);
          void loadDetail();
        }}
      />

      <CustomerTransferDialog
        open={transferOpen}
        customer={{
          id: customer.id,
          name: customer.name,
          ownerId: customer.ownerId,
          ownerName: customer.ownerName,
        }}
        onClose={() => setTransferOpen(false)}
        onTransferred={() => {
          setTransferOpen(false);
          void loadDetail();
        }}
      />
    </div>
  );
};

export default CustomerDetailPage;
