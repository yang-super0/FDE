import React, { useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { UserSelect } from '@client/src/components/business-ui/user-select';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { Label } from '@client/src/components/ui/label';
import { Textarea } from '@client/src/components/ui/textarea';
import { transferCustomer } from '@client/src/api/customers';
import OwnerQuickSelect from './OwnerQuickSelect';

export interface TransferableCustomer {
  id: string;
  name: string;
  ownerId: string | null;
  ownerName: string;
}

interface CustomerTransferDialogProps {
  open: boolean;
  customer: TransferableCustomer | null;
  onClose: () => void;
  onTransferred: () => void;
}

const CustomerTransferDialog: React.FC<CustomerTransferDialogProps> = ({
  open,
  customer,
  onClose,
  onTransferred,
}) => {
  const [newOwnerId, setNewOwnerId] = useState<string | null>(null);
  const [reason, setReason] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  if (!open || customer === null) {
    return null;
  }

  const submit = async (): Promise<void> => {
    if (!newOwnerId) {
      setError('请选择新负责人');
      return;
    }
    if (newOwnerId === customer.ownerId) {
      setError('新负责人与当前负责人相同');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      await transferCustomer(customer.id, {
        ownerId: newOwnerId,
        reason: reason.trim() || undefined,
      });
      setNewOwnerId(null);
      setReason('');
      onTransferred();
    } catch (err) {
      logger.error(`Customer transfer failed: ${String(err)}`);
      setError('转移失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(nextOpen: boolean) => {
        if (!nextOpen) {
          setNewOwnerId(null);
          setReason('');
          setError('');
          onClose();
        }
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>转移客户</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label className="mb-2 block">客户名称</Label>
            <p className="text-sm">{customer.name}</p>
          </div>
          <div>
            <Label className="mb-2 block">当前负责人</Label>
            {customer.ownerId !== null && customer.ownerName ? (
              <span className="text-sm">{customer.ownerName}</span>
            ) : (
              <Badge
                className="bg-[hsl(216_12%_94%)] font-normal text-[hsl(216_15%_55%)]"
                data-testid="transfer-current-unassigned"
              >
                未分配
              </Badge>
            )}
          </div>
          <div>
            <Label className="mb-2 block">新负责人</Label>
            <UserSelect
              value={newOwnerId}
              onChange={setNewOwnerId}
              placeholder="请选择新负责人"
            />
            <div className="mt-2">
              <OwnerQuickSelect
                value={newOwnerId}
                onChange={setNewOwnerId}
                excludeOwnerId={customer.ownerId}
                placeholder="或从已有负责人中快速选择"
                disabled={submitting}
              />
            </div>
          </div>
          <div>
            <Label className="mb-2 block">转移原因（选填）</Label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="请输入转移原因"
              maxLength={200}
            />
          </div>
          {error && <p className="text-sm text-[hsl(0_65%_52%)]">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={submitting}>
            取消
          </Button>
          <Button
            onClick={() => void submit()}
            disabled={submitting}
            data-ai-section-type="button"
            data-testid="transfer-dialog-confirm"
          >
            {submitting ? '转移中...' : '确认转移'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CustomerTransferDialog;
