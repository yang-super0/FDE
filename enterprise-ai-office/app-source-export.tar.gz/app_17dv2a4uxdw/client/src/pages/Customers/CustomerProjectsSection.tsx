import React, { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import dayjs from 'dayjs';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Briefcase } from 'lucide-react';
import type {
  CustomerProjectListResponse,
  ProjectListItem,
} from '@shared/api.interface';
import { listCustomerProjects } from '@client/src/api/customers';
import { Badge } from '@client/src/components/ui/badge';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@client/src/components/ui/card';
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@client/src/components/ui/empty';
import { Progress } from '@client/src/components/ui/progress';
import { PROJECT_STATUS_META } from '@client/src/pages/Projects/projectStatusMeta';

interface CustomerProjectsSectionProps {
  customerId: string;
}

const CustomerProjectsSection: React.FC<CustomerProjectsSectionProps> = ({
  customerId,
}) => {
  const [projects, setProjects] = useState<ProjectListItem[]>([]);
  const [loaded, setLoaded] = useState<boolean>(false);

  const loadProjects = useCallback(async (): Promise<void> => {
    try {
      const res: CustomerProjectListResponse =
        await listCustomerProjects(customerId);
      setProjects(res.items);
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error('关联项目加载失败');
    } finally {
      setLoaded(true);
    }
  }, [customerId]);

  useEffect(() => {
    void loadProjects();
  }, [loadProjects]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Briefcase className="size-4 text-muted-foreground" />
          关联项目
        </CardTitle>
      </CardHeader>
      <CardContent>
        {loaded && projects.length === 0 ? (
          <Empty>
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <Briefcase className="size-6" />
              </EmptyMedia>
              <EmptyTitle>暂无关联项目</EmptyTitle>
              <EmptyDescription>
                可前往项目管理模块为该客户创建项目
              </EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <div className="divide-y">
            {projects.map((item: ProjectListItem) => (
              <div key={item.id} className="space-y-2 px-4 py-3">
                <div className="flex items-center justify-between gap-2">
                  <Link
                    to={`/projects/${item.id}`}
                    className="text-sm font-medium hover:underline"
                  >
                    {item.name}
                  </Link>
                  <Badge
                    variant="outline"
                    className={PROJECT_STATUS_META[item.status].badgeClass}
                  >
                    {PROJECT_STATUS_META[item.status].label}
                  </Badge>
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs text-muted-foreground">
                    负责人：{item.ownerName} ·{' '}
                    {dayjs(item.startDate).format('YYYY-MM-DD')} ~{' '}
                    {dayjs(item.endDate).format('YYYY-MM-DD')}
                  </span>
                  <div className="flex items-center gap-2">
                    <Progress value={item.progress} className="w-32" />
                    <span className="font-mono text-xs text-muted-foreground">
                      {item.progress}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CustomerProjectsSection;
