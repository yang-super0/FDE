import React, { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import { Input } from '@client/src/components/ui/input';
import { Label } from '@client/src/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { UserSelect } from '@client/src/components/business-ui/user-select';
import { createCustomer, updateCustomer } from '@client/src/api/customers';
import OwnerQuickSelect from './OwnerQuickSelect';
import type { CustomerDetail } from '@shared/api.interface';

const INDUSTRY_OPTIONS: string[] = [
  '互联网',
  '软件服务',
  '制造业',
  '房地产',
  '零售',
  '金融服务',
  '教育培训',
  '医疗健康',
  '能源化工',
  '商务服务',
  '物流运输',
  '农林牧渔',
  '文化传媒',
  '政府公共事业',
];

interface CustomerFormDialogProps {
  open: boolean;
  customer: CustomerDetail | null;
  isAdmin: boolean;
  currentUserId: string | null;
  onClose: () => void;
  onSaved: () => void;
}

interface CustomerFormState {
  name: string;
  industry: string;
  contactName: string;
  contactPhone: string;
  address: string;
  ownerId: string | null;
}

const CustomerFormDialog: React.FC<CustomerFormDialogProps> = ({
  open,
  customer,
  isAdmin,
  currentUserId,
  onClose,
  onSaved,
}) => {
  const isEdit: boolean = customer !== null;
  const [form, setForm] = useState<CustomerFormState>({
    name: '',
    industry: '',
    contactName: '',
    contactPhone: '',
    address: '',
    ownerId: null,
  });
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    if (!open) {
      return;
    }
    if (customer) {
      setForm({
        name: customer.name,
        industry: customer.industry,
        contactName: customer.contactName,
        contactPhone: customer.contactPhone,
        address: customer.address,
        ownerId: customer.ownerId,
      });
    } else {
      setForm({
        name: '',
        industry: '',
        contactName: '',
        contactPhone: '',
        address: '',
        ownerId: currentUserId ?? null,
      });
    }
    setError('');
  }, [open, customer, currentUserId]);

  const updateField = <K extends keyof CustomerFormState>(
    key: K,
    value: CustomerFormState[K],
  ): void => {
    setForm((prev: CustomerFormState) => ({ ...prev, [key]: value }));
  };

  const submit = async (): Promise<void> => {
    const name: string = form.name.trim();
    if (!name) {
      setError('请输入客户名称');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      if (isEdit && customer) {
        await updateCustomer(customer.id, {
          name,
          industry: form.industry || undefined,
          contactName: form.contactName.trim() || undefined,
          contactPhone: form.contactPhone.trim() || undefined,
          address: form.address.trim() || undefined,
          ownerId: isAdmin ? form.ownerId : undefined,
        });
      } else {
        await createCustomer({
          name,
          industry: form.industry || undefined,
          contactName: form.contactName.trim() || undefined,
          contactPhone: form.contactPhone.trim() || undefined,
          address: form.address.trim() || undefined,
          ownerId: isAdmin ? form.ownerId ?? undefined : undefined,
        });
      }
      onSaved();
    } catch (err) {
      logger.error(`Customer form submit failed: ${String(err)}`);
      setError('保存失败，请检查客户名称是否重复');
    } finally {
      setSubmitting(false);
    }
  };

  if (!open) {
    return null;
  }

  return (
    <Dialog open={open} onOpenChange={(nextOpen: boolean) => {
      if (!nextOpen) {
        onClose();
      }
    }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{isEdit ? '编辑客户' : '新建客户'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label className="mb-2 block">
              客户名称 <span className="text-[hsl(0_65%_52%)]">*</span>
            </Label>
            <Input
              value={form.name}
              onChange={(e) => updateField('name', e.target.value)}
              placeholder="请输入客户名称"
              maxLength={200}
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="mb-2 block">所属行业</Label>
              <Select
                value={form.industry || undefined}
                onValueChange={(value: string) =>
                  updateField('industry', value)
                }
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="请选择行业" />
                </SelectTrigger>
                <SelectContent>
                  {INDUSTRY_OPTIONS.map((industry: string) => (
                    <SelectItem key={industry} value={industry}>
                      {industry}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-2 block">联系电话</Label>
              <Input
                value={form.contactPhone}
                onChange={(e) => updateField('contactPhone', e.target.value)}
                placeholder="请输入联系电话"
              />
            </div>
          </div>
          <div>
            <Label className="mb-2 block">联系人</Label>
            <Input
              value={form.contactName}
              onChange={(e) => updateField('contactName', e.target.value)}
              placeholder="请输入联系人姓名"
            />
          </div>
          <div>
            <Label className="mb-2 block">负责人</Label>
            {isAdmin ? (
              <div className="space-y-2">
                <UserSelect
                  value={form.ownerId}
                  onChange={(value: string | null) =>
                    updateField('ownerId', value)
                  }
                  placeholder="未指定时为当前用户"
                />
                <OwnerQuickSelect
                  value={form.ownerId}
                  onChange={(value: string) => updateField('ownerId', value)}
                  placeholder="或从已有负责人中选择"
                />
              </div>
            ) : (
              <p className="text-sm text-[hsl(216_15%_50%)]">
                {isEdit
                  ? '仅管理员可以修改负责人'
                  : '负责人默认为当前用户'}
              </p>
            )}
          </div>
          <div>
            <Label className="mb-2 block">地址</Label>
            <Input
              value={form.address}
              onChange={(e) => updateField('address', e.target.value)}
              placeholder="请输入客户地址"
            />
          </div>
          {error && <p className="text-sm text-[hsl(0_65%_52%)]">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={submitting}>
            取消
          </Button>
          <Button
            onClick={() => void submit()}
            disabled={submitting}
            data-ai-section-type="button"
            data-testid="customer-form-save"
          >
            {submitting ? '保存中...' : '保存'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default CustomerFormDialog;
