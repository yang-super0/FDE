import React, { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { listCustomerOwners } from '@client/src/api/customers';
import type { CustomerOwnerOption } from '@shared/api.interface';

interface OwnerQuickSelectProps {
  value: string | null;
  onChange: (ownerId: string) => void;
  excludeOwnerId?: string | null;
  placeholder?: string;
  disabled?: boolean;
}

const OwnerQuickSelect: React.FC<OwnerQuickSelectProps> = ({
  value,
  onChange,
  excludeOwnerId,
  placeholder,
  disabled,
}) => {
  const [options, setOptions] = useState<CustomerOwnerOption[]>([]);

  useEffect(() => {
    listCustomerOwners()
      .then((res) => setOptions(res.items))
      .catch((err: unknown) =>
        logger.error(`Load owner options failed: ${String(err)}`),
      );
  }, []);

  const visibleOptions: CustomerOwnerOption[] = options.filter(
    (option: CustomerOwnerOption) => option.userId !== excludeOwnerId,
  );

  if (visibleOptions.length === 0) {
    return null;
  }

  return (
    <Select
      value={value ?? undefined}
      onValueChange={onChange}
      disabled={disabled}
    >
      <SelectTrigger className="w-full" data-testid="owner-quick-select">
        <SelectValue placeholder={placeholder || '从已有负责人中选择'} />
      </SelectTrigger>
      <SelectContent>
        {visibleOptions.map((option: CustomerOwnerOption) => (
          <SelectItem key={option.userId} value={option.userId}>
            {option.name || option.userId}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

export default OwnerQuickSelect;
