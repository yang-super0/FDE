import React, { useEffect, useState } from 'react';
import { isAxiosError } from 'axios';
import dayjs from 'dayjs';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Calendar as CalendarIcon, X } from 'lucide-react';
import type { CreateFollowUpRequest } from '@shared/api.interface';
import { createFollowUp } from '@client/src/api/customers';
import { Button } from '@client/src/components/ui/button';
import { Calendar } from '@client/src/components/ui/calendar';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@client/src/components/ui/form';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Textarea } from '@client/src/components/ui/textarea';

const FOLLOW_UP_METHODS: string[] = ['电话', '拜访', '线上会议', '其他'];

const followUpSchema = z.object({
  method: z.string().min(1, '请选择跟进方式'),
  content: z.string().trim().min(1, '请填写跟进内容'),
});

type FollowUpFormData = z.infer<typeof followUpSchema>;

interface FollowUpDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  customerId: string;
  customerName?: string;
  onSaved: () => void;
}

const FollowUpDialog: React.FC<FollowUpDialogProps> = ({
  open,
  onOpenChange,
  customerId,
  customerName,
  onSaved,
}) => {
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [datePopoverOpen, setDatePopoverOpen] = useState<boolean>(false);
  const [nextFollowDate, setNextFollowDate] = useState<Date | undefined>(
    undefined,
  );
  const form = useForm<FollowUpFormData>({
    resolver: zodResolver(followUpSchema),
    defaultValues: { method: '', content: '' },
  });

  useEffect(() => {
    if (open) {
      form.reset({ method: '', content: '' });
      setNextFollowDate(undefined);
    }
  }, [open, form]);

  const onSubmit = form.handleSubmit(
    async (data: FollowUpFormData): Promise<void> => {
      setSubmitting(true);
      try {
        const requestData: CreateFollowUpRequest = {
          method: data.method,
          content: data.content.trim(),
        };
        if (nextFollowDate) {
          requestData.nextFollowAt = dayjs(nextFollowDate).format(
            'YYYY-MM-DD',
          );
        }
        await createFollowUp(customerId, requestData);
        toast.success('跟进记录已添加');
        onOpenChange(false);
        onSaved();
      } catch (error: unknown) {
        logger.error(String(error));
        const message: string = isAxiosError(error)
          ? String(error.response?.data?.message ?? '添加跟进失败')
          : '添加跟进失败';
        toast.error(message);
      } finally {
        setSubmitting(false);
      }
    },
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {customerName ? `添加跟进 - ${customerName}` : '添加跟进'}
          </DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={onSubmit} className="space-y-4">
            <FormField
              control={form.control}
              name="method"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    跟进方式 <span className="text-destructive">*</span>
                  </FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    value={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="请选择跟进方式" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {FOLLOW_UP_METHODS.map((method: string) => (
                        <SelectItem key={method} value={method}>
                          {method}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="content"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    跟进内容 <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="请输入本次跟进的沟通内容与结论"
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormItem>
              <FormLabel>下次跟进时间</FormLabel>
              <div className="flex items-center gap-2">
                <Popover
                  open={datePopoverOpen}
                  onOpenChange={setDatePopoverOpen}
                >
                  <PopoverTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      className="justify-start font-normal"
                    >
                      <CalendarIcon className="mr-2 size-4" />
                      {nextFollowDate
                        ? dayjs(nextFollowDate).format('YYYY-MM-DD')
                        : '选择日期（可选）'}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={nextFollowDate}
                      onSelect={(date: Date | undefined) => {
                        setNextFollowDate(date);
                        setDatePopoverOpen(false);
                      }}
                    />
                  </PopoverContent>
                </Popover>
                {nextFollowDate ? (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setNextFollowDate(undefined)}
                  >
                    <X className="size-4" />
                    清除
                  </Button>
                ) : null}
              </div>
            </FormItem>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                取消
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? '提交中...' : '提交'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};

export default FollowUpDialog;
