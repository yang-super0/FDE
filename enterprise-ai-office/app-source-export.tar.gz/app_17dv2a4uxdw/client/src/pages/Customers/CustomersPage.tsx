import React, { useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowLeftRight,
  ChevronLeft,
  ChevronRight,
  Plus,
  Search,
} from 'lucide-react';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Checkbox } from '@client/src/components/ui/checkbox';
import { Input } from '@client/src/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import {
  batchAssignCustomers,
  getCurrentUserRole,
  getUnassignedCount,
  listCustomerOwners,
  listCustomers,
} from '@client/src/api/customers';
import CustomerBatchBar from './CustomerBatchBar';
import CustomerFormDialog from './CustomerFormDialog';
import CustomerTransferDialog, {
  type TransferableCustomer,
} from './CustomerTransferDialog';
import type {
  CustomerListItem,
  CustomerOwnerOption,
} from '@shared/api.interface';

const PAGE_SIZE: number = 10;
const ALL_OWNER_VALUE: string = '__all__';
const UNASSIGNED_OWNER_VALUE: string = 'unassigned';

const INDUSTRY_OPTIONS: string[] = [
  '互联网',
  '软件服务',
  '制造业',
  '房地产',
  '零售',
  '金融服务',
  '教育培训',
  '医疗健康',
  '能源化工',
  '商务服务',
  '物流运输',
  '农林牧渔',
  '文化传媒',
  '政府公共事业',
];

const NO_FOLLOW_DAYS: number = 15;

const isLongTimeNoFollow = (iso: string | null): boolean => {
  if (!iso) {
    return true;
  }
  const elapsedMs: number = Date.now() - new Date(iso).getTime();
  return elapsedMs > NO_FOLLOW_DAYS * 86400000;
};

const formatDateTime = (iso: string | null): string => {
  if (!iso) {
    return '-';
  }
  const date: Date = new Date(iso);
  const pad = (value: number): string => String(value).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
};

interface CustomerOwnerFilterProps {
  value: string;
  options: CustomerOwnerOption[];
  onChange: (value: string) => void;
}

const CustomerOwnerFilter: React.FC<CustomerOwnerFilterProps> = ({
  value,
  options,
  onChange,
}) => {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-40" data-testid="owner-filter">
        <SelectValue placeholder="负责人" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value={ALL_OWNER_VALUE}>全部负责人</SelectItem>
        <SelectItem value={UNASSIGNED_OWNER_VALUE}>未分配</SelectItem>
        {options.map((option: CustomerOwnerOption) => (
          <SelectItem key={option.userId} value={option.userId}>
            {option.name || option.userId}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

const CustomersPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [customers, setCustomers] = useState<CustomerListItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [keyword, setKeyword] = useState<string>('');
  const [industry, setIndustry] = useState<string>(ALL_OWNER_VALUE);
  const [ownerFilter, setOwnerFilter] = useState<string>(() => {
    const fromUrl: string | null = searchParams.get('ownerFilter');
    return fromUrl === UNASSIGNED_OWNER_VALUE
      ? UNASSIGNED_OWNER_VALUE
      : ALL_OWNER_VALUE;
  });
  const [page, setPage] = useState<number>(1);
  const [formOpen, setFormOpen] = useState<boolean>(false);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [ownerOptions, setOwnerOptions] = useState<CustomerOwnerOption[]>([]);
  const [unassignedCount, setUnassignedCount] = useState<number>(0);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [assigning, setAssigning] = useState<boolean>(false);
  const [transferTarget, setTransferTarget] =
    useState<TransferableCustomer | null>(null);

  const loadOwnerMeta = async (): Promise<void> => {
    try {
      const [roleRes, ownersRes, countRes] = await Promise.all([
        getCurrentUserRole(),
        listCustomerOwners(),
        getUnassignedCount(),
      ]);
      setIsAdmin(roleRes.isAdmin);
      setOwnerOptions(ownersRes.items);
      setUnassignedCount(countRes.count);
    } catch (err) {
      logger.error(`Load customer owner meta failed: ${String(err)}`);
    }
  };

  useEffect(() => {
    void loadOwnerMeta();
  }, []);

  const loadList = async (): Promise<void> => {
    setLoading(true);
    try {
      const res = await listCustomers({
        keyword: keyword.trim() || undefined,
        industry: industry === ALL_OWNER_VALUE ? undefined : industry,
        ownerId: ownerFilter === ALL_OWNER_VALUE ? undefined : ownerFilter,
        page,
        pageSize: PAGE_SIZE,
      });
      setCustomers(res.items);
      setTotal(res.total);
    } catch (err) {
      logger.error(`Load customer list failed: ${String(err)}`);
      setCustomers([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadList();
  }, [keyword, industry, ownerFilter, page]);

  const totalPages: number = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const allSelected: boolean =
    customers.length > 0 &&
    customers.every((c: CustomerListItem) => selectedIds.includes(c.id));

  const toggleSelectAll = (): void => {
    setSelectedIds((prev: string[]) =>
      allSelected
        ? prev.filter(
            (id: string) => !customers.some((c) => c.id === id),
          )
        : [
            ...prev,
            ...customers
              .map((c: CustomerListItem) => c.id)
              .filter((id: string) => !prev.includes(id)),
          ],
    );
  };

  const toggleSelect = (id: string): void => {
    setSelectedIds((prev: string[]) =>
      prev.includes(id) ? prev.filter((v: string) => v !== id) : [...prev, id],
    );
  };

  const handleBatchAssign = async (ownerId: string): Promise<void> => {
    setAssigning(true);
    try {
      await batchAssignCustomers({ customerIds: selectedIds, ownerId });
      setSelectedIds([]);
      await Promise.all([loadList(), loadOwnerMeta()]);
    } catch (err) {
      logger.error(`Batch assign customers failed: ${String(err)}`);
    } finally {
      setAssigning(false);
    }
  };

  const openTransfer = (item: CustomerListItem): void => {
    setTransferTarget({
      id: item.id,
      name: item.name,
      ownerId: item.ownerId,
      ownerName: item.ownerName,
    });
  };

  const handleTransferred = (): void => {
    setTransferTarget(null);
    void loadList();
    void loadOwnerMeta();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold">客户管理</h1>
          <p className="mt-1 text-sm text-[hsl(216_15%_50%)]">
            管理客户信息、负责人分配与跟进记录
          </p>
        </div>
        <Button
          onClick={() => setFormOpen(true)}
          data-ai-section-type="button"
          data-testid="customer-create-btn"
        >
          <Plus className="mr-1 h-4 w-4" /> 新建客户
        </Button>
      </div>

      {isAdmin && unassignedCount > 0 && (
        <div
          className="flex items-center gap-2 rounded-lg border border-[hsl(38_80%_90%)] bg-[hsl(38_80%_96%)] px-4 py-3"
          data-testid="customer-unassigned-banner"
        >
          <AlertTriangle className="h-4 w-4 shrink-0 text-[hsl(38_85%_48%)]" />
          <span className="text-sm">
            当前有 <span className="font-semibold">{unassignedCount}</span>{' '}
            个客户未分配负责人
          </span>
          <button
            type="button"
            className="ml-auto text-sm font-medium text-[hsl(217_70%_52%)] hover:underline"
            onClick={() => setOwnerFilter(UNASSIGNED_OWNER_VALUE)}
          >
            去分配
          </button>
        </div>
      )}

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-[hsl(216_15%_50%)]" />
          <Input
            className="pl-9"
            placeholder="搜索客户名称或联系人"
            value={keyword}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
              setKeyword(e.target.value);
              setPage(1);
            }}
          />
        </div>
        <Select
          value={industry}
          onValueChange={(value: string) => {
            setIndustry(value);
            setPage(1);
          }}
        >
          <SelectTrigger className="w-36">
            <SelectValue placeholder="全部行业" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_OWNER_VALUE}>全部行业</SelectItem>
            {INDUSTRY_OPTIONS.map((value: string) => (
              <SelectItem key={value} value={value}>
                {value}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <CustomerOwnerFilter
          value={ownerFilter}
          options={ownerOptions}
          onChange={(value: string) => {
            setOwnerFilter(value);
            setPage(1);
          }}
        />
      </div>

      {isAdmin && (
        <CustomerBatchBar
          selectedCount={selectedIds.length}
          submitting={assigning}
          onAssign={handleBatchAssign}
          onClearSelection={() => setSelectedIds([])}
        />
      )}

      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              {isAdmin && (
                <TableHead className="w-12">
                  <Checkbox
                    checked={allSelected}
                    onCheckedChange={toggleSelectAll}
                    aria-label="全选"
                    data-testid="customer-select-all"
                  />
                </TableHead>
              )}
              <TableHead>客户名称</TableHead>
              <TableHead>所属行业</TableHead>
              <TableHead>负责人</TableHead>
              <TableHead>联系人</TableHead>
              <TableHead>联系电话</TableHead>
              <TableHead>最近跟进</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell
                  colSpan={isAdmin ? 7 : 6}
                  className="py-12 text-center text-[hsl(216_15%_50%)]"
                >
                  加载中...
                </TableCell>
              </TableRow>
            ) : customers.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={isAdmin ? 7 : 6}
                  className="py-12 text-center text-[hsl(216_15%_50%)]"
                >
                  暂无客户数据
                </TableCell>
              </TableRow>
            ) : (
              customers.map((item: CustomerListItem) => (
                <TableRow
                  key={item.id}
                  className="cursor-pointer hover:bg-[hsl(217_40%_95%)]"
                  onClick={() => navigate(`/customers/${item.id}`)}
                >
                  {isAdmin && (
                    <TableCell
                      className="w-12"
                      onClick={(e: React.MouseEvent) => e.stopPropagation()}
                    >
                      <Checkbox
                        checked={selectedIds.includes(item.id)}
                        onCheckedChange={() => toggleSelect(item.id)}
                        aria-label={`选择 ${item.name}`}
                      />
                    </TableCell>
                  )}
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell>{item.industry || '-'}</TableCell>
                  <TableCell>
                    <span className="flex items-center gap-2">
                      {item.ownerId !== null && item.ownerName ? (
                        <span>{item.ownerName}</span>
                      ) : (
                        <Badge className="bg-[hsl(216_12%_94%)] font-normal text-[hsl(216_15%_55%)]">
                          未分配
                        </Badge>
                      )}
                      {isAdmin && (
                        <button
                          type="button"
                          className="text-[hsl(216_15%_50%)] transition-colors hover:text-[hsl(217_70%_52%)]"
                          onClick={(e: React.MouseEvent) => {
                            e.stopPropagation();
                            openTransfer(item);
                          }}
                          title="转移客户"
                        >
                          <ArrowLeftRight className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </span>
                  </TableCell>
                  <TableCell>{item.contactName || '-'}</TableCell>
                  <TableCell>{item.contactPhone || '-'}</TableCell>
                  <TableCell>
                    <span className="flex items-center gap-2">
                      {formatDateTime(item.lastFollowedAt)}
                      {isLongTimeNoFollow(item.lastFollowedAt) && (
                        <Badge className="bg-[hsl(38_80%_96%)] font-normal text-[hsl(38_85%_48%)]">
                          未跟进
                        </Badge>
                      )}
                    </span>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>

        <div className="flex items-center justify-between border-t px-4 py-3">
          <span className="text-sm text-[hsl(216_15%_50%)]">
            共 {total} 条
          </span>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              disabled={page <= 1}
              onClick={() => setPage((p: number) => p - 1)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm">
              {page} / {totalPages}
            </span>
            <Button
              variant="outline"
              size="icon"
              disabled={page >= totalPages}
              onClick={() => setPage((p: number) => p + 1)}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <CustomerFormDialog
        open={formOpen}
        customer={null}
        isAdmin={isAdmin}
        currentUserId={null}
        onClose={() => setFormOpen(false)}
        onSaved={() => {
          setFormOpen(false);
          void loadList();
        }}
      />

      <CustomerTransferDialog
        open={transferTarget !== null}
        customer={transferTarget}
        onClose={() => setTransferTarget(null)}
        onTransferred={handleTransferred}
      />
    </div>
  );
};

export default CustomersPage;
