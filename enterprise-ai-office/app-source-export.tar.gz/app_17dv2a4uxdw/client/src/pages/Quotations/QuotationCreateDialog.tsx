import React, { useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type {
  CreateQuotationRequest,
  CustomerListItem,
  CustomerListResponse,
  ProductCustomOption,
  ProductCustomOptionsResponse,
  ProductOption,
  ProductListResponse,
  ProjectScene,
  QuotationDetail,
  QuotationItemDetail,
  QuotationUnitDetail,
  UpdateQuotationRequest,
} from '@shared/api.interface';
import {
  createQuotation,
  getQuotationDetail,
  updateQuotation,
} from '@client/src/api/quotations';
import { listCustomers } from '@client/src/api/customers';
import {
  getProductCustomOptions,
  listProducts,
} from '@client/src/api/products';
import { Button } from '@client/src/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@client/src/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@client/src/components/ui/alert-dialog';
import QuotationFormFields, {
  createUnitDraft,
  type UnitDraft,
} from './QuotationFormFields';
import QuotationAiPanel from './QuotationAiPanel';
import {
  effectiveOptionPrice,
  isOptionRequiredByScene,
} from './QuotationCustomItemPicker';
import { getApiErrorMessage } from './QuotationStatusBadge';

interface QuotationCreateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
  editingId?: string | null;
}

function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

function collectUnitItemIds(
  unit: UnitDraft,
  options: ProductCustomOption[],
): string[] {
  const requiredIds: string[] = options
    .filter((option: ProductCustomOption) =>
      isOptionRequiredByScene(option, unit.scene),
    )
    .map((option: ProductCustomOption) => option.customItemId);
  return [...new Set([...unit.selectedItemIds, ...requiredIds])];
}

const QuotationCreateDialog: React.FC<QuotationCreateDialogProps> = ({
  open,
  onOpenChange,
  onSaved,
  editingId,
}) => {
  const isEditing: boolean = Boolean(editingId);
  const [customers, setCustomers] = useState<CustomerListItem[]>([]);
  const [customerId, setCustomerId] = useState<string>('');
  const [originalCustomerId, setOriginalCustomerId] = useState<string | null>(
    null,
  );
  const [pendingCustomerId, setPendingCustomerId] = useState<string | null>(
    null,
  );
  const [productOptions, setProductOptions] = useState<ProductOption[]>([]);
  const [productLoading, setProductLoading] = useState<boolean>(false);
  const [units, setUnits] = useState<UnitDraft[]>([createUnitDraft()]);
  const [optionsCache, setOptionsCache] = useState<
    Record<string, ProductCustomOption[]>
  >({});
  const [optionsLoadingIds, setOptionsLoadingIds] = useState<
    Record<string, boolean>
  >({});
  const [remark, setRemark] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);

  const loadCustomOptions = async (productId: string): Promise<void> => {
    if (!productId || optionsCache[productId]) {
      return;
    }
    setOptionsLoadingIds((prev) => ({ ...prev, [productId]: true }));
    try {
      const res: ProductCustomOptionsResponse =
        await getProductCustomOptions(productId);
      setOptionsCache((prev) => ({ ...prev, [productId]: res.items }));
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error('定制项加载失败');
    } finally {
      setOptionsLoadingIds((prev) => ({ ...prev, [productId]: false }));
    }
  };

  const prefillFromDetail = (detail: QuotationDetail): void => {
    setCustomerId(detail.customerId);
    setOriginalCustomerId(detail.customerId);
    setRemark(detail.remark ?? '');
    const drafts: UnitDraft[] = detail.units.map(
      (unit: QuotationUnitDetail) => ({
        ...createUnitDraft(),
        productId: unit.productId,
        scene: unit.projectScene,
        selectedItemIds: unit.items
          .map((item: QuotationItemDetail) => item.customItemId)
          .filter(
            (itemId: string | null): itemId is string => Boolean(itemId),
          ),
      }),
    );
    setUnits(drafts.length > 0 ? drafts : [createUnitDraft()]);
    const productIds: string[] = [
      ...new Set(
        drafts
          .map((draft: UnitDraft) => draft.productId)
          .filter((productId: string) => Boolean(productId)),
      ),
    ];
    void Promise.all(productIds.map((id: string) => loadCustomOptions(id)));
  };

  useEffect(() => {
    if (!open) {
      setCustomerId('');
      setOriginalCustomerId(null);
      setPendingCustomerId(null);
      setUnits([createUnitDraft()]);
      setOptionsCache({});
      setRemark('');
      return;
    }
    let cancelled: boolean = false;
    const init = async (): Promise<void> => {
      setProductLoading(true);
      try {
        const detailPromise: Promise<QuotationDetail | null> = editingId
          ? getQuotationDetail(editingId)
          : Promise.resolve(null);
        const [customersRes, productsRes, detail] = await Promise.all([
          listCustomers({ page: 1, pageSize: 50 }),
          listProducts(),
          detailPromise,
        ]);
        if (cancelled) {
          return;
        }
        setCustomers(customersRes.items);
        setProductOptions(productsRes.items);
        if (detail) {
          prefillFromDetail(detail);
        }
      } catch (error: unknown) {
        logger.error(String(error));
        toast.error(isEditing ? '报价单数据加载失败' : '基础数据加载失败');
      } finally {
        if (!cancelled) {
          setProductLoading(false);
        }
      }
    };
    void init();
    return () => {
      cancelled = true;
    };
  }, [open, editingId]);

  const handleCustomerChange = (nextCustomerId: string): void => {
    if (
      isEditing &&
      originalCustomerId &&
      nextCustomerId !== originalCustomerId
    ) {
      setPendingCustomerId(nextCustomerId);
      return;
    }
    setCustomerId(nextCustomerId);
  };

  const confirmCustomerChange = (): void => {
    if (!pendingCustomerId) {
      return;
    }
    setCustomerId(pendingCustomerId);
    setPendingCustomerId(null);
    setUnits((prev: UnitDraft[]) =>
      prev.map((unit: UnitDraft) => ({ ...unit, selectedItemIds: [] })),
    );
  };

  const handleUnitProductChange = (key: string, productId: string): void => {
    setUnits((prev: UnitDraft[]) =>
      prev.map((unit: UnitDraft) =>
        unit.key === key
          ? { ...unit, productId, selectedItemIds: [] }
          : unit,
      ),
    );
    void loadCustomOptions(productId);
  };

  const handleUnitSceneChange = (key: string, scene: ProjectScene): void => {
    setUnits((prev: UnitDraft[]) =>
      prev.map((unit: UnitDraft) =>
        unit.key === key ? { ...unit, scene } : unit,
      ),
    );
  };

  const handleUnitToggleItem = (
    key: string,
    customItemId: string,
    checked: boolean,
  ): void => {
    setUnits((prev: UnitDraft[]) =>
      prev.map((unit: UnitDraft) => {
        if (unit.key !== key) {
          return unit;
        }
        const nextIds: string[] = checked
          ? [...unit.selectedItemIds, customItemId]
          : unit.selectedItemIds.filter((id: string) => id !== customItemId);
        return { ...unit, selectedItemIds: nextIds };
      }),
    );
  };

  const addUnit = (): void => {
    setUnits((prev: UnitDraft[]) => [...prev, createUnitDraft()]);
  };

  const removeUnit = (key: string): void => {
    setUnits((prev: UnitDraft[]) =>
      prev.length > 1 ? prev.filter((unit: UnitDraft) => unit.key !== key) : prev,
    );
  };

  const totalAmount: number = useMemo(
    () =>
      round2(
        units.reduce((sum: number, unit: UnitDraft) => {
          const product: ProductOption | undefined = productOptions.find(
            (option: ProductOption) => option.id === unit.productId,
          );
          const options: ProductCustomOption[] =
            optionsCache[unit.productId] ?? [];
          const itemIds: string[] = collectUnitItemIds(unit, options);
          const adjustment: number = options
            .filter((option: ProductCustomOption) =>
              itemIds.includes(option.customItemId),
            )
            .reduce(
              (acc: number, option: ProductCustomOption) =>
                round2(acc + effectiveOptionPrice(option, unit.scene)),
              0,
            );
          return round2(sum + (product?.basePrice ?? 0) + adjustment);
        }, 0),
      ),
    [units, productOptions, optionsCache],
  );

  const handleSubmit = async (): Promise<void> => {
    if (!customerId) {
      toast.error('请选择客户');
      return;
    }
    const invalidUnitIndex: number = units.findIndex(
      (unit: UnitDraft) => !unit.productId,
    );
    if (invalidUnitIndex >= 0) {
      toast.error(`请为第 ${invalidUnitIndex + 1} 台选择产品`);
      return;
    }

    const requestData: CreateQuotationRequest = {
      customerId,
      units: units.map((unit: UnitDraft) => ({
        productId: unit.productId,
        projectScene: unit.scene,
        customItemIds: collectUnitItemIds(
          unit,
          optionsCache[unit.productId] ?? [],
        ),
      })),
    };
    if (remark.trim()) {
      requestData.remark = remark.trim();
    }

    setSubmitting(true);
    try {
      if (editingId) {
        const updateData: UpdateQuotationRequest = { ...requestData };
        await updateQuotation(editingId, updateData);
        toast.success('报价单已更新');
      } else {
        await createQuotation(requestData);
        toast.success('报价单创建成功');
      }
      onOpenChange(false);
      onSaved();
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(
        getApiErrorMessage(error, isEditing ? '报价单更新失败' : '报价单创建失败'),
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-h-[90vh] overflow-y-auto rounded-xl sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{isEditing ? '编辑报价' : '新建报价'}</DialogTitle>
          </DialogHeader>
          <QuotationAiPanel
            customerName={
              customers.find(
                (item: CustomerListItem) => item.id === customerId,
              )?.name ?? ''
            }
            onApplySuggestion={(suggestion: string) => setRemark(suggestion)}
          />
          <QuotationFormFields
            customers={customers}
            customerId={customerId}
            onCustomerChange={handleCustomerChange}
            units={units}
            productOptions={productOptions}
            productLoading={productLoading}
            optionsCache={optionsCache}
            optionsLoadingIds={optionsLoadingIds}
            totalAmount={totalAmount}
            remark={remark}
            onRemarkChange={setRemark}
            onProductChange={handleUnitProductChange}
            onSceneChange={handleUnitSceneChange}
            onToggleItem={handleUnitToggleItem}
            onRemoveUnit={removeUnit}
            onAddUnit={addUnit}
          />
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={submitting}
            >
              取消
            </Button>
            <Button
              type="button"
              onClick={() => {
                void handleSubmit();
              }}
              disabled={submitting}
              data-ai-section-type="button"
            >
              {submitting
                ? isEditing
                  ? '保存中...'
                  : '创建中...'
                : isEditing
                  ? '保存修改'
                  : '创建报价单'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={pendingCustomerId !== null}
        onOpenChange={(nextOpen: boolean) => {
          if (!nextOpen) {
            setPendingCustomerId(null);
          }
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>变更客户</AlertDialogTitle>
            <AlertDialogDescription>
              变更客户将清空已选定制项，是否继续？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction onClick={confirmCustomerChange}>
              确认变更
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default QuotationCreateDialog;
