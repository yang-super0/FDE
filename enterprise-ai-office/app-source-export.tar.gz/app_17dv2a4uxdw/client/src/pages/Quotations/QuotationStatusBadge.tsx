import React from 'react';
import { isAxiosError } from 'axios';
import type { QuotationStatus } from '@shared/api.interface';
import { Badge } from '@client/src/components/ui/badge';
import { cn } from '@/lib/utils';

export const QUOTATION_STATUS_LABEL: Record<QuotationStatus, string> = {
  draft: '草稿',
  sent: '已发送',
  confirmed: '已确认',
  closed: '已关闭',
};

export interface QuotationStatusAction {
  target: Exclude<QuotationStatus, 'draft'>;
  label: string;
  variant: 'default' | 'destructive' | 'outline';
}

export const QUOTATION_STATUS_ACTIONS: Record<
  QuotationStatus,
  QuotationStatusAction[]
> = {
  draft: [{ target: 'sent', label: '发送', variant: 'default' }],
  sent: [
    { target: 'confirmed', label: '确认', variant: 'default' },
    { target: 'closed', label: '关闭', variant: 'destructive' },
  ],
  confirmed: [],
  closed: [],
};

const QUOTATION_STATUS_BADGE_CLASS: Record<QuotationStatus, string> = {
  draft: 'border-transparent bg-[hsl(216_12%_94%)] text-[hsl(216_15%_40%)]',
  sent: 'border-transparent bg-accent text-accent-foreground',
  confirmed:
    'border-transparent bg-[hsl(152_55%_96%)] text-[hsl(152_60%_32%)]',
  closed: 'border-transparent bg-[hsl(0_60%_96%)] text-[hsl(0_65%_42%)]',
};

export function formatAmount(value: number): string {
  return `¥ ${value.toLocaleString('zh-CN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function getApiErrorMessage(error: unknown, fallback: string): string {
  if (isAxiosError(error)) {
    const message: unknown = error.response?.data?.message;
    if (typeof message === 'string' && message) {
      return message;
    }
  }
  return fallback;
}

interface QuotationStatusBadgeProps {
  status: QuotationStatus;
}

const QuotationStatusBadge: React.FC<QuotationStatusBadgeProps> = ({
  status,
}) => (
  <Badge
    variant="outline"
    className={cn('rounded-full', QUOTATION_STATUS_BADGE_CLASS[status])}
  >
    {QUOTATION_STATUS_LABEL[status]}
  </Badge>
);

export default QuotationStatusBadge;
