import React from 'react';
import { Badge } from '@client/src/components/ui/badge';
import { Checkbox } from '@client/src/components/ui/checkbox';
import type {
  ProductCustomOption,
  ProjectScene,
} from '@shared/api.interface';

interface QuotationCustomItemPickerProps {
  options: ProductCustomOption[];
  selectedIds: string[];
  scene: ProjectScene;
  loading?: boolean;
  onToggle: (id: string, checked: boolean) => void;
}

export function effectiveOptionPrice(
  option: ProductCustomOption,
  scene: ProjectScene,
): number {
  const conditional: number | undefined = option.conditionalScenes.find(
    (item) => item.scene === scene,
  )?.priceAdjustment;
  return conditional ?? option.priceAdjustment;
}

export function isOptionRequiredByScene(
  option: ProductCustomOption,
  scene: ProjectScene,
): boolean {
  return option.conditionalScenes.some((item) => item.scene === scene);
}

const QuotationCustomItemPicker: React.FC<QuotationCustomItemPickerProps> = ({
  options,
  selectedIds,
  scene,
  loading = false,
  onToggle,
}) => {
  if (loading) {
    return (
      <div className="space-y-2">
        <div className="h-14 animate-pulse rounded-lg bg-accent" />
        <div className="h-14 animate-pulse rounded-lg bg-accent" />
        <div className="h-14 animate-pulse rounded-lg bg-accent" />
      </div>
    );
  }

  if (options.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-border p-4 text-center text-xs text-muted-foreground">
        该产品暂无可选定制项
      </div>
    );
  }

  return (
    <div className="grid gap-2">
      {options.map((option: ProductCustomOption) => {
        const required: boolean = isOptionRequiredByScene(option, scene);
        const checked: boolean = required || selectedIds.includes(option.customItemId);
        return (
          <label
            key={option.customItemId}
            className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 transition-colors ${
              checked
                ? 'border-primary/40 bg-accent/50'
                : 'border-border hover:bg-accent/30'
            } ${required ? 'cursor-not-allowed' : ''}`}
          >
            <Checkbox
              checked={checked}
              disabled={required}
              onCheckedChange={(value: boolean | 'indeterminate') =>
                onToggle(option.customItemId, value === true)
              }
            />
            <div className="flex-1 space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-medium">{option.itemName}</span>
                {required && (
                  <Badge className="bg-primary/10 text-primary">
                    必选（项目场景要求）
                  </Badge>
                )}
              </div>
              {option.description && (
                <p className="text-xs text-muted-foreground">
                  {option.description}
                </p>
              )}
            </div>
            <span className="font-mono text-sm font-medium text-foreground">
              +¥{effectiveOptionPrice(option, scene).toLocaleString('zh-CN')}
              {option.unit ? <span className="text-xs text-muted-foreground"> / {option.unit}</span> : null}
            </span>
          </label>
        );
      })}
    </div>
  );
};

export default QuotationCustomItemPicker;
