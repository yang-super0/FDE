import React, { useMemo } from 'react';
import { Trash2 } from 'lucide-react';
import type {
  ProductCustomOption,
  ProductOption,
  ProjectScene,
} from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import { Label } from '@client/src/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import QuotationCustomItemPicker, {
  effectiveOptionPrice,
  isOptionRequiredByScene,
} from './QuotationCustomItemPicker';
import { formatAmount } from './QuotationStatusBadge';

const PROJECT_SCENES: ProjectScene[] = [
  '普通项目',
  '沿海项目',
  '高速项目',
  '山地项目',
];

interface QuotationUnitEditorProps {
  unitNo: number;
  productOptions: ProductOption[];
  productLoading: boolean;
  productId: string;
  scene: ProjectScene;
  selectedItemIds: string[];
  customOptions: ProductCustomOption[];
  optionsLoading: boolean;
  removable: boolean;
  onProductChange: (productId: string) => void;
  onSceneChange: (scene: ProjectScene) => void;
  onToggleItem: (customItemId: string, checked: boolean) => void;
  onRemove: () => void;
}

function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

export function computeUnitSubtotal(
  product: ProductOption | undefined,
  customOptions: ProductCustomOption[],
  selectedIds: string[],
  scene: ProjectScene,
): number {
  const base: number = product?.basePrice ?? 0;
  const adjustment: number = customOptions
    .filter((option: ProductCustomOption) =>
      selectedIds.includes(option.customItemId),
    )
    .reduce(
      (sum: number, option: ProductCustomOption) =>
        round2(sum + effectiveOptionPrice(option, scene)),
      0,
    );
  return round2(base + adjustment);
}

const QuotationUnitEditor: React.FC<QuotationUnitEditorProps> = ({
  unitNo,
  productOptions,
  productLoading,
  productId,
  scene,
  selectedItemIds,
  customOptions,
  optionsLoading,
  removable,
  onProductChange,
  onSceneChange,
  onToggleItem,
  onRemove,
}) => {
  const selectedProduct: ProductOption | undefined = useMemo(
    () =>
      productOptions.find((option: ProductOption) => option.id === productId),
    [productOptions, productId],
  );

  const requiredItemIds: string[] = useMemo(
    () =>
      customOptions
        .filter((option: ProductCustomOption) =>
          isOptionRequiredByScene(option, scene),
        )
        .map((option: ProductCustomOption) => option.customItemId),
    [customOptions, scene],
  );

  const allSelectedIds: string[] = useMemo(
    () => [...new Set([...selectedItemIds, ...requiredItemIds])],
    [selectedItemIds, requiredItemIds],
  );

  const unitSubtotal: number = useMemo(
    () =>
      computeUnitSubtotal(selectedProduct, customOptions, allSelectedIds, scene),
    [selectedProduct, customOptions, allSelectedIds, scene],
  );

  const toggleItem = (customItemId: string, checked: boolean): void => {
    if (requiredItemIds.includes(customItemId)) {
      return;
    }
    onToggleItem(customItemId, checked);
  };

  return (
    <div className="space-y-3 rounded-lg border border-border p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 font-mono text-xs font-bold text-primary">
            {unitNo}
          </span>
          <span className="text-sm font-medium">第 {unitNo} 台</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-mono text-sm font-bold text-primary">
            {selectedProduct ? `小计 ${formatAmount(unitSubtotal)}` : ''}
          </span>
          {removable ? (
            <Button
              type="button"
              variant="ghost"
              size="icon"
              className="h-7 w-7 text-muted-foreground hover:text-destructive"
              onClick={onRemove}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          ) : null}
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label>
            产品 <span className="text-destructive">*</span>
          </Label>
          {productLoading ? (
            <div className="h-9 w-full animate-pulse rounded-md bg-accent" />
          ) : (
            <Select value={productId} onValueChange={onProductChange}>
              <SelectTrigger>
                <SelectValue placeholder="请选择产品" />
              </SelectTrigger>
              <SelectContent>
                {productOptions.map((option: ProductOption) => (
                  <SelectItem key={option.id} value={option.id}>
                    {option.name}（基础价 {formatAmount(option.basePrice)}）
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>
        <div className="space-y-1.5">
          <Label>项目场景</Label>
          <Select
            value={scene}
            onValueChange={(value: string) =>
              onSceneChange(value as ProjectScene)
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="请选择项目场景" />
            </SelectTrigger>
            <SelectContent>
              {PROJECT_SCENES.map((item: ProjectScene) => (
                <SelectItem key={item} value={item}>
                  {item}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {productId ? (
        <div className="space-y-1.5">
          <Label>定制项（可选）</Label>
          <QuotationCustomItemPicker
            options={customOptions}
            selectedIds={allSelectedIds}
            scene={scene}
            loading={optionsLoading}
            onToggle={toggleItem}
          />
        </div>
      ) : null}
    </div>
  );
};

export default QuotationUnitEditor;
