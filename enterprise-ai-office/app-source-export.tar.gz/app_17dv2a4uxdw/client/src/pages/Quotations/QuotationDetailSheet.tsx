import React, { useCallback, useEffect, useState } from 'react';
import dayjs from 'dayjs';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Can } from '@lark-apaas/client-toolkit/auth';
import type {
  QuotationDetail,
  QuotationItemDetail,
  QuotationStatus,
  QuotationUnitDetail,
} from '@shared/api.interface';
import {
  getQuotationDetail,
  updateQuotationStatus,
} from '@client/src/api/quotations';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@client/src/components/ui/sheet';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@client/src/components/ui/table';
import { Skeleton } from '@client/src/components/ui/skeleton';
import { Sparkles } from 'lucide-react';
import QuotationStatusBadge, {
  formatAmount,
  getApiErrorMessage,
  QUOTATION_STATUS_ACTIONS,
  type QuotationStatusAction,
} from './QuotationStatusBadge';

interface QuotationDetailSheetProps {
  id: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onChanged: () => void;
  refreshSignal?: number;
  onEdit?: (id: string) => void;
}

const QuotationDetailSheet: React.FC<QuotationDetailSheetProps> = ({
  id,
  open,
  onOpenChange,
  onChanged,
  refreshSignal,
  onEdit,
}) => {
  const [detail, setDetail] = useState<QuotationDetail | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [transitioning, setTransitioning] = useState<boolean>(false);

  const fetchDetail = useCallback(async (): Promise<void> => {
    if (!id) {
      return;
    }
    setLoading(true);
    try {
      const res: QuotationDetail = await getQuotationDetail(id);
      setDetail(res);
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(getApiErrorMessage(error, '报价单详情加载失败'));
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    if (open && id) {
      setDetail(null);
      void fetchDetail();
    }
  }, [open, id, refreshSignal, fetchDetail]);

  const handleTransition = async (
    target: Exclude<QuotationStatus, 'draft'>,
  ): Promise<void> => {
    if (!id) {
      return;
    }
    setTransitioning(true);
    try {
      await updateQuotationStatus(id, { status: target });
      toast.success('状态已更新');
      await fetchDetail();
      onChanged();
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(getApiErrorMessage(error, '状态流转失败'));
    } finally {
      setTransitioning(false);
    }
  };

  const actions: QuotationStatusAction[] = detail
    ? QUOTATION_STATUS_ACTIONS[detail.status]
    : [];

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-xl">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-3">
            <span>{detail?.quotationNo ?? '报价单详情'}</span>
            {detail ? <QuotationStatusBadge status={detail.status} /> : null}
          </SheetTitle>
        </SheetHeader>

        {loading ? (
          <div className="space-y-3 px-6 py-4">
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        ) : !detail ? (
          <div className="px-6 py-4 text-sm text-muted-foreground">
            暂无数据
          </div>
        ) : (
          <div className="flex-1 space-y-5 overflow-y-auto px-6 py-4">
            <div className="space-y-2 rounded-lg border p-4">
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm text-muted-foreground">客户</span>
                <span className="truncate text-sm font-medium">
                  {detail.customerName || '—'}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm text-muted-foreground">总台数</span>
                <span className="font-mono text-sm font-medium">
                  {detail.totalUnits} 台
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm text-muted-foreground">
                  更新时间
                </span>
                <span className="text-sm">
                  {dayjs(detail.updatedAt).format('YYYY-MM-DD HH:mm')}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm text-muted-foreground">
                  总金额
                </span>
                <span className="font-mono text-xl font-bold text-primary">
                  {formatAmount(detail.totalAmount)}
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="text-sm font-medium">
                报价明细（共 {detail.totalUnits} 台）
              </h4>
              {detail.units.map((unit: QuotationUnitDetail) => (
                <div
                  key={`${unit.unitNo}`}
                  className="space-y-2 rounded-lg border border-border p-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant="outline" className="font-mono">
                        第 {unit.unitNo} 台
                      </Badge>
                      <span className="text-sm font-medium">
                        {unit.productName || '自定义明细'}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {unit.projectScene}
                      </span>
                    </div>
                    <span className="font-mono text-sm font-bold">
                      小计 {formatAmount(unit.unitSubtotal)}
                    </span>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>名称</TableHead>
                        <TableHead className="text-right">金额</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {unit.productName && unit.basePrice > 0 ? (
                        <TableRow>
                          <TableCell className="break-words">
                            {unit.productName}（基础价）
                          </TableCell>
                          <TableCell className="text-right font-mono">
                            {formatAmount(unit.basePrice)}
                          </TableCell>
                        </TableRow>
                      ) : null}
                      {unit.items.map((item: QuotationItemDetail) => (
                        <TableRow key={item.id}>
                          <TableCell className="break-words">
                            <span className="inline-flex flex-wrap items-center gap-1.5">
                              {item.itemName}
                              {item.requiredByScene ? (
                                <Badge className="bg-primary/10 text-primary">
                                  必选
                                </Badge>
                              ) : null}
                            </span>
                          </TableCell>
                          <TableCell className="text-right font-mono">
                            {formatAmount(
                              item.priceAdjustment ?? item.amount,
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                      {unit.productName &&
                      unit.basePrice > 0 &&
                      unit.items.length === 0 ? (
                        <TableRow>
                          <TableCell
                            colSpan={2}
                            className="text-center text-xs text-muted-foreground"
                          >
                            无定制项
                          </TableCell>
                        </TableRow>
                      ) : null}
                    </TableBody>
                  </Table>
                </div>
              ))}
              <div className="flex items-center justify-between rounded-lg bg-accent p-3">
                <span className="text-sm font-medium">
                  总合计（{detail.totalUnits} 台）
                </span>
                <span className="font-mono text-lg font-bold text-primary">
                  {formatAmount(detail.totalAmount)}
                </span>
              </div>
            </div>

            {detail.remark ? (
              <div className="space-y-1">
                <h4 className="text-sm font-medium">报价说明</h4>
                <p className="whitespace-pre-wrap break-words rounded-lg border p-3 text-sm text-muted-foreground">
                  {detail.remark}
                </p>
              </div>
            ) : null}

            {detail.aiSuggestion ? (
              <div className="space-y-1 rounded-lg bg-accent p-3">
                <div className="flex items-center gap-1.5 text-xs font-medium text-accent-foreground">
                  <Sparkles className="size-3.5" />
                  AI 建议
                </div>
                <p className="whitespace-pre-wrap break-words text-sm text-foreground">
                  {detail.aiSuggestion}
                </p>
              </div>
            ) : null}
          </div>
        )}

        {detail && (actions.length > 0 || (detail.status === 'draft' && onEdit)) ? (
          <div className="flex items-center justify-end gap-2 border-t px-6 py-4">
            {detail.status === 'draft' && onEdit ? (
              <Can action="operate" subject="Quotation">
                <Button
                  variant="outline"
                  onClick={() => onEdit(detail.id)}
                  data-ai-section-type="button"
                >
                  编辑
                </Button>
              </Can>
            ) : null}
            <Can action="operate" subject="Quotation">
              {actions.map((action: QuotationStatusAction) => (
                <Button
                  key={action.target}
                  variant={action.variant}
                  disabled={transitioning}
                  onClick={() => {
                    void handleTransition(action.target);
                  }}
                  data-ai-section-type="button"
                >
                  {action.label}
                </Button>
              ))}
            </Can>
          </div>
        ) : null}
      </SheetContent>
    </Sheet>
  );
};

export default QuotationDetailSheet;
