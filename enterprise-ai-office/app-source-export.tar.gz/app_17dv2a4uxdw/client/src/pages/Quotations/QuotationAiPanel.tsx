import React, { useState } from 'react';
import { capabilityClient } from '@lark-apaas/client-toolkit';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { Sparkles } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import { Textarea } from '@client/src/components/ui/textarea';
import { Label } from '@client/src/components/ui/label';
import type {
  QuotationAiGenerateOneOutput,
} from '@shared/plugin-types';
import { formatAmount } from './QuotationStatusBadge';

interface AiQuotationItem {
  itemName: string;
  quantity: number;
  unitPrice: number;
}

interface AiGenerateResult {
  suggestion: string;
  items: AiQuotationItem[];
}

interface QuotationAiPanelProps {
  customerName: string;
  onApplySuggestion: (suggestion: string) => void;
}

function parseItems(itemsJson: string): AiQuotationItem[] {
  try {
    const parsed: unknown = JSON.parse(itemsJson);
    if (!Array.isArray(parsed)) {
      return [];
    }
    return parsed
      .filter((row: unknown): row is Record<string, unknown> =>
        Boolean(row) && typeof row === 'object')
      .map((row: Record<string, unknown>): AiQuotationItem => ({
        itemName: String(row.itemName ?? ''),
        quantity: Number(row.quantity ?? 0),
        unitPrice: Number(row.unitPrice ?? 0),
      }))
      .filter((item: AiQuotationItem) => item.itemName.length > 0);
  } catch (error) {
    logger.error(`AI 报价明细解析失败: ${String(error)}`);
    return [];
  }
}

const QuotationAiPanel: React.FC<QuotationAiPanelProps> = ({
  customerName,
  onApplySuggestion,
}) => {
  const [requirementDesc, setRequirementDesc] = useState<string>('');
  const [generating, setGenerating] = useState<boolean>(false);
  const [result, setResult] = useState<AiGenerateResult | null>(null);

  const handleGenerate = async (): Promise<void> => {
    const desc: string = requirementDesc.trim();
    if (desc.length === 0) {
      toast.error('请先输入客户需求描述');
      return;
    }
    setGenerating(true);
    try {
      const descInput: string = customerName.length > 0
        ? `客户：${customerName}\n${desc}`
        : desc;
      const output: QuotationAiGenerateOneOutput = await capabilityClient
        .load('quotation_ai_generate_1')
        .call<QuotationAiGenerateOneOutput>('textToJson', {
          requirementDesc: descInput,
        });
      const items: AiQuotationItem[] = parseItems(output.itemsJson ?? '');
      const suggestion: string = String(output.suggestion ?? '').trim();
      if (items.length === 0 && suggestion.length === 0) {
        toast.error('AI 未返回有效内容，请补充需求描述后重试');
        return;
      }
      setResult({ suggestion, items });
      toast.success('AI 报价生成完成，请核对后采纳');
    } catch (error) {
      logger.error(`AI 报价生成失败: ${String(error)}`);
      toast.error('AI 报价生成失败，请重试');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="space-y-3 rounded-lg border p-4">
      <div className="flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-primary" />
        <span className="text-sm font-medium">AI 智能报价</span>
        <span className="text-xs text-muted-foreground">
          输入客户需求，自动生成报价明细与报价建议
        </span>
      </div>
      <Textarea
        value={requirementDesc}
        onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) =>
          setRequirementDesc(event.target.value)}
        rows={3}
        placeholder="请描述客户需求，例如：客户需要采购一台 FZQ-12 防撞墙台车，要求含安装调试与一年质保，预算 50 万左右..."
      />
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={() => {
          void handleGenerate();
        }}
        disabled={generating}
        data-ai-section-type="button"
      >
        <Sparkles className="h-4 w-4" />
        {generating ? 'AI 生成中...' : 'AI 生成报价'}
      </Button>

      {result !== null && (
        <div className="space-y-3 rounded-lg bg-accent p-3">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-medium text-accent-foreground">
              AI 生成结果（请核对后使用）
            </span>
            {result.suggestion.length > 0 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  onApplySuggestion(result.suggestion);
                  toast.success('报价建议已填入报价说明');
                }}
              >
                采纳建议至报价说明
              </Button>
            )}
          </div>
          {result.items.length > 0 && (
            <div className="overflow-hidden rounded-md border bg-card">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40 text-left text-xs text-muted-foreground">
                    <th className="px-3 py-2 font-medium">明细名称</th>
                    <th className="px-3 py-2 text-right font-medium">数量</th>
                    <th className="px-3 py-2 text-right font-medium">单价</th>
                    <th className="px-3 py-2 text-right font-medium">金额</th>
                  </tr>
                </thead>
                <tbody>
                  {result.items.map((item: AiQuotationItem, index: number) => (
                    <tr key={`${item.itemName}-${index}`} className="border-b last:border-b-0">
                      <td className="px-3 py-2">{item.itemName}</td>
                      <td className="px-3 py-2 text-right font-mono">
                        {item.quantity}
                      </td>
                      <td className="px-3 py-2 text-right font-mono">
                        {formatAmount(item.unitPrice)}
                      </td>
                      <td className="px-3 py-2 text-right font-mono">
                        {formatAmount(item.quantity * item.unitPrice)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {result.suggestion.length > 0 && (
            <div className="space-y-1">
              <Label className="text-xs text-accent-foreground">
                报价建议
              </Label>
              <p className="whitespace-pre-wrap text-sm leading-relaxed">
                {result.suggestion}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default QuotationAiPanel;
