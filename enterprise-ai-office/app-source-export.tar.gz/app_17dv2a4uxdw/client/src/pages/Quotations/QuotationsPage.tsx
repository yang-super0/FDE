import React, { useCallback, useEffect, useState } from 'react';
import dayjs from 'dayjs';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Can } from '@lark-apaas/client-toolkit/auth';
import {
  Table,
  type TableColumnsType,
} from '@lark-apaas/client-toolkit/antd-table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@client/src/components/ui/dropdown-menu';
import { ChevronDown, FileText, Plus } from 'lucide-react';
import type {
  QuotationListItem,
  QuotationListParams,
  QuotationListResponse,
  QuotationStatus,
  QuotationUnitSummary,
} from '@shared/api.interface';
import {
  listQuotations,
  updateQuotationStatus,
} from '@client/src/api/quotations';
import { Button } from '@client/src/components/ui/button';
import { Card, CardContent } from '@client/src/components/ui/card';
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from '@client/src/components/ui/empty';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import QuotationStatusBadge, {
  formatAmount,
  getApiErrorMessage,
  QUOTATION_STATUS_ACTIONS,
  QUOTATION_STATUS_LABEL,
  type QuotationStatusAction,
} from './QuotationStatusBadge';
import QuotationDetailSheet from './QuotationDetailSheet';
import QuotationCreateDialog from './QuotationCreateDialog';

const ALL_STATUS: string = '__all__';
const DEFAULT_PAGE_SIZE: number = 20;
const QUOTATION_STATUS_FILTERS: QuotationStatus[] = [
  'draft',
  'sent',
  'confirmed',
  'closed',
];

const QuotationsPage: React.FC = () => {
  const [statusFilter, setStatusFilter] = useState<string>(ALL_STATUS);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(DEFAULT_PAGE_SIZE);
  const [items, setItems] = useState<QuotationListItem[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);
  const [formOpen, setFormOpen] = useState<boolean>(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [detailId, setDetailId] = useState<string | null>(null);
  const [detailOpen, setDetailOpen] = useState<boolean>(false);
  const [detailVersion, setDetailVersion] = useState<number>(0);

  const fetchList = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const params: QuotationListParams = {
        page,
        pageSize,
        status:
          statusFilter === ALL_STATUS
            ? undefined
            : (statusFilter as QuotationStatus),
      };
      const res: QuotationListResponse = await listQuotations(params);
      setItems(res.items);
      setTotal(res.total);
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error('报价单列表加载失败');
    } finally {
      setLoading(false);
    }
  }, [statusFilter, page, pageSize]);

  useEffect(() => {
    void fetchList();
  }, [fetchList]);

  const handleView = (id: string): void => {
    setDetailId(id);
    setDetailOpen(true);
  };

  const handleCreate = (): void => {
    setEditingId(null);
    setFormOpen(true);
  };

  const handleEdit = (id: string): void => {
    setEditingId(id);
    setFormOpen(true);
  };

  const handleFormSaved = (): void => {
    void fetchList();
    setDetailVersion((version: number) => version + 1);
  };

  const handleTransition = async (
    id: string,
    target: Exclude<QuotationStatus, 'draft'>,
  ): Promise<void> => {
    try {
      await updateQuotationStatus(id, { status: target });
      toast.success('状态已更新');
      void fetchList();
    } catch (error: unknown) {
      logger.error(String(error));
      toast.error(getApiErrorMessage(error, '状态流转失败'));
    }
  };

  const columns: TableColumnsType<QuotationListItem> = [
    {
      title: '报价单号',
      dataIndex: 'quotationNo',
      fixed: 'left',
      width: 170,
      render: (quotationNo: string, record: QuotationListItem) => (
        <button
          type="button"
          className="text-primary hover:underline"
          onClick={() => handleView(record.id)}
        >
          {quotationNo}
        </button>
      ),
    },
    {
      title: '客户',
      dataIndex: 'customerName',
      width: 180,
      render: (value: string) => value || '—',
    },
    {
      title: '产品',
      dataIndex: 'unitSummary',
      width: 240,
      render: (_: unknown, record: QuotationListItem) => {
        if (record.unitSummary.length > 0) {
          return (
            <span className="break-words">
              {record.unitSummary
                .map(
                  (summary: QuotationUnitSummary) =>
                    `${summary.productName} ×${summary.count}`,
                )
                .join(' + ')}
            </span>
          );
        }
        return record.productName || '—';
      },
    },
    {
      title: '总台数',
      dataIndex: 'totalUnits',
      width: 90,
      align: 'center',
      render: (value: number) => (
        <span className="font-mono">{value}</span>
      ),
    },
    {
      title: '总金额',
      dataIndex: 'totalAmount',
      width: 150,
      align: 'right',
      render: (value: number) => (
        <span className="font-mono">{formatAmount(value)}</span>
      ),
    },
    {
      title: '状态',
      dataIndex: 'status',
      width: 110,
      render: (status: QuotationStatus) => (
        <QuotationStatusBadge status={status} />
      ),
    },
    {
      title: '更新时间',
      dataIndex: 'updatedAt',
      width: 170,
      render: (value: string) => dayjs(value).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: '操作',
      key: 'action',
      fixed: 'right',
      width: 220,
      render: (_: unknown, record: QuotationListItem) => {
        const actions: QuotationStatusAction[] =
          QUOTATION_STATUS_ACTIONS[record.status];
        return (
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleView(record.id)}
            >
              查看
            </Button>
            {record.status === 'draft' ? (
              <Can action="operate" subject="Quotation">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleEdit(record.id)}
                >
                  编辑
                </Button>
              </Can>
            ) : null}
            {actions.length > 0 ? (
              <Can action="operate" subject="Quotation">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      流转
                      <ChevronDown className="size-3.5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    {actions.map((action: QuotationStatusAction) => (
                      <DropdownMenuItem
                        key={action.target}
                        onSelect={() => {
                          void handleTransition(record.id, action.target);
                        }}
                      >
                        {action.label}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              </Can>
            ) : null}
          </div>
        );
      },
    },
  ];

  return (
    <div className="mx-auto max-w-[1400px] space-y-4 p-6">
      <div className="flex flex-wrap items-center gap-3">
        <Select
          value={statusFilter}
          onValueChange={(value: string) => {
            setStatusFilter(value);
            setPage(1);
          }}
        >
          <SelectTrigger className="w-40">
            <SelectValue placeholder="选择状态" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL_STATUS}>全部状态</SelectItem>
            {QUOTATION_STATUS_FILTERS.map((status: QuotationStatus) => (
              <SelectItem key={status} value={status}>
                {QUOTATION_STATUS_LABEL[status]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Can action="operate" subject="Quotation">
          <Button
            className="ml-auto"
            onClick={handleCreate}
            data-ai-section-type="button"
          >
            <Plus className="mr-2 size-4" />
            新建报价
          </Button>
        </Can>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table
            columns={columns}
            dataSource={items}
            loading={loading}
            rowKey="id"
            scroll={{ x: 1280, y: 500 }}
            pagination={{
              current: page,
              pageSize,
              total,
              showSizeChanger: true,
              onChange: (nextPage: number, nextPageSize: number) => {
                setPage(nextPage);
                setPageSize(nextPageSize);
              },
            }}
            locale={{
              emptyText: (
                <Empty>
                  <EmptyHeader>
                    <EmptyMedia variant="icon">
                      <FileText className="size-6" />
                    </EmptyMedia>
                    <EmptyTitle>暂无报价单</EmptyTitle>
                    <EmptyDescription>
                      调整状态筛选条件，或点击「新建报价」创建第一张报价单
                    </EmptyDescription>
                  </EmptyHeader>
                </Empty>
              ),
            }}
          />
        </CardContent>
      </Card>

      <QuotationDetailSheet
        id={detailId}
        open={detailOpen}
        onOpenChange={setDetailOpen}
        onChanged={() => {
          void fetchList();
        }}
        refreshSignal={detailVersion}
        onEdit={handleEdit}
      />

      <QuotationCreateDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        editingId={editingId}
        onSaved={handleFormSaved}
      />
    </div>
  );
};

export default QuotationsPage;
