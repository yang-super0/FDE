import React from 'react';
import { Plus } from 'lucide-react';
import type {
  CustomerListItem,
  ProductCustomOption,
  ProductOption,
  ProjectScene,
} from '@shared/api.interface';
import { Button } from '@client/src/components/ui/button';
import { Label } from '@client/src/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import { Textarea } from '@client/src/components/ui/textarea';
import QuotationUnitEditor from './QuotationUnitEditor';
import { formatAmount } from './QuotationStatusBadge';

export interface UnitDraft {
  key: string;
  productId: string;
  scene: ProjectScene;
  selectedItemIds: string[];
}

let unitKeySeq: number = 0;
export function createUnitDraft(): UnitDraft {
  unitKeySeq += 1;
  return {
    key: `unit-${unitKeySeq}`,
    productId: '',
    scene: '普通项目',
    selectedItemIds: [],
  };
}

interface QuotationFormFieldsProps {
  customers: CustomerListItem[];
  customerId: string;
  onCustomerChange: (customerId: string) => void;
  units: UnitDraft[];
  productOptions: ProductOption[];
  productLoading: boolean;
  optionsCache: Record<string, ProductCustomOption[]>;
  optionsLoadingIds: Record<string, boolean>;
  totalAmount: number;
  remark: string;
  onRemarkChange: (value: string) => void;
  onProductChange: (key: string, productId: string) => void;
  onSceneChange: (key: string, scene: ProjectScene) => void;
  onToggleItem: (key: string, customItemId: string, checked: boolean) => void;
  onRemoveUnit: (key: string) => void;
  onAddUnit: () => void;
}

const QuotationFormFields: React.FC<QuotationFormFieldsProps> = ({
  customers,
  customerId,
  onCustomerChange,
  units,
  productOptions,
  productLoading,
  optionsCache,
  optionsLoadingIds,
  totalAmount,
  remark,
  onRemarkChange,
  onProductChange,
  onSceneChange,
  onToggleItem,
  onRemoveUnit,
  onAddUnit,
}) => {
  return (
    <div className="space-y-5">
      <div className="space-y-2">
        <Label>
          客户 <span className="text-destructive">*</span>
        </Label>
        <Select value={customerId} onValueChange={onCustomerChange}>
          <SelectTrigger>
            <SelectValue placeholder="请选择客户" />
          </SelectTrigger>
          <SelectContent>
            {customers.map((item: CustomerListItem) => (
              <SelectItem key={item.id} value={item.id}>
                {item.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-3">
        {units.map((unit: UnitDraft, index: number) => (
          <QuotationUnitEditor
            key={unit.key}
            unitNo={index + 1}
            productOptions={productOptions}
            productLoading={productLoading}
            productId={unit.productId}
            scene={unit.scene}
            selectedItemIds={unit.selectedItemIds}
            customOptions={optionsCache[unit.productId] ?? []}
            optionsLoading={optionsLoadingIds[unit.productId] ?? false}
            removable={units.length > 1}
            onProductChange={(productId: string) =>
              onProductChange(unit.key, productId)
            }
            onSceneChange={(scene: ProjectScene) =>
              onSceneChange(unit.key, scene)
            }
            onToggleItem={(customItemId: string, checked: boolean) =>
              onToggleItem(unit.key, customItemId, checked)
            }
            onRemove={() => onRemoveUnit(unit.key)}
          />
        ))}
        <Button
          type="button"
          variant="outline"
          className="w-full border-dashed"
          onClick={onAddUnit}
          data-ai-section-type="button"
        >
          <Plus className="mr-1 h-4 w-4" />
          添加一台
        </Button>
      </div>

      <div className="flex items-center justify-between rounded-lg bg-accent p-3">
        <span className="text-sm font-medium">
          共 {units.length} 台 · 预估总价
        </span>
        <span className="font-mono text-lg font-bold text-primary">
          {formatAmount(totalAmount)}
        </span>
      </div>

      <div className="space-y-2">
        <Label>报价说明</Label>
        <Textarea
          value={remark}
          onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) =>
            onRemarkChange(event.target.value)
          }
          placeholder="请输入报价说明（可选）"
          rows={2}
        />
      </div>
    </div>
  );
};

export default QuotationFormFields;
