import React, { useState } from 'react';
import dayjs from 'dayjs';
import { CalendarIcon } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@client/src/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@client/src/components/ui/popover';
import { Calendar } from '@client/src/components/ui/calendar';
import { Button } from '@client/src/components/ui/button';
import type {
  DashboardOwnerOption,
  DashboardRange,
} from '@shared/api.interface';
import { cn } from '@client/src/lib/utils';

export interface DashboardFilterState {
  range: DashboardRange;
  startDate: string;
  endDate: string;
  ownerId: string;
}

interface StatsFiltersProps {
  filters: DashboardFilterState;
  owners: DashboardOwnerOption[];
  onChange: (next: DashboardFilterState) => void;
}

const RANGE_OPTIONS: { value: DashboardRange; label: string }[] = [
  { value: '7d', label: '近7天' },
  { value: '30d', label: '近30天' },
  { value: '90d', label: '近90天' },
  { value: 'year', label: '本年度' },
  { value: 'custom', label: '自定义' },
];

const DAY_FORMAT: string = 'YYYY-MM-DD';

function DatePicker({
  value,
  onChange,
}: {
  value: string;
  onChange: (day: string) => void;
}) {
  const [open, setOpen] = useState<boolean>(false);
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={cn(
            'w-[130px] justify-start text-left font-normal',
            !value && 'text-muted-foreground'
          )}
        >
          <CalendarIcon className="mr-1.5 h-3.5 w-3.5" />
          {value ? dayjs(value).format('YYYY/MM/DD') : '选择日期'}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar
          mode="single"
          selected={value ? dayjs(value).toDate() : undefined}
          onSelect={(date: Date | undefined) => {
            if (date) {
              onChange(dayjs(date).format(DAY_FORMAT));
            }
            setOpen(false);
          }}
        />
      </PopoverContent>
    </Popover>
  );
}

const StatsFilters: React.FC<StatsFiltersProps> = ({
  filters,
  owners,
  onChange,
}) => {
  return (
    <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-card p-3 shadow-sm">
      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground">时间范围</span>
        <Select
          value={filters.range}
          onValueChange={(value: string) =>
            onChange({ ...filters, range: value as DashboardRange })}
        >
          <SelectTrigger className="w-[120px]">
            <SelectValue placeholder="请选择" />
          </SelectTrigger>
          <SelectContent>
            {RANGE_OPTIONS.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {filters.range === 'custom' && (
        <div className="flex items-center gap-2">
          <DatePicker
            value={filters.startDate}
            onChange={(day: string) =>
              onChange({ ...filters, startDate: day })}
          />
          <span className="text-sm text-muted-foreground">至</span>
          <DatePicker
            value={filters.endDate}
            onChange={(day: string) =>
              onChange({ ...filters, endDate: day })}
          />
        </div>
      )}

      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground">负责人</span>
        <Select
          value={filters.ownerId || 'all'}
          onValueChange={(value: string) =>
            onChange({
              ...filters,
              ownerId: value === 'all' ? '' : value,
            })}
        >
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="全部" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部</SelectItem>
            {owners.map((owner: DashboardOwnerOption) => (
              <SelectItem key={owner.userId} value={owner.userId}>
                {owner.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default StatsFilters;
