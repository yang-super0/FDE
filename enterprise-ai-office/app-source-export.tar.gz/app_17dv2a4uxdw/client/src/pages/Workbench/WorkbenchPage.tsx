import React, { useCallback, useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import dayjs from 'dayjs';
import { useNavigate } from 'react-router-dom';
import { AlertCircle, AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@client/src/components/ui/button';
import { getStats, getOwners, getTodos } from '@client/src/api/dashboard';
import { getCurrentUserRole, getUnassignedCount } from '@client/src/api/customers';
import type {
  DashboardOwnerOption,
  DashboardStats,
  DashboardTodos,
} from '@shared/api.interface';
import GreetingBar from './GreetingBar';
import OverviewCards from './OverviewCards';
import StatsFilters, { type DashboardFilterState } from './StatsFilters';
import TrendCharts from './TrendCharts';
import DistributionCharts from './DistributionCharts';
import MetricsCards from './MetricsCards';
import TodoReminders from './TodoReminders';
import AlertPanel from './AlertPanel';

const DAY_FORMAT: string = 'YYYY-MM-DD';

const WorkbenchPage: React.FC = () => {
  const [todos, setTodos] = useState<DashboardTodos | null>(null);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [owners, setOwners] = useState<DashboardOwnerOption[]>([]);
  const [filters, setFilters] = useState<DashboardFilterState>({
    range: '30d',
    startDate: dayjs().subtract(6, 'day').format(DAY_FORMAT),
    endDate: dayjs().format(DAY_FORMAT),
    ownerId: '',
  });
  const [loading, setLoading] = useState<boolean>(true);
  const [statsLoading, setStatsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [unassignedCount, setUnassignedCount] = useState<number>(0);
  const navigate = useNavigate();

  const loadBase = useCallback(async (): Promise<void> => {
    setLoading(true);
    setError(null);
    try {
      const [todosData, ownersData] = await Promise.all([
        getTodos(),
        getOwners(),
      ]);
      setTodos(todosData);
      setOwners(ownersData);
    } catch (err) {
      logger.error(`Workbench data load failed: ${String(err)}`);
      setError('工作台数据加载失败，请稍后重试');
      toast.error('工作台数据加载失败');
    } finally {
      setLoading(false);
    }
  }, []);

  const loadStats = useCallback(async (
    current: DashboardFilterState
  ): Promise<void> => {
    if (
      current.range === 'custom' &&
      (!current.startDate || !current.endDate)
    ) {
      return;
    }
    setStatsLoading(true);
    try {
      const statsData: DashboardStats = await getStats({
        range: current.range,
        startDate: current.range === 'custom'
          ? current.startDate
          : undefined,
        endDate: current.range === 'custom' ? current.endDate : undefined,
        ownerId: current.ownerId || undefined,
      });
      setStats(statsData);
    } catch (err) {
      logger.error(`Business dashboard data load failed: ${String(err)}`);
      toast.error('经营看板数据加载失败，请稍后重试');
    } finally {
      setStatsLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadBase();
  }, [loadBase]);

  useEffect(() => {
    void loadStats(filters);
  }, [filters, loadStats]);

  useEffect(() => {
    let cancelled: boolean = false;
    const loadUnassignedBanner = async (): Promise<void> => {
      try {
        const [role, unassigned] = await Promise.all([
          getCurrentUserRole(),
          getUnassignedCount(),
        ]);
        if (!cancelled) {
          setIsAdmin(role.isAdmin === true);
          setUnassignedCount(unassigned.count);
        }
      } catch (err) {
        logger.error(`Unassigned customers banner load failed: ${String(err)}`);
        if (!cancelled) {
          setIsAdmin(false);
          setUnassignedCount(0);
        }
      }
    };
    void loadUnassignedBanner();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="flex flex-col gap-4 p-6">
      <GreetingBar />
      {isAdmin && unassignedCount > 0 ? (
        <div
          data-testid="workbench-unassigned-banner"
          className="rounded-lg border border-[hsl(38_80%_96%)] bg-[hsl(38_80%_96%)] px-4 py-3 flex items-center gap-2"
        >
          <AlertTriangle className="h-4 w-4 shrink-0 text-[hsl(38_85%_48%)]" />
          <p className="text-sm text-foreground">
            当前有{' '}
            <span className="font-semibold">{unassignedCount}</span>{' '}
            个客户未分配负责人
          </p>
          <button
            type="button"
            className="ml-auto text-sm font-medium text-[hsl(217_70%_52%)] hover:underline"
            onClick={() => navigate('/customers?ownerFilter=unassigned')}
            data-ai-section-type="button"
          >
            去分配
          </button>
        </div>
      ) : null}
      {error !== null ? (
        <div className="flex flex-col items-center gap-3 rounded-lg border border-[hsl(0_65%_52%)] bg-[hsl(0_60%_96%)] p-10 text-center">
          <AlertCircle className="h-8 w-8 text-[hsl(0_65%_52%)]" />
          <p className="text-sm text-[hsl(0_65%_42%)]">{error}</p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => void loadBase()}
            data-ai-section-type="button"
          >
            <RefreshCw className="h-4 w-4" />
            重试
          </Button>
        </div>
      ) : (
        <>
          <OverviewCards data={stats?.cards ?? null} loading={statsLoading} />
          <StatsFilters
            filters={filters}
            owners={owners}
            onChange={setFilters}
          />
          <TrendCharts
            quotationTrend={stats?.quotationTrend ?? []}
            customerTrend={stats?.customerTrend ?? []}
          />
          <DistributionCharts
            projectStatusDist={stats?.projectStatusDist ?? []}
            reportRateTrend={stats?.reportRateTrend ?? []}
          />
          <MetricsCards metrics={stats?.metrics ?? null} loading={statsLoading} />
          <TodoReminders todos={todos} loading={loading} />
          <AlertPanel isAdmin={isAdmin} />
        </>
      )}
    </div>
  );
};

export default WorkbenchPage;
