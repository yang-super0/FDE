import React from 'react';
import dayjs from 'dayjs';
import { useCurrentUserProfile } from '@lark-apaas/client-toolkit/hooks/useCurrentUserProfile';

const WEEK_LABELS: string[] = ['日', '一', '二', '三', '四', '五', '六'];

const GreetingBar: React.FC = () => {
  const userInfo = useCurrentUserProfile();
  const name: string = userInfo?.name || '用户';
  const now: dayjs.Dayjs = dayjs();
  const dateText: string = `${now.format('YYYY年M月D日')} 星期${
    WEEK_LABELS[now.day()] ?? ''
  }`;

  return (
    <section className="rounded-lg bg-gradient-to-r from-primary to-[hsl(217_70%_40%)] p-6 text-primary-foreground shadow-sm">
      <h1 className="text-xl font-semibold">{name}，欢迎回来</h1>
      <p className="mt-1 text-sm text-primary-foreground/80">
        {dateText} · 经营概况一屏掌握
      </p>
    </section>
  );
};

export default GreetingBar;
