import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  CalendarClock,
  Inbox,
  PhoneCall,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@client/src/components/ui/card';
import {
  Empty,
  EmptyDescription,
  EmptyMedia,
  EmptyTitle,
} from '@client/src/components/ui/empty';
import { Skeleton } from '@client/src/components/ui/skeleton';
import type { DashboardTodos } from '@shared/api.interface';

interface TodoRemindersProps {
  todos: DashboardTodos | null;
  loading: boolean;
}

const TodoReminders: React.FC<TodoRemindersProps> = ({ todos, loading }) => {
  const navigate = useNavigate();

  if (loading) {
    return (
      <section className="flex flex-col gap-4">
        <h2 className="text-lg font-semibold">待办提醒</h2>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <Card className="rounded-lg p-6">
            <Skeleton className="h-5 w-28" />
            <Skeleton className="mt-4 h-12 w-full" />
            <Skeleton className="mt-2 h-12 w-full" />
          </Card>
          <Card className="rounded-lg p-6">
            <Skeleton className="h-5 w-28" />
            <Skeleton className="mt-4 h-12 w-full" />
            <Skeleton className="mt-2 h-12 w-full" />
          </Card>
        </div>
      </section>
    );
  }

  const hasTodos: boolean =
    (todos?.followUps.length ?? 0) > 0 ||
    (todos?.nearingProjects.length ?? 0) > 0 ||
    todos?.dailyReportMissing === true;

  return (
    <section className="flex flex-col gap-4">
      <h2 className="text-lg font-semibold">待办提醒</h2>
      {!hasTodos ? (
        <Card className="rounded-lg shadow-sm">
          <CardContent className="p-6">
            <Empty className="border-0 p-4">
              <EmptyMedia variant="icon">
                <Inbox className="h-5 w-5 text-primary" />
              </EmptyMedia>
              <EmptyTitle>暂无待办提醒</EmptyTitle>
              <EmptyDescription>
                当前没有需要跟进的客户、临期项目，今日日报也已就绪
              </EmptyDescription>
            </Empty>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card className="rounded-lg shadow-sm">
              <CardHeader className="p-4 pb-2">
                <CardTitle className="flex items-center gap-2 text-base">
                  <PhoneCall className="h-4 w-4 text-primary" />
                  客户跟进提醒
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-1 p-4 pt-1">
                {(todos?.followUps ?? []).length === 0 ? (
                  <p className="py-4 text-center text-sm text-muted-foreground">
                    未来 7 天暂无客户跟进计划
                  </p>
                ) : (
                  (todos?.followUps ?? []).map((item) => (
                    <button
                      key={`${item.customerId}-${item.nextFollowAt}`}
                      type="button"
                      className="flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left transition-colors duration-200 hover:bg-accent"
                      onClick={() => navigate(`/customers/${item.customerId}`)}
                    >
                      <span className="truncate text-sm font-medium">
                        {item.customerName}
                      </span>
                      <span className="ml-3 shrink-0 rounded-full bg-[hsl(38_80%_96%)] px-2.5 py-0.5 text-xs text-[hsl(38_85%_38%)]">
                        {item.nextFollowAt}
                      </span>
                    </button>
                  ))
                )}
              </CardContent>
            </Card>

            <Card className="rounded-lg shadow-sm">
              <CardHeader className="p-4 pb-2">
                <CardTitle className="flex items-center gap-2 text-base">
                  <CalendarClock className="h-4 w-4 text-primary" />
                  临期项目
                </CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-1 p-4 pt-1">
                {(todos?.nearingProjects ?? []).length === 0 ? (
                  <p className="py-4 text-center text-sm text-muted-foreground">
                    未来 7 天暂无临期项目
                  </p>
                ) : (
                  (todos?.nearingProjects ?? []).map((item) => (
                    <button
                      key={item.projectId}
                      type="button"
                      className="flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left transition-colors duration-200 hover:bg-accent"
                      onClick={() => navigate(`/projects/${item.projectId}`)}
                    >
                      <span className="truncate text-sm font-medium">
                        {item.projectName}
                      </span>
                      <span className="ml-3 shrink-0 rounded-full bg-[hsl(38_80%_96%)] px-2.5 py-0.5 text-xs text-[hsl(38_85%_38%)]">
                        {item.endDate} 截止
                      </span>
                    </button>
                  ))
                )}
              </CardContent>
            </Card>
          </div>

          {todos?.dailyReportMissing === true && (
            <button
              type="button"
              className="flex w-full items-center gap-3 rounded-lg bg-[hsl(0_60%_96%)] p-4 text-left transition-opacity duration-200 hover:opacity-90"
              onClick={() => navigate('/daily-reports')}
            >
              <AlertTriangle className="h-5 w-5 shrink-0 text-[hsl(0_65%_52%)]" />
              <span className="text-sm font-medium text-[hsl(0_65%_42%)]">
                您今日尚未提交日报，点击前往提交
              </span>
            </button>
          )}
        </>
      )}
    </section>
  );
};

export default TodoReminders;
