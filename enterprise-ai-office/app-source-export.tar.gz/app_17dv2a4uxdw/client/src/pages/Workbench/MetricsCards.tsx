import React from 'react';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Skeleton } from '@client/src/components/ui/skeleton';
import type { DashboardMetrics } from '@shared/api.interface';

interface MetricsCardsProps {
  metrics: DashboardMetrics | null;
  loading?: boolean;
}

interface MetricDef {
  key: keyof DashboardMetrics;
  label: string;
  sub: string;
  format: (value: number) => string;
}

const METRIC_DEFS: MetricDef[] = [
  {
    key: 'conversionRate',
    label: '报价转化率',
    sub: '已确认报价数 / 报价总数',
    format: (value: number) => `${value}%`,
  },
  {
    key: 'followUpRate',
    label: '客户跟进完成率',
    sub: '有跟进记录客户数 / 客户总数',
    format: (value: number) => `${value}%`,
  },
  {
    key: 'onTimeRate',
    label: '项目按期完成率',
    sub: '按期完成项目数 / 已完成项目数',
    format: (value: number) => `${value}%`,
  },
  {
    key: 'avgQuotationAmount',
    label: '平均报价金额',
    sub: '报价总金额 / 报价单数',
    format: (value: number) =>
      `¥${value.toLocaleString('zh-CN', { maximumFractionDigits: 0 })}`,
  },
];

const MetricsCards: React.FC<MetricsCardsProps> = ({ metrics, loading }) => {
  if (loading) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {METRIC_DEFS.map((def: MetricDef) => (
          <Skeleton key={def.key} className="h-[92px] rounded-lg" />
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {METRIC_DEFS.map((def: MetricDef) => (
        <Card key={def.key}>
          <CardContent className="pt-5 pb-4">
            <p className="text-sm text-muted-foreground">{def.label}</p>
            <p
              className="mt-1.5 text-2xl font-bold tracking-tight text-foreground"
              style={{ fontFamily: "'Roboto Mono', 'SF Mono', monospace" }}
            >
              {metrics ? def.format(metrics[def.key]) : '-'}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">{def.sub}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default MetricsCards;
