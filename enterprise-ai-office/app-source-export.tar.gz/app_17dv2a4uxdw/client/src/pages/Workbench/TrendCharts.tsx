import React from 'react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import type {
  CallbackDataParams,
  TopLevelFormatterParams,
} from 'echarts/types/dist/shared';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import type {
  DashboardQuotationTrendPoint,
  DashboardStatPoint,
} from '@shared/api.interface';

interface TrendChartsProps {
  quotationTrend: DashboardQuotationTrendPoint[];
  customerTrend: DashboardStatPoint[];
}

const PRIMARY_BLUE: string = '#3370eb';

function formatDayLabel(value: string): string {
  return value.length > 7 ? value.slice(5) : value;
}

const TrendCharts: React.FC<TrendChartsProps> = ({
  quotationTrend,
  customerTrend,
}) => {
  const quotationOption: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      formatter: (params: TopLevelFormatterParams) => {
        const list: CallbackDataParams[] = Array.isArray(params)
          ? params
          : [params];
        const first: CallbackDataParams | undefined = list[0];
        if (!first) {
          return '';
        }
        const point: DashboardQuotationTrendPoint | undefined =
          quotationTrend[first.dataIndex];
        const amount: number = Number(first.value ?? 0);
        return `${first.name}<br/>报价金额：¥${amount.toLocaleString('zh-CN')}<br/>报价单数：${point?.count ?? 0}`;
      },
    },
    legend: { bottom: 0, show: false },
    grid: { left: '3%', right: '4%', bottom: '20%', containLabel: true },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: quotationTrend.map((point: DashboardQuotationTrendPoint) =>
        formatDayLabel(point.date)),
    },
    yAxis: {
      type: 'value',
      axisLabel: {
        formatter: (value: number) =>
          value >= 10000 ? `${value / 10000}万` : `${value}`,
      },
    },
    series: [
      {
        name: '报价金额',
        type: 'line',
        smooth: true,
        data: quotationTrend.map(
          (point: DashboardQuotationTrendPoint) => point.amount
        ),
        itemStyle: { color: PRIMARY_BLUE },
        areaStyle: { color: '#e4ecfb' },
      },
    ],
  };

  const customerOption: EChartsOption = {
    tooltip: { trigger: 'axis' },
    legend: { bottom: 0, show: false },
    grid: { left: '3%', right: '4%', bottom: '20%', containLabel: true },
    xAxis: {
      type: 'category',
      boundaryGap: true,
      data: customerTrend.map((point: DashboardStatPoint) =>
        formatDayLabel(point.date)),
    },
    yAxis: { type: 'value' },
    series: [
      {
        name: '新增客户',
        type: 'bar',
        data: customerTrend.map((point: DashboardStatPoint) => point.value),
        itemStyle: { color: '#1bcebf', borderRadius: [4, 4, 0, 0] },
        barMaxWidth: 24,
      },
    ],
  };

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold">
            报价金额趋势
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ReactECharts
            option={quotationOption}
            theme="ud"
            className="h-[300px] w-full"
            notMerge
          />
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold">
            客户新增趋势
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ReactECharts
            option={customerOption}
            theme="ud"
            className="h-[300px] w-full"
            notMerge
          />
        </CardContent>
      </Card>
    </div>
  );
};

export default TrendCharts;
