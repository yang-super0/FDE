import React, { useCallback, useEffect, useState } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  BadgeCheck,
  EyeOff,
  ShieldAlert,
} from 'lucide-react';
import { Badge } from '@client/src/components/ui/badge';
import { Button } from '@client/src/components/ui/button';
import { Card } from '@client/src/components/ui/card';
import {
  dismissAlert,
  fetchAlerts,
  markAlertsAllRead,
} from '@client/src/api/alerts';
import type {
  AlertGroup,
  AlertItem,
  AlertListResponse,
  AlertType,
} from '@shared/api.interface';

const ALERT_TYPE_ORDER: AlertType[] = [
  'project_delay',
  'report_missing',
  'customer_no_follow',
  'quotation_anomaly',
];

const ALERT_TYPE_LABEL: Record<AlertType, string> = {
  project_delay: '项目延期',
  report_missing: '日报未提交',
  customer_no_follow: '客户未跟进',
  quotation_anomaly: '报价异常',
};

type AlertFilter = AlertType | 'all';

const getAlertLink = (item: AlertItem): string => {
  switch (item.type) {
    case 'project_delay':
      return `/projects/${item.objectId}`;
    case 'customer_no_follow':
      return `/customers/${item.objectId}`;
    case 'report_missing':
      return '/daily-reports';
    case 'quotation_anomaly':
      return '/quotations';
  }
};

const formatOccurredAt = (value: string): string => {
  return value.slice(0, 10);
};

interface AlertPanelProps {
  isAdmin: boolean;
}

const AlertPanel: React.FC<AlertPanelProps> = ({ isAdmin }) => {
  const [data, setData] = useState<AlertListResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [filter, setFilter] = useState<AlertFilter>('all');
  const [markingRead, setMarkingRead] = useState<boolean>(false);
  const navigate = useNavigate();

  const load = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const result: AlertListResponse = await fetchAlerts();
      setData(result);
    } catch (err) {
      logger.error(`Alerts load failed: ${String(err)}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isAdmin) {
      void load();
    }
  }, [isAdmin, load]);

  const handleDismiss = async (item: AlertItem): Promise<void> => {
    try {
      await dismissAlert(item.type, item.targetId);
      setData((prev: AlertListResponse | null) => {
        if (prev === null) return prev;
        const groups: AlertGroup[] = prev.groups.map(
          (group: AlertGroup): AlertGroup =>
            group.type === item.type
              ? {
                  ...group,
                  items: group.items.filter(
                    (alert: AlertItem) => alert.targetId !== item.targetId,
                  ),
                  count: group.count - 1,
                }
              : group,
        );
        return { groups, total: Math.max(prev.total - 1, 0) };
      });
    } catch (err) {
      logger.error(`Dismiss alert failed: ${String(err)}`);
      toast.error('忽略预警失败，请重试');
    }
  };

  const handleMarkAllRead = async (): Promise<void> => {
    setMarkingRead(true);
    try {
      await markAlertsAllRead();
      setData({ groups: data?.groups.map((g: AlertGroup) => ({ ...g, items: [], count: 0 })) ?? [], total: 0 });
      toast.success('已全部标记为已读');
    } catch (err) {
      logger.error(`Mark all read failed: ${String(err)}`);
      toast.error('操作失败，请重试');
    } finally {
      setMarkingRead(false);
    }
  };

  if (!isAdmin) {
    return null;
  }

  const visibleGroups: AlertGroup[] = (data?.groups ?? []).filter(
    (group: AlertGroup) => filter === 'all' || group.type === filter,
  );
  const total: number = data?.total ?? 0;

  return (
    <Card className="p-5" data-ai-section-type="card-list">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <ShieldAlert className="h-5 w-5 text-[hsl(0_65%_52%)]" />
          <h2 className="text-base font-semibold">异常预警</h2>
          {total > 0 ? (
            <Badge className="bg-[hsl(0_60%_96%)] text-[hsl(0_65%_52%)]">
              {total} 项
            </Badge>
          ) : null}
        </div>
        <Button
          variant="outline"
          size="sm"
          disabled={total === 0 || markingRead}
          onClick={() => void handleMarkAllRead()}
          data-ai-section-type="button"
        >
          <BadgeCheck className="mr-1 h-4 w-4" />
          全部已读
        </Button>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        <button
          type="button"
          className={`rounded-full px-3 py-1 text-sm transition-colors ${
            filter === 'all'
              ? 'bg-[hsl(217_70%_52%)] text-white'
              : 'bg-[hsl(217_40%_95%)] text-[hsl(217_70%_40%)] hover:opacity-80'
          }`}
          onClick={() => setFilter('all')}
        >
          全部
        </button>
        {ALERT_TYPE_ORDER.map((type: AlertType) => {
          const count: number =
            data?.groups.find((g: AlertGroup) => g.type === type)?.count ?? 0;
          return (
            <button
              key={type}
              type="button"
              className={`rounded-full px-3 py-1 text-sm transition-colors ${
                filter === type
                  ? 'bg-[hsl(217_70%_52%)] text-white'
                  : 'bg-[hsl(217_40%_95%)] text-[hsl(217_70%_40%)] hover:opacity-80'
              }`}
              onClick={() => setFilter(type)}
            >
              {ALERT_TYPE_LABEL[type]}（{count}）
            </button>
          );
        })}
      </div>

      <div className="mt-4 space-y-2">
        {loading ? (
          <p className="py-8 text-center text-sm text-[hsl(216_15%_50%)]">
            加载中...
          </p>
        ) : total === 0 ? (
          <div className="flex flex-col items-center gap-2 py-8 text-center">
            <BadgeCheck className="h-8 w-8 text-[hsl(152_60%_42%)]" />
            <p className="text-sm text-[hsl(216_15%_50%)]">
              当前没有待处理的异常预警
            </p>
          </div>
        ) : (
          visibleGroups
            .filter((group: AlertGroup) => group.items.length > 0)
            .map((group: AlertGroup) => (
              <div key={group.type}>
                <p className="mb-2 text-sm font-medium text-[hsl(216_15%_50%)]">
                  {ALERT_TYPE_LABEL[group.type]}（{group.count} 个）
                </p>
                <div className="space-y-2">
                  {group.items.map((item: AlertItem) => {
                    const danger: boolean = item.level === 'danger';
                    return (
                      <div
                        key={`${item.type}_${item.targetId}`}
                        className={`flex flex-wrap items-center gap-3 rounded-lg border px-3 py-2.5 ${
                          danger
                            ? 'border-[hsl(0_65%_52%_/_30%)] bg-[hsl(0_60%_96%)]'
                            : 'border-[hsl(38_85%_48%_/_30%)] bg-[hsl(38_80%_96%)]'
                        }`}
                      >
                        <AlertTriangle
                          className={`h-4 w-4 shrink-0 ${
                            danger
                              ? 'text-[hsl(0_65%_52%)]'
                              : 'text-[hsl(38_85%_48%)]'
                          }`}
                        />
                        <button
                          type="button"
                          className="text-sm font-medium text-foreground hover:text-[hsl(217_70%_52%)] hover:underline"
                          onClick={() => navigate(getAlertLink(item))}
                        >
                          {item.title}
                        </button>
                        <span className="flex-1 text-sm text-[hsl(216_15%_50%)]">
                          {item.detail}
                        </span>
                        <span className="font-mono text-xs text-[hsl(216_15%_50%)]">
                          {formatOccurredAt(item.occurredAt)}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 px-2 text-xs"
                          onClick={() => void handleDismiss(item)}
                          data-ai-section-type="button"
                        >
                          <EyeOff className="mr-1 h-3.5 w-3.5" />
                          忽略
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
        )}
      </div>
    </Card>
  );
};

export default AlertPanel;
