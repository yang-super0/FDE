import React from 'react';
import ReactECharts from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import { Card, CardContent, CardHeader, CardTitle } from '@client/src/components/ui/card';
import type {
  DashboardReportRatePoint,
  DashboardStats,
} from '@shared/api.interface';

type ProjectStatusSlice =
  DashboardStats['projectStatusDist'][number];

interface DistributionChartsProps {
  projectStatusDist: ProjectStatusSlice[];
  reportRateTrend: DashboardReportRatePoint[];
}

const STATUS_META: Record<string, { label: string; color: string }> = {
  not_started: { label: '未开始', color: '#8a94a6' },
  in_progress: { label: '进行中', color: '#3370eb' },
  completed: { label: '已完成', color: '#2ba471' },
  delayed: { label: '已延期', color: '#f0a514' },
};

const DistributionCharts: React.FC<DistributionChartsProps> = ({
  projectStatusDist,
  reportRateTrend,
}) => {
  const pieOption: EChartsOption = {
    tooltip: { trigger: 'item' },
    legend: { type: 'scroll', bottom: 0 },
    series: [
      {
        name: '项目进度分布',
        type: 'pie',
        radius: ['42%', '68%'],
        center: ['50%', '45%'],
        label: { show: false },
        emphasis: { label: { show: false } },
        data: projectStatusDist.map((slice: ProjectStatusSlice) => ({
          name: STATUS_META[slice.status]?.label ?? slice.status,
          value: slice.count,
          itemStyle: {
            color: STATUS_META[slice.status]?.color ?? '#8a94a6',
          },
        })),
      },
    ],
  };

  const rateOption: EChartsOption = {
    tooltip: { trigger: 'axis' },
    legend: { bottom: 0, show: false },
    grid: { left: '3%', right: '4%', bottom: '20%', containLabel: true },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: reportRateTrend.map((point: DashboardReportRatePoint) =>
        point.date.slice(5)),
    },
    yAxis: {
      type: 'value',
      max: 100,
      axisLabel: {
        formatter: (value: number) => `${value}%`,
      },
    },
    series: [
      {
        name: '提交率',
        type: 'line',
        smooth: true,
        data: reportRateTrend.map(
          (point: DashboardReportRatePoint) => point.rate
        ),
        itemStyle: { color: '#7a5af8' },
      },
    ],
  };

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold">
            项目进度分布
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ReactECharts
            option={pieOption}
            theme="ud"
            className="h-[300px] w-full"
            notMerge
          />
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold">
            日报提交率趋势（近30天）
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ReactECharts
            option={rateOption}
            theme="ud"
            className="h-[300px] w-full"
            notMerge
          />
        </CardContent>
      </Card>
    </div>
  );
};

export default DistributionCharts;
