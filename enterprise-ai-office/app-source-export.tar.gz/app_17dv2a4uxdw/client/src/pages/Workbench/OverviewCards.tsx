import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FileText,
  TrendingDown,
  TrendingUp,
  Users,
  Briefcase,
  ClipboardCheck,
} from 'lucide-react';
import { Card, CardContent } from '@client/src/components/ui/card';
import { Skeleton } from '@client/src/components/ui/skeleton';
import type { DashboardDeltaStat } from '@shared/api.interface';
import { cn } from '@client/src/lib/utils';

interface OverviewCardDef {
  key: 'quotationAmount' | 'quotationCount' | 'customerCount' |
    'activeProjectCount' | 'todayReportCount';
  label: string;
  sub: string;
  icon: React.ReactNode;
  link: string;
  format: (value: number) => string;
}

const CARD_DEFS: OverviewCardDef[] = [
  {
    key: 'quotationAmount',
    label: '本月报价金额',
    sub: '所选时间范围内报价总金额',
    icon: <FileText className="h-4 w-4 text-primary" />,
    link: '/quotations',
    format: (value: number) =>
      `¥${value.toLocaleString('zh-CN', { maximumFractionDigits: 0 })}`,
  },
  {
    key: 'quotationCount',
    label: '本月报价单数',
    sub: '所选时间范围内创建的报价单数',
    icon: <ClipboardCheck className="h-4 w-4 text-primary" />,
    link: '/quotations',
    format: (value: number) => `${value}`,
  },
  {
    key: 'customerCount',
    label: '客户总数',
    sub: '新增客户环比对比',
    icon: <Users className="h-4 w-4 text-primary" />,
    link: '/customers',
    format: (value: number) => `${value}`,
  },
  {
    key: 'activeProjectCount',
    label: '进行中项目',
    sub: '当前处于进行中阶段的项目数量',
    icon: <Briefcase className="h-4 w-4 text-primary" />,
    link: '/projects',
    format: (value: number) => `${value}`,
  },
  {
    key: 'todayReportCount',
    label: '今日日报提交',
    sub: '较昨日',
    icon: <ClipboardCheck className="h-4 w-4 text-primary" />,
    link: '/daily-reports',
    format: (value: number) => `${value}`,
  },
];

interface OverviewCardsProps {
  data: {
    quotationAmount: DashboardDeltaStat;
    quotationCount: DashboardDeltaStat;
    customerCount: DashboardDeltaStat;
    activeProjectCount: number;
    todayReportCount: DashboardDeltaStat;
  } | null;
  loading?: boolean;
}

function DeltaBadge({ delta }: { delta: number | null }) {
  if (delta === null) {
    return (
      <span className="text-xs text-muted-foreground">上期无对比数据</span>
    );
  }
  const rising: boolean = delta >= 0;
  return (
    <span
      className={cn(
        'inline-flex items-center gap-0.5 text-xs font-medium',
        rising ? 'text-[#2ba471]' : 'text-[#d5494f]'
      )}
    >
      {rising
        ? <TrendingUp className="h-3 w-3" />
        : <TrendingDown className="h-3 w-3" />}
      环比 {rising ? '+' : ''}{delta}%
    </span>
  );
}

const OverviewCards: React.FC<OverviewCardsProps> = ({ data, loading }) => {
  const navigate = useNavigate();

  if (loading) {
    return (
      <div
        data-ai-section-type="card-stat"
        className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5"
      >
        {CARD_DEFS.map(
          (def: OverviewCardDef) => (
            <Skeleton key={def.key} className="h-[104px] rounded-lg" />
          )
        )}
      </div>
    );
  }

  const getValue = (key: OverviewCardDef['key']): number => {
    if (!data) {
      return 0;
    }
    if (key === 'activeProjectCount') {
      return data.activeProjectCount;
    }
    return data[key].value;
  };

  return (
    <div
      data-ai-section-type="card-stat"
      className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5"
    >
      {CARD_DEFS.map((def: OverviewCardDef) => (
        <Card
          key={def.key}
          className="cursor-pointer transition-colors hover:bg-accent/40"
          onClick={() => navigate(def.link)}
        >
          <CardContent className="pt-5 pb-4">
            <div className="flex items-center justify-between gap-2">
              <span className="inline-flex items-center gap-1.5 text-sm text-muted-foreground">
                {def.icon}
                {def.label}
              </span>
            </div>
            <p
              className="mt-2 text-3xl font-bold tracking-tight text-foreground"
              style={{ fontFamily: "'Roboto Mono', 'SF Mono', monospace" }}
            >
              {data ? def.format(getValue(def.key)) : '-'}
            </p>
            <div className="mt-2 flex items-center justify-between gap-2">
              {def.key === 'activeProjectCount'
                ? <span className="text-xs text-muted-foreground">无环比数据</span>
                : data
                  ? <DeltaBadge delta={data[def.key].delta} />
                  : <span className="text-xs text-muted-foreground">-</span>}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">{def.sub}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default OverviewCards;
