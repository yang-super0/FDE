// ---- plugin:quotation_ai_generate_1 ----
// ============================================================
// 插件 quotation_ai_generate_1 (quotation-ai-generate) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface QuotationAiGenerateOneInput {
  /** 客户需求描述文本 */
  requirementDesc: string;
}

/**
 * capabilityClient.load('quotation_ai_generate_1').call<QuotationAiGenerateOneOutput>('textToJson', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { suggestion, itemsJson } = result;
 * 返回值形如：
 *   {"suggestion":"示例文本","itemsJson":"示例文本"}
 */
export interface QuotationAiGenerateOneOutput {
  /** AI给出的报价建议文本 */
  suggestion: string;
  /** 报价明细的JSON数组字符串，数组每项为对象，包含itemName（明细名称，字符串）、quantity（数量，数值）、unitPrice（单价，数值）三个键 */
  itemsJson: string;
}
// ---- end:quotation_ai_generate_1 ----

// ---- plugin:meeting_minutes_ai_extract_1 ----
// ============================================================
// 插件 meeting_minutes_ai_extract_1 (meeting-minutes-ai-extract) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface MeetingMinutesAiExtractOneInput {
  /** 会议沟通要点原文 */
  meeting_text: string;
}

/**
 * capabilityClient.load('meeting_minutes_ai_extract_1').call<MeetingMinutesAiExtractOneOutput>('textToJson', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { attendees, key_topics, action_items, ... } = result;
 * 返回值形如：
 *   {"attendees":"示例文本","key_topics":"示例文本","action_items":"示例文本","decisions":"示例文本","title":"示例文本","meeting_type":"示例文本","customer_name":"示例文本"}
 */
export interface MeetingMinutesAiExtractOneOutput {
  /** 参会人列表JSON数组字符串，每个元素包含name（姓名）和role（角色/职位）字段，例如"[{\"name\":\"张三\",\"role\":\"产品经理\"}]" */
  attendees: string;
  /** 核心议题JSON数组字符串，每个元素为议题描述文本，例如"[\"Q3产品迭代规划\",\"用户反馈问题处理\"]" */
  key_topics: string;
  /** 待办事项JSON数组字符串，每个元素包含content（事项内容）、assignee（负责人）、due_date（截止时间，YYYY-MM-DD格式，相对时间必须按调用方在文本开头标注的今天日期推算，年份必须与今天年份一致，禁止使用过去年份或示例中的年份，未提及则留空字符串）、status（状态，固定为"未开始"）字段，例如"[{\"content\":\"完成需求文档\",\"assignee\":\"李四\",\"due_date\":\"2024-07-30\",\"status\":\"未开始\"}]" */
  action_items: string;
  /** 关键决策纯文本摘要 */
  decisions: string;
  /** 会议标题：基于会议核心议题和参会人生成的简洁标题，不超过30字，只输出标题文本 */
  title: string;
  /** 会议类型：根据内容判断，只能输出以下四个值之一：客户拜访（有外部客户参与，如拜访客户、与客户洽谈）、内部会议（仅公司内部人员）、项目评审（方案或项目评审讨论）、其他 */
  meeting_type: string;
  /** 客户名称：文本中提到的客户公司或组织名称（如中原桥梁、杭州云启科技有限公司），未提到具体客户公司则留空字符串 */
  customer_name: string;
}
// ---- end:meeting_minutes_ai_extract_1 ----

// ---- plugin:abnormal_alert_daily_summary_push_1 ----
// ============================================================
// 插件 abnormal_alert_daily_summary_push_1 (异常预警每日摘要推送) 的类型定义
// 由 get_plugin_ai_json 自动生成
// ============================================================

export interface AbnormalAlertDailySummaryPushOneInput {
  /** 接收人妙搭用户ID列表 */
  receiverUserList: string[];
  /** 预警摘要正文（markdown） */
  content: string;
}

/**
 * capabilityClient.load('abnormal_alert_daily_summary_push_1').call<AbnormalAlertDailySummaryPushOneOutput>('send_feishu_message', input)
 * 直接返回此类型，无 .data 包装，直接解构使用：
 * const { success } = result;
 * 返回值形如：
 *   {"success":false}
 */
export interface AbnormalAlertDailySummaryPushOneOutput {
  /** [object Object] */
  success: boolean;
}
// ---- end:abnormal_alert_daily_summary_push_1 ----