/* 前后端共享的类型写在这里 */

export interface PageParams {
  page: number;
  pageSize: number;
}

/* ===== 工作台 ===== */

export interface DashboardOverview {
  monthlyQuotationCount: number;
  monthlyQuotationAmount: number;
  customerCount: number;
  activeProjectCount: number;
  todayReportCount: number;
}

export interface FollowUpTodo {
  customerId: string;
  customerName: string;
  nextFollowAt: string;
}

export interface NearingProjectTodo {
  projectId: string;
  projectName: string;
  endDate: string;
}

export interface DashboardTodos {
  followUps: FollowUpTodo[];
  nearingProjects: NearingProjectTodo[];
  dailyReportMissing: boolean;
}

export type DashboardRange = '7d' | '30d' | '90d' | 'year' | 'custom';

export interface DashboardStatsParams {
  range: DashboardRange;
  startDate?: string;
  endDate?: string;
  ownerId?: string;
}

export interface DashboardDeltaStat {
  value: number;
  delta: number | null;
}

export interface DashboardCards {
  quotationAmount: DashboardDeltaStat;
  quotationCount: DashboardDeltaStat;
  customerCount: DashboardDeltaStat;
  activeProjectCount: number;
  todayReportCount: DashboardDeltaStat;
}

export interface DashboardQuotationTrendPoint {
  date: string;
  amount: number;
  count: number;
}

export interface DashboardStatPoint {
  date: string;
  value: number;
}

export interface DashboardReportRatePoint {
  date: string;
  submitted: number;
  total: number;
  rate: number;
}

export interface DashboardMetrics {
  conversionRate: number;
  followUpRate: number;
  onTimeRate: number;
  avgQuotationAmount: number;
}

export interface DashboardStats {
  cards: DashboardCards;
  quotationTrend: DashboardQuotationTrendPoint[];
  customerTrend: DashboardStatPoint[];
  projectStatusDist: { status: ProjectStatus; count: number }[];
  reportRateTrend: DashboardReportRatePoint[];
  metrics: DashboardMetrics;
}

export interface DashboardOwnerOption {
  userId: string;
  name: string;
}

/* ===== 智能报价 ===== */

export type QuotationStatus = 'draft' | 'sent' | 'confirmed' | 'closed';

export type ProjectScene =
  | '普通项目'
  | '沿海项目'
  | '高速项目'
  | '山地项目';

export interface QuotationUnitSummary {
  productId: string;
  productName: string;
  count: number;
}

export interface QuotationListItem {
  id: string;
  quotationNo: string;
  customerName: string;
  productName: string;
  totalUnits: number;
  unitSummary: QuotationUnitSummary[];
  totalAmount: number;
  status: QuotationStatus;
  updatedAt: string;
}

export interface QuotationListResponse {
  items: QuotationListItem[];
  total: number;
}

export interface QuotationListParams extends PageParams {
  status?: QuotationStatus;
}

export interface QuotationItemDetail {
  id: string;
  itemName: string;
  quantity: number;
  unitPrice: number;
  amount: number;
  customItemId: string | null;
  priceAdjustment: number | null;
  requiredByScene: boolean;
}

export interface QuotationUnitDetail {
  id: string;
  unitNo: number;
  productId: string;
  productName: string;
  basePrice: number;
  projectScene: ProjectScene;
  unitSubtotal: number;
  remark: string | null;
  items: QuotationItemDetail[];
}

export interface QuotationDetail {
  id: string;
  quotationNo: string;
  customerId: string;
  customerName: string;
  productId: string | null;
  productName: string;
  basePrice: number | null;
  projectScene: ProjectScene;
  totalAmount: number;
  totalUnits: number;
  status: QuotationStatus;
  remark: string | null;
  aiSuggestion: string | null;
  units: QuotationUnitDetail[];
  items: QuotationItemDetail[];
  updatedAt: string;
}

export interface CreateQuotationUnitRequest {
  productId: string;
  projectScene: ProjectScene;
  customItemIds: string[];
}

export interface CreateQuotationRequest {
  customerId: string;
  units: CreateQuotationUnitRequest[];
  remark?: string;
}

export interface UpdateQuotationRequest {
  customerId: string;
  units: CreateQuotationUnitRequest[];
  remark?: string;
}

export interface CustomerProjectListResponse {
  items: ProjectListItem[];
}

/* ===== 产品与定制选项 ===== */

export interface ProductOption {
  id: string;
  productCode: string;
  name: string;
  category: string;
  basePrice: number;
}

export interface ProductListResponse {
  items: ProductOption[];
}

export interface SceneConditionalPrice {
  scene: ProjectScene;
  priceAdjustment: number;
}

export interface ProductCustomOption {
  customItemId: string;
  itemName: string;
  priceAdjustment: number;
  ruleType: string;
  description: string;
  unit: string | null;
  conditionalScenes: SceneConditionalPrice[];
}

export interface ProductCustomOptionsResponse {
  productId: string;
  productName: string;
  basePrice: number;
  items: ProductCustomOption[];
}

export interface CreateQuotationResponse {
  id: string;
}

export interface UpdateQuotationStatusRequest {
  status: Exclude<QuotationStatus, 'draft'>;
}

export interface SuccessResponse {
  success: boolean;
}

/* ===== 基础数据管理 ===== */

export type BaseDataStatus = 'active' | 'disabled';

export type PricingRuleType =
  | 'base_price'
  | 'standard'
  | 'conditional'
  | 'package';

export interface UpdateBaseDataStatusRequest {
  status: BaseDataStatus;
}

export interface ProductAdminItem {
  id: string;
  productCode: string;
  name: string;
  category: string | null;
  basePrice: number;
  description: string | null;
  spec: Record<string, string> | null;
  status: BaseDataStatus;
  updatedAt: string;
}

export interface ProductAdminListParams extends PageParams {
  keyword?: string;
  status?: BaseDataStatus;
}

export interface ProductAdminListResponse {
  items: ProductAdminItem[];
  total: number;
}

export interface CreateProductRequest {
  productCode: string;
  name: string;
  category?: string;
  basePrice: number;
  spec?: Record<string, string>;
  description?: string;
}

export interface UpdateProductRequest {
  productCode?: string;
  name?: string;
  category?: string;
  basePrice?: number;
  spec?: Record<string, string>;
  description?: string;
}

export interface CustomCategoryNode {
  id: string;
  name: string;
  parentId: string | null;
  sortOrder: number;
  status: BaseDataStatus;
  children: CustomCategoryNode[];
}

export interface CustomCategoryTreeResponse {
  items: CustomCategoryNode[];
}

export interface CustomCategoryOption {
  id: string;
  name: string;
  fullName: string;
}

export interface CustomCategoryOptionsResponse {
  items: CustomCategoryOption[];
}

export interface CreateCustomCategoryRequest {
  name: string;
  parentId?: string;
  sortOrder?: number;
}

export interface UpdateCustomCategoryRequest {
  name?: string;
  parentId?: string | null;
  sortOrder?: number;
}

export interface CustomItemAdminItem {
  id: string;
  name: string;
  categoryId: string;
  categoryName: string;
  description: string | null;
  defaultPrice: number;
  priceType: string;
  unit: string | null;
  status: BaseDataStatus;
  updatedAt: string;
}

export interface CustomItemAdminListParams extends PageParams {
  keyword?: string;
  status?: BaseDataStatus;
  categoryId?: string;
}

export interface CustomItemAdminListResponse {
  items: CustomItemAdminItem[];
  total: number;
}

export interface CustomItemOption {
  id: string;
  name: string;
}

export interface CustomItemOptionsResponse {
  items: CustomItemOption[];
}

export interface CreateCustomItemRequest {
  name: string;
  categoryId: string;
  description?: string;
  defaultPrice: number;
  priceType: string;
  unit?: string;
}

export interface UpdateCustomItemRequest {
  name?: string;
  categoryId?: string;
  description?: string;
  defaultPrice?: number;
  priceType?: string;
  unit?: string;
}

export interface PricingRuleAdminItem {
  id: string;
  name: string;
  productId: string;
  productName: string;
  customItemId: string | null;
  customItemName: string | null;
  ruleType: PricingRuleType;
  priceAdjustment: number;
  conditions: Record<string, string | number | boolean> | null;
  priority: number;
  description: string | null;
  status: BaseDataStatus;
  updatedAt: string;
}

export interface PricingRuleAdminListParams extends PageParams {
  keyword?: string;
  status?: BaseDataStatus;
  ruleType?: PricingRuleType;
}

export interface PricingRuleAdminListResponse {
  items: PricingRuleAdminItem[];
  total: number;
}

export interface CreatePricingRuleRequest {
  name: string;
  productId: string;
  customItemId?: string;
  ruleType: PricingRuleType;
  priceAdjustment: number;
  conditions?: Record<string, string | number | boolean>;
  priority: number;
  description?: string;
}

export interface UpdatePricingRuleRequest {
  name?: string;
  productId?: string;
  customItemId?: string | null;
  ruleType?: PricingRuleType;
  priceAdjustment?: number;
  conditions?: Record<string, string | number | boolean> | null;
  priority?: number;
  description?: string;
}

/* ===== 客户管理 ===== */

export interface CustomerListItem {
  id: string;
  name: string;
  industry: string;
  contactName: string;
  contactPhone: string;
  lastFollowedAt: string | null;
  ownerId: string | null;
  ownerName: string;
}

export interface CustomerListResponse {
  items: CustomerListItem[];
  total: number;
}

export interface CustomerListParams extends PageParams {
  keyword?: string;
  industry?: string;
  ownerId?: string;
}

export interface CreateCustomerRequest {
  name: string;
  industry?: string;
  contactName?: string;
  contactPhone?: string;
  address?: string;
  ownerId?: string;
}

export interface CreateCustomerResponse {
  id: string;
}

export interface UpdateCustomerRequest {
  name?: string;
  industry?: string;
  contactName?: string;
  contactPhone?: string;
  address?: string;
  ownerId?: string | null;
}

export interface CustomerDetail {
  id: string;
  name: string;
  industry: string;
  contactName: string;
  contactPhone: string;
  address: string;
  ownerId: string | null;
  ownerName: string;
}

export interface CustomerOwnerOption {
  userId: string;
  name: string;
}

export interface CustomerOwnerListResponse {
  items: CustomerOwnerOption[];
}

export interface BatchAssignCustomerRequest {
  customerIds: string[];
  ownerId: string;
}

export interface TransferCustomerRequest {
  ownerId: string;
  reason?: string;
}

export interface CustomerUnassignedCountResponse {
  count: number;
}

export interface CurrentUserRoleResponse {
  isAdmin: boolean;
}

export interface FollowUpItem {
  id: string;
  method: string;
  content: string;
  operatorName: string;
  nextFollowAt: string | null;
  createdAt: string;
}

export interface FollowUpListResponse {
  items: FollowUpItem[];
}

export interface CreateFollowUpRequest {
  method: string;
  content: string;
  nextFollowAt?: string;
}

export interface CreateFollowUpResponse {
  id: string;
}

export interface CustomerQuotationItem {
  id: string;
  quotationNo: string;
  totalAmount: number;
  status: QuotationStatus;
}

export interface CustomerQuotationListResponse {
  items: CustomerQuotationItem[];
}

/* ===== 项目管理 ===== */

export type ProjectStatus =
  | 'not_started'
  | 'in_progress'
  | 'completed'
  | 'delayed';

export interface ProjectListItem {
  id: string;
  name: string;
  ownerName: string;
  startDate: string;
  endDate: string;
  status: ProjectStatus;
  progress: number;
  customerId: string | null;
  customerName: string | null;
}

export interface ProjectListResponse {
  items: ProjectListItem[];
  total: number;
}

export interface ProjectListParams {
  status?: ProjectStatus;
}

export interface CreateProjectRequest {
  name: string;
  startDate: string;
  endDate: string;
  description?: string;
  ownerId: string;
  memberIds: string[];
  customerId?: string | null;
}

export interface CreateProjectResponse {
  id: string;
}

export interface ProjectMemberInfo {
  userId: string;
  name: string;
  avatar: string;
}

export interface ProjectDetail {
  id: string;
  name: string;
  ownerId: string;
  ownerName: string;
  startDate: string;
  endDate: string;
  description: string;
  status: ProjectStatus;
  progress: number;
  members: ProjectMemberInfo[];
  customerId: string | null;
  customerName: string | null;
}

export interface UpdateProjectRequest {
  customerId?: string | null;
  progress?: number;
}

export interface UpdateProjectStatusRequest {
  status: ProjectStatus;
}

export interface AddProjectMembersRequest {
  memberIds: string[];
}

export type ProjectTaskStatus = 'pending' | 'completed';

export interface ProjectTaskItem {
  id: string;
  taskName: string;
  assigneeId: string;
  assigneeName: string;
  status: ProjectTaskStatus;
  dueDate: string;
}

export interface ProjectTaskListResponse {
  items: ProjectTaskItem[];
}

export interface CreateProjectTaskRequest {
  taskName: string;
  assigneeId: string;
  dueDate: string;
}

export interface CreateProjectTaskResponse {
  id: string;
}

export interface UpdateProjectTaskRequest {
  status: ProjectTaskStatus;
}

/* ===== 员工日报 ===== */

export type DailyReportStatus = 'draft' | 'submitted';

export interface WorkDraftItem {
  time: string;
  relatedObject: string;
  summary: string;
}

export interface WorkDraftCategory {
  type: string;
  items: WorkDraftItem[];
}

export interface DailyReportContentStructure {
  categories: WorkDraftCategory[];
}

export interface AutoDraftRequest {
  reportDate: string;
}

export interface AutoDraftResponse {
  reportDate: string;
  categories: WorkDraftCategory[];
}

export interface SubmitDailyReportRequest {
  reportDate: string;
  todayContent: string;
  tomorrowPlan?: string;
  risk?: string;
  contentStructure?: DailyReportContentStructure | null;
}

export interface SubmitDailyReportResponse {
  id: string;
  status: DailyReportStatus;
}

export interface SaveDailyReportDraftRequest {
  reportDate: string;
  todayContent: string;
  tomorrowPlan?: string;
  risk?: string;
  contentStructure?: DailyReportContentStructure | null;
}

export interface SaveDailyReportDraftResponse {
  id: string;
  status: DailyReportStatus;
}

export interface MyDailyReportItem {
  id: string;
  reportDate: string;
  todayContent: string;
  tomorrowPlan: string;
  risk: string;
  status: DailyReportStatus;
  contentStructure: DailyReportContentStructure | null;
  createdAt: string;
}

export interface MyDailyReportListResponse {
  items: MyDailyReportItem[];
}

export interface TeamDailyReportItem {
  userId: string;
  userName: string;
  submitted: boolean;
  reportId: string | null;
  todayContent: string | null;
  tomorrowPlan: string | null;
  risk: string | null;
  submittedAt: string | null;
}

export interface TeamDailyReportResponse {
  items: TeamDailyReportItem[];
}

export interface TeamDailyReportParams {
  date: string;
  memberId?: string;
}

/* ===== 权限管理 ===== */

export interface RoleInfo {
  id: string;
  name: string;
  bizId: string;
  isBuiltin: boolean;
  permissions: string[];
  memberCount: number;
}

export interface RoleListResponse {
  items: RoleInfo[];
}

export interface CreateRoleRequest {
  name: string;
  permissionKeys: string[];
}

export interface CreateRoleResponse {
  id: string;
}

export interface UpdateRoleRequest {
  name?: string;
  permissionKeys?: string[];
}

export interface MemberRoleInfo {
  userId: string;
  name: string;
  avatar: string;
  departmentName: string | null;
  roleIds: string[];
  roleNames: string[];
}

export interface MemberListResponse {
  items: MemberRoleInfo[];
}

export interface AssignMemberRolesRequest {
  roleIds: string[];
}

export interface PermissionPointInfo {
  id: string;
  action: string;
  subject: string;
  description: string;
}

/* ===== 会议纪要 ===== */

export type MeetingType =
  | '客户拜访'
  | '内部会议'
  | '项目评审'
  | '其他';

export type MeetingSource = '手动录入' | 'AI生成' | '飞书妙记导入';

export type MeetingActionStatus = '未开始' | '进行中' | '已完成';

export interface MeetingAttendee {
  name: string;
  role: string;
}

export interface MeetingActionItem {
  content: string;
  assignee: string;
  dueDate: string;
  status: MeetingActionStatus;
}

export interface MeetingMinuteListItem {
  id: string;
  title: string;
  meetingDate: string;
  meetingType: MeetingType;
  customerId: string | null;
  customerName: string | null;
  source: MeetingSource;
  createdBy: string;
}

export interface MeetingMinuteListParams extends PageParams {
  startDate?: string;
  endDate?: string;
  meetingType?: MeetingType;
  customerId?: string;
}

export interface MeetingMinuteListResponse {
  items: MeetingMinuteListItem[];
  total: number;
}

export interface MeetingMinuteDetail {
  id: string;
  title: string;
  meetingDate: string;
  meetingType: MeetingType;
  customerId: string | null;
  customerName: string | null;
  attendees: MeetingAttendee[];
  keyTopics: string[];
  actionItems: MeetingActionItem[];
  decisions: string;
  source: MeetingSource;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface SaveMeetingMinuteRequest {
  title: string;
  meetingDate: string;
  meetingType: MeetingType;
  customerId: string | null;
  attendees: MeetingAttendee[];
  keyTopics: string[];
  actionItems: MeetingActionItem[];
  decisions: string;
  source: MeetingSource;
}

export interface SaveMeetingMinuteResponse {
  id: string;
}

export interface CustomerTimelineMinuteItem {
  id: string;
  title: string;
  meetingDate: string;
  meetingType: MeetingType;
  decisions: string;
}

export interface CustomerTimelineMinutesResponse {
  items: CustomerTimelineMinuteItem[];
}

/* ===== 异常预警 ===== */

export type AlertType =
  | 'project_delay'
  | 'report_missing'
  | 'customer_no_follow'
  | 'quotation_anomaly';

export interface AlertItem {
  type: AlertType;
  level: 'warning' | 'danger';
  targetId: string;
  objectId: string;
  title: string;
  detail: string;
  occurredAt: string;
}

export interface AlertGroup {
  type: AlertType;
  count: number;
  items: AlertItem[];
}

export interface AlertListResponse {
  groups: AlertGroup[];
  total: number;
}

export interface AlertDismissRequest {
  type: AlertType;
  targetId: string;
}

export interface AlertSuccessResponse {
  success: boolean;
}

export interface AlertMarkAllReadResponse {
  dismissed: number;
}

export interface AlertPushNowResponse {
  success: boolean;
  message: string;
}
