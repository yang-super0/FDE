export type PermissionAction = 'read' | 'operate' | 'manage';

export type PermissionSubject =
  | 'Quotation'
  | 'Customer'
  | 'Project'
  | 'DailyReport'
  | 'MeetingMinutes'
  | 'Permission';

export interface PermissionPointDef {
  action: PermissionAction;
  subject: PermissionSubject;
  description: string;
}

export const PERMISSION_POINTS: PermissionPointDef[] = [
  { action: 'manage', subject: 'Permission', description: '管理权限配置' },
  { action: 'read', subject: 'Quotation', description: '查看报价列表与详情' },
  { action: 'operate', subject: 'Quotation', description: '新建报价与状态流转' },
  { action: 'read', subject: 'Customer', description: '查看客户列表与详情' },
  { action: 'operate', subject: 'Customer', description: '新建编辑客户与跟进' },
  { action: 'read', subject: 'Project', description: '查看项目列表与详情' },
  {
    action: 'operate',
    subject: 'Project',
    description: '立项、阶段变更、任务与成员管理',
  },
  { action: 'read', subject: 'DailyReport', description: '查看团队日报' },
  { action: 'operate', subject: 'DailyReport', description: '提交日报' },
  { action: 'read', subject: 'MeetingMinutes', description: '查看会议纪要列表与详情' },
  { action: 'operate', subject: 'MeetingMinutes', description: '新建、编辑与删除会议纪要' },
  { action: 'read', subject: 'Permission', description: '查看权限管理页' },
  { action: 'operate', subject: 'Permission', description: '管理角色与成员授权' },
];

export const ROLE_KEYS = {
  admin: 'admin',
  sales: 'sales',
  projectManager: 'project_manager',
  staff: 'staff',
} as const;

export interface PermissionSubjectMeta {
  subject: PermissionSubject;
  label: string;
}

export const PERMISSION_SUBJECT_META: PermissionSubjectMeta[] = [
  { subject: 'Quotation', label: '智能报价' },
  { subject: 'Customer', label: '客户管理' },
  { subject: 'Project', label: '项目管理' },
  { subject: 'DailyReport', label: '员工日报' },
  { subject: 'MeetingMinutes', label: '会议纪要' },
  { subject: 'Permission', label: '权限管理' },
];
