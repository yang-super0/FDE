# 技术方案

## 开发元信息
- 开发模式: 全栈应用
- 涉及层级: [数据库, 插件, 服务端, 前端]
- 权限方案: 使用平台内置动态权限点位能力（`@Can`/`<Can>` + AuthorizationSDK + 平台角色权限表），**禁止自建角色表/权限表**；实施前须先完成权限体系 DESIGN 确认
- 用户能力: 复用平台内置用户系统（当前用户 `useCurrentUserProfile`、人员选择器 `UserSelect`、用户展示 `UserDisplay`、服务端按 ID 查人 `AuthNPaasService.listUsersByIds`），不开发登录注册

## 页面路由与导航

### 页面路由
| 路由 | 页面 |
|------|------|
| / | 工作台 |
| /quotations | 智能报价 |
| /customers | 客户管理 |
| /customers/:id | 客户详情 |
| /projects | 项目管理 |
| /projects/:id | 项目详情 |
| /daily-reports | 员工日报 |
| /permissions | 权限管理 |

### 导航设计
- 导航机制：页面路由（全局左侧边栏，PC 宽屏布局）
- 导航项：
  - 工作台（/，默认选中）
  - 智能报价
  - 客户管理
  - 项目管理
  - 员工日报
  - 权限管理（仅拥有权限管理查看权限点的用户可见）

## 业务组件
| 组件 | 来源 | 关联页面 | 对应功能点 |
|------|------|---------|-----------|
| UserSelect 人员选择器 | 平台内置用户组件 | 项目管理、项目详情、权限管理 | 选取项目负责人/成员、指派任务、为成员分配角色 |
| UserDisplay 用户展示 | 平台内置用户组件 | 项目详情、员工日报、权限管理 | 展示成员/提交人姓名头像 |
| useCurrentUserProfile | 平台内置 Hook | 工作台、员工日报 | 问候条展示当前用户姓名、日报默认作者 |

## 数据模型

### 数据库设计

> id 主键与审计字段（_created_at/_updated_at/_created_by/_updated_by）平台自动包含，不再声明。人员字段一律使用 `user_profile` 类型。

#### 客户表（customer）
用途：存储客户主数据档案。
核心字段：
- name: varchar（客户名称，业务唯一，服务端创建时查重拦截）
- industry: varchar（所属行业）
- contact_name: varchar（联系人）
- contact_phone: varchar（联系电话）
- address: varchar（地址）
- last_followed_at: timestamp（最近跟进时间，创建跟进记录时由服务端更新）
关联关系：与跟进记录表、报价单表一对多

#### 跟进记录表（follow_up）
用途：存储客户跟进记录。
核心字段：
- customer_id: relation（关联客户表）
- method: varchar（跟进方式：电话/拜访/线上会议/其他）
- content: text（跟进内容）
- next_follow_at: date（下次跟进时间）
- operator: user_profile（跟进操作人）
关联关系：多对一关联客户表

#### 报价单表（quotation）
用途：存储报价单主信息、状态与 AI 报价建议。
核心字段：
- quotation_no: varchar（报价单号，服务端生成，如 QT-YYYYMMDD-序号）
- customer_id: relation（关联客户表）
- total_amount: decimal（总金额，由明细金额合计）
- status: varchar ['draft', 'sent', 'confirmed', 'closed']（草稿/已发送/已确认/已关闭）
- remark: text（报价说明）
- ai_suggestion: text（AI 生成的报价建议，可为空）
关联关系：多对一关联客户表；与报价明细表一对多

#### 报价明细表（quotation_item）
用途：存储报价单的产品/服务明细行。
核心字段：
- quotation_id: relation（关联报价单表）
- item_name: varchar（产品/服务名称）
- quantity: decimal（数量）
- unit_price: decimal（单价）
- amount: decimal（金额 = 数量 × 单价）
关联关系：多对一关联报价单表

#### 项目表（project）
用途：存储项目立项信息与阶段进度。
核心字段：
- name: varchar（项目名称）
- owner: user_profile（项目负责人）
- start_date: date（开始日期）
- end_date: date（结束日期）
- description: text（项目说明）
- status: varchar ['not_started', 'in_progress', 'completed', 'delayed']（未开始/进行中/已完成/延期）
- progress: integer（进度百分比 0-100，服务端按任务完成率计算）
关联关系：与项目成员表、项目任务表一对多

#### 项目成员表（project_member）
用途：存储项目成员名单。
核心字段：
- project_id: relation（关联项目表）
- member: user_profile（项目成员，同一项目内唯一）
关联关系：多对一关联项目表

#### 项目任务表（project_task）
用途：存储项目下的任务及指派与完成情况。
核心字段：
- project_id: relation（关联项目表）
- task_name: varchar（任务名称）
- assignee: user_profile（任务负责人）
- status: varchar ['pending', 'completed']（待办/已完成）
- due_date: date（截止日期）
关联关系：多对一关联项目表

#### 日报表（daily_report）
用途：存储员工按天提交的日报，同一作者同一日期仅一条（upsert）。
核心字段：
- report_date: date（日报日期，与作者联合唯一）
- author: user_profile（提交人）
- today_content: text（今日工作内容）
- tomorrow_plan: text（明日计划）
- risk: text（问题与风险）
关联关系：无

## 插件设计
| 插件名称 | 基础插件 | 用途 | 调用方式 | 关联页面 | 输入参数 | 输出类型 |
|---------|---------|------|---------|---------|---------|---------|
| quotation-ai-generate | ai-text-to-json | 根据客户需求描述生成报价明细与报价建议，回填报价表单 | 前端 capabilityClient（用户交互触发、结果经已有报价创建接口落库，无需服务端中转） | 智能报价 | requirementDesc: string（客户需求描述） | { itemsJson: string（报价明细 JSON 数组字符串，每项含 itemName/quantity/unitPrice）, suggestion: string（报价建议） } |

说明：
- 创建实例时须一次性定义全部输出字段（itemsJson、suggestion），实施时以 `get_plugin_ai_json` 运行时投影为准生成调用代码
- 前端解析 itemsJson 后回填明细行供逐条编辑；「重新生成」即重新调用同一实例
- 禁止 mock 插件返回值；生成失败时前端给出错误提示

## 业务模型

### 权限点位规划
权限点定义放入 shared 契约（6 个模块 × 查看/操作），全部业务 API 用 `@Can(action, subject)` 鉴权、前端菜单与操作按钮用 `<Can>` 控制显隐，禁止混用 CanRole：
- workbench: read（工作台所有人可见，不做点位拦截）
- quotation: read / operate（查看列表详情 / 新建与状态流转）
- customer: read / operate（查看列表详情 / 新建编辑客户与跟进）
- project: read / operate（查看列表详情 / 立项、阶段变更、任务与成员管理）
- daily-report: read / operate（查看团队日报 / 提交日报）
- permission: read / operate（查看权限管理页 / 管理角色与成员授权）

预置角色（实施时经角色管理创建）：管理员（全部点位，内置不可删除）、销售（报价/客户读写、项目/日报读、日报写）、项目经理（项目读写、日报读写、客户/报价读）、普通员工（日报读写、各模块读）。开发环境用 MOCK 角色，线上由管理员在权限管理页或角色面板授权。

### API 设计

> 统一约定：分页返回 `{ items, total }`；人员展示信息由服务端经 `AuthNPaasService.listUsersByIds` 补充姓名头像；403 由前端统一请求层在 response 层拦截提示，不落 catch。

#### 工作台 相关
**页面路径**: /
**功能全景**：
| 功能 | 实现方式 | 说明 |
|------|----------|------|
| 四大模块数据概览卡片 | API | GET /api/dashboard/overview |
| 待办提醒（客户跟进/项目节点/日报未交） | API | GET /api/dashboard/todos |
| 问候条展示当前用户姓名 | 平台能力 | useCurrentUserProfile |
| 侧边栏菜单按权限显隐 | 平台能力 | 动态权限点位 `<Can>` |

**所需 API**:
```typescript
// 数据概览 [领域模型: Quotation/Customer/Project/DailyReport] [对应页面功能: 数据概览卡片区]
GET /api/dashboard/overview
Response: { monthlyQuotationCount: number; monthlyQuotationAmount: number; customerCount: number; activeProjectCount: number; todayReportCount: number }

// 待办提醒 [领域模型: FollowUp/Project/DailyReport] [对应页面功能: 待办提醒区]
GET /api/dashboard/todos
Response: {
  followUps: Array<{ customerId: string; customerName: string; nextFollowAt: string }>;
  nearingProjects: Array<{ projectId: string; projectName: string; endDate: string }>;
  dailyReportMissing: boolean;
}
```

#### 智能报价 相关
**页面路径**: /quotations
**功能全景**：
| 功能 | 实现方式 | 说明 |
|------|----------|------|
| 报价列表与状态筛选 | API | GET /api/quotations |
| 报价详情（明细与建议） | API | GET /api/quotations/:id |
| 新建报价（含明细） | API | POST /api/quotations |
| 状态流转 | API | PATCH /api/quotations/:id/status |
| AI 智能生成明细与建议 | 插件 | quotation-ai-generate（ai-text-to-json），前端 capabilityClient |

**所需 API**:
```typescript
// 报价列表 [领域模型: QuotationModel] [对应页面功能: 报价列表]
GET /api/quotations?status=draft&page=1&pageSize=20
Response: { items: Array<{ id: string; quotationNo: string; customerName: string; totalAmount: number; status: 'draft' | 'sent' | 'confirmed' | 'closed'; updatedAt: string }>; total: number }

// 报价详情 [领域模型: QuotationModel + QuotationItemModel] [对应页面功能: 详情抽屉]
GET /api/quotations/:id
Response: { id: string; quotationNo: string; customerId: string; customerName: string; totalAmount: number; status: string; remark: string | null; aiSuggestion: string | null; items: Array<{ id: string; itemName: string; quantity: number; unitPrice: number; amount: number }>; updatedAt: string }

// 新建报价 [领域模型: QuotationModel] [对应页面功能: 新建报价弹窗]
POST /api/quotations
Request: { customerId: string; remark?: string; aiSuggestion?: string; items: Array<{ itemName: string; quantity: number; unitPrice: number }> }
Response: { id: string }
// 服务端校验客户与至少一条明细必填，金额服务端合计

// 状态流转 [领域模型: QuotationModel] [对应页面功能: 状态流转]
PATCH /api/quotations/:id/status
Request: { status: 'sent' | 'confirmed' | 'closed' }
Response: { success: boolean }
// 流转规则：草稿→已发送→已确认/已关闭；已关闭不可再流转，服务端拦截
```

#### 客户管理 相关
**页面路径**: /customers、/customers/:id
**功能全景**：
| 功能 | 实现方式 | 说明 |
|------|----------|------|
| 客户列表、搜索、行业筛选、分页 | API | GET /api/customers |
| 新建客户（名称查重拦截） | API | POST /api/customers |
| 编辑客户 | API | PATCH /api/customers/:id |
| 客户详情 | API | GET /api/customers/:id |
| 跟进时间线 | API | GET /api/customers/:id/follow-ups |
| 添加跟进 | API | POST /api/customers/:id/follow-ups |
| 关联报价列表 | API | GET /api/customers/:id/quotations |

**所需 API**:
```typescript
// 客户列表 [领域模型: CustomerModel] [对应页面功能: 客户列表/搜索与筛选区]
GET /api/customers?keyword=张&industry=互联网&page=1&pageSize=20
Response: { items: Array<{ id: string; name: string; industry: string; contactName: string; contactPhone: string; lastFollowedAt: string | null }>; total: number }
// keyword 匹配客户名称或联系人

// 新建客户 [领域模型: CustomerModel] [对应页面功能: 新建与编辑客户]
POST /api/customers
Request: { name: string; industry?: string; contactName?: string; contactPhone?: string; address?: string }
Response: { id: string }
// 名称必填且唯一，重复返回业务错误提示

// 编辑客户 [领域模型: CustomerModel] [对应页面功能: 新建与编辑客户]
PATCH /api/customers/:id
Request: { name?: string; industry?: string; contactName?: string; contactPhone?: string; address?: string }
Response: { success: boolean }

// 客户详情 [领域模型: CustomerModel] [对应页面功能: 基本信息卡]
GET /api/customers/:id
Response: { id: string; name: string; industry: string; contactName: string; contactPhone: string; address: string }

// 跟进时间线 [领域模型: FollowUpModel] [对应页面功能: 跟进时间线]
GET /api/customers/:id/follow-ups
Response: { items: Array<{ id: string; method: string; content: string; operatorName: string; nextFollowAt: string | null; createdAt: string }> }

// 添加跟进 [领域模型: FollowUpModel] [对应页面功能: 添加跟进弹窗]
POST /api/customers/:id/follow-ups
Request: { method: string; content: string; nextFollowAt?: string }
Response: { id: string }
// 操作人取当前登录用户；创建后同步更新客户最近跟进时间

// 关联报价 [领域模型: QuotationModel] [对应页面功能: 关联报价区]
GET /api/customers/:id/quotations
Response: { items: Array<{ id: string; quotationNo: string; totalAmount: number; status: string }> }
```

#### 项目管理 相关
**页面路径**: /projects、/projects/:id
**功能全景**：
| 功能 | 实现方式 | 说明 |
|------|----------|------|
| 项目列表与状态筛选 | API | GET /api/projects |
| 新建项目 | API | POST /api/projects |
| 项目详情（含成员） | API | GET /api/projects/:id |
| 阶段变更 | API | PATCH /api/projects/:id/status |
| 补充成员 | API | POST /api/projects/:id/members |
| 任务列表/新建/完成 | API | GET/POST /api/projects/:id/tasks、PATCH /api/projects/:id/tasks/:taskId |
| 负责人/成员选取 | 平台能力 | UserSelect 人员选择器 |

**所需 API**:
```typescript
// 项目列表 [领域模型: ProjectModel] [对应页面功能: 项目列表]
GET /api/projects?status=in_progress
Response: { items: Array<{ id: string; name: string; ownerName: string; startDate: string; endDate: string; status: 'not_started' | 'in_progress' | 'completed' | 'delayed'; progress: number }> }

// 新建项目 [领域模型: ProjectModel + ProjectMemberModel] [对应页面功能: 新建项目弹窗]
POST /api/projects
Request: { name: string; startDate: string; endDate: string; description?: string; ownerId: string; memberIds: string[] }
Response: { id: string }
// ownerId/memberIds 为人员选择器返回的用户 ID；新项目默认「未开始」

// 项目详情 [领域模型: ProjectModel + ProjectMemberModel] [对应页面功能: 项目概览区/成员区]
GET /api/projects/:id
Response: { id: string; name: string; ownerId: string; ownerName: string; startDate: string; endDate: string; description: string; status: string; progress: number; members: Array<{ userId: string; name: string; avatar: string }> }

// 阶段变更 [领域模型: ProjectModel] [对应页面功能: 阶段变更操作]
PATCH /api/projects/:id/status
Request: { status: 'not_started' | 'in_progress' | 'completed' | 'delayed' }
Response: { success: boolean }

// 补充成员 [领域模型: ProjectMemberModel] [对应页面功能: 成员区]
POST /api/projects/:id/members
Request: { memberIds: string[] }
Response: { success: boolean }

// 任务列表 [领域模型: ProjectTaskModel] [对应页面功能: 任务管理区]
GET /api/projects/:id/tasks
Response: { items: Array<{ id: string; taskName: string; assigneeName: string; status: 'pending' | 'completed'; dueDate: string }> }

// 新建任务 [领域模型: ProjectTaskModel] [对应页面功能: 新建任务弹窗]
POST /api/projects/:id/tasks
Request: { taskName: string; assigneeId: string; dueDate: string }
Response: { id: string }
// 创建后服务端按任务完成率重算项目进度

// 标记任务完成 [领域模型: ProjectTaskModel] [对应页面功能: 标记任务完成]
PATCH /api/projects/:id/tasks/:taskId
Request: { status: 'completed' }
Response: { success: boolean }
// 完成后服务端重算项目进度
```

#### 员工日报 相关
**页面路径**: /daily-reports
**功能全景**：
| 功能 | 实现方式 | 说明 |
|------|----------|------|
| 提交/更新日报 | API | POST /api/daily-reports（同人同日 upsert） |
| 我的日报列表 | API | GET /api/daily-reports/mine |
| 团队日报（提交情况与内容） | API | GET /api/daily-reports/team |
| 当前用户信息 | 平台能力 | useCurrentUserProfile |

**所需 API**:
```typescript
// 提交日报 [领域模型: DailyReportModel] [对应页面功能: 日报提交表单]
POST /api/daily-reports
Request: { reportDate: string; todayContent: string; tomorrowPlan?: string; risk?: string }
Response: { id: string; created: boolean }
// 作者取当前登录用户；同人同日已存在则更新并返回 created: false

// 我的日报 [领域模型: DailyReportModel] [对应页面功能: 我的日报列表]
GET /api/daily-reports/mine
Response: { items: Array<{ id: string; reportDate: string; todayContent: string; tomorrowPlan: string; risk: string; createdAt: string }> }

// 团队日报 [领域模型: DailyReportModel] [对应页面功能: 团队日报标签页]
GET /api/daily-reports/team?date=2026-09-10&memberId=
Response: { items: Array<{ userId: string; userName: string; submitted: boolean; reportId: string | null; todayContent: string | null; tomorrowPlan: string | null; risk: string | null; submittedAt: string | null }> }
// 成员范围以历史提交过日报的用户聚合为准（服务端无法获取企业全员名单），未提交者 submitted 为 false
```

#### 权限管理 相关
**页面路径**: /permissions
**功能全景**：
| 功能 | 实现方式 | 说明 |
|------|----------|------|
| 角色列表/新建/编辑/删除（含勾选权限点） | API + 平台能力 | 服务端经 AuthorizationSDK 操作，禁止自封装 |
| 成员列表与角色分配 | API + 平台能力 | 成员名单按各角色成员聚合；分配经 AuthorizationSDK |
| 菜单与操作按钮按点位显隐 | 平台能力 | `<Can>` 组件 + 权限点位 |
| 权限体系设计确认 | 平台能力 | 实施前先完成 rbac_role_manager DESIGN |

**所需 API**:
```typescript
// 角色列表 [领域模型: 平台角色] [对应页面功能: 角色管理]
GET /api/permission-admin/roles
Response: { items: Array<{ id: string; name: string; bizId: string; isBuiltin: boolean; permissions: string[]; memberCount: number }> }

// 新建角色（勾选权限点） [领域模型: 平台角色] [对应页面功能: 角色管理]
POST /api/permission-admin/roles
Request: { name: string; permissionKeys: string[] }
Response: { id: string }

// 更新角色权限点 [领域模型: 平台角色] [对应页面功能: 角色管理]
PATCH /api/permission-admin/roles/:id
Request: { name?: string; permissionKeys?: string[] }
Response: { success: boolean }

// 删除角色 [领域模型: 平台角色] [对应页面功能: 角色管理]
DELETE /api/permission-admin/roles/:id
Response: { success: boolean }
// 内置角色（含管理员）不可删除；仍有成员挂靠时拒绝删除并提示

// 成员列表 [领域模型: 平台角色成员] [对应页面功能: 成员授权]
GET /api/permission-admin/members
Response: { items: Array<{ userId: string; name: string; avatar: string; departmentName: string | null; roleIds: string[]; roleNames: string[] }> }

// 为成员分配/变更角色 [领域模型: 平台角色成员] [对应页面功能: 成员授权]
POST /api/permission-admin/members/:userId/roles
Request: { roleIds: string[] }
Response: { success: boolean }
// 分配后立即生效；成员按新角色点位刷新菜单与操作入口
```