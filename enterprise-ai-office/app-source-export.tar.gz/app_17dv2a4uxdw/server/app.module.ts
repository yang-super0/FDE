import { APP_FILTER } from '@nestjs/core';
import { Module } from '@nestjs/common';
import { PlatformModule } from '@lark-apaas/fullstack-nestjs-core';

import { GlobalExceptionFilter } from './common/filters/exception.filter';
import { ViewModule } from './modules/view/view.module';
import { DbPermissionResolver } from './modules/permission/db-permission-resolver';
import { PermissionModule } from './modules/permission/permission.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { QuotationModule } from './modules/quotation/quotation.module';
import { ProductsModule } from './modules/products/products.module';
import { CustomerModule } from './modules/customer/customer.module';
import { ProjectModule } from './modules/project/project.module';
import { DailyReportModule } from './modules/daily-report/daily-report.module';
import { PermissionAdminModule } from './modules/permission-admin/permission-admin.module';
import { MasterDataModule } from './modules/master-data/master-data.module';
import { MeetingMinutesModule } from './modules/meeting-minutes/meeting-minutes.module';
import { AlertModule } from './modules/alert/alert.module';

@Module({
  imports: [
    // 平台 Module，提供平台能力与动态权限点位解析
    PlatformModule.forRoot({
      authz: { permissionResolver: DbPermissionResolver },
    }),
    PermissionModule,
    // ====== @route-section: business-modules START ======
    DashboardModule,
    ProductsModule,
    QuotationModule,
    CustomerModule,
    ProjectModule,
    DailyReportModule,
    PermissionAdminModule,
    MasterDataModule,
    MeetingMinutesModule,
    AlertModule,
    // ====== @route-section: business-modules END ======

    // ⚠️ @route-order: last
    // ViewModule is the fallback route module, must be registered last.
    ViewModule,
  ],
  providers: [
    {
      provide: APP_FILTER,
      useClass: GlobalExceptionFilter,
    },
  ],
})
export class AppModule {}
