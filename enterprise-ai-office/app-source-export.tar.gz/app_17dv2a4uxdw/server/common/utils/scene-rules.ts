import type { ProjectScene } from '@shared/api.interface';

export const PROJECT_SCENES: ProjectScene[] = [
  '普通项目',
  '沿海项目',
  '高速项目',
  '山地项目',
];

type SceneConditions = Record<string, string>;

const SCENE_CONDITIONS: Record<ProjectScene, SceneConditions> = {
  普通项目: {},
  沿海项目: { project_environment: 'coastal' },
  高速项目: { road_type: 'expressway' },
  山地项目: {},
};

export type RuleConditions = Record<string, string | number | boolean>;

function effectiveEntries(
  conditions: RuleConditions | null,
): Array<[string, string]> {
  if (!conditions || typeof conditions !== 'object') {
    return [];
  }
  return Object.entries(conditions)
    .filter(([key]: [string, string | number | boolean]) => key !== 'required')
    .map(
      ([key, value]: [string, string | number | boolean]) =>
        [key, String(value)] as [string, string],
    );
}

export function sceneMatchesConditions(
  scene: ProjectScene,
  conditions: RuleConditions | null,
): boolean {
  if (scene === '普通项目') {
    return false;
  }
  const entries: Array<[string, string]> = effectiveEntries(conditions);
  if (entries.length === 0) {
    return false;
  }
  const sceneConditions: SceneConditions = SCENE_CONDITIONS[scene];
  return entries.every(
    ([key, value]: [string, string]) => sceneConditions[key] === value,
  );
}

export function scenesMatchingConditions(
  conditions: RuleConditions | null,
): ProjectScene[] {
  return PROJECT_SCENES.filter((scene: ProjectScene) =>
    sceneMatchesConditions(scene, conditions),
  );
}

export function isValidProjectScene(value: unknown): value is ProjectScene {
  return (
    typeof value === 'string' &&
    PROJECT_SCENES.includes(value as ProjectScene)
  );
}
