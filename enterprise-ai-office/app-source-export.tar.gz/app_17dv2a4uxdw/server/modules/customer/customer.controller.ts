import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
} from '@nestjs/common';
import {
  AuthorizationSDK,
  Can,
  type UserSimpleDTO,
} from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import type {
  CreateCustomerResponse,
  CreateFollowUpResponse,
  CustomerDetail,
  CustomerListResponse,
  CustomerOwnerListResponse,
  CustomerProjectListResponse,
  CustomerQuotationListResponse,
  CustomerUnassignedCountResponse,
  CurrentUserRoleResponse,
  FollowUpListResponse,
  SuccessResponse,
} from '@shared/api.interface';
import { ROLE_KEYS } from '@shared/permissions';
import {
  CustomerService,
  type CustomerViewerContext,
} from './customer.service';
import { ProjectService } from '../project/project.service';
import {
  BatchAssignCustomerDto,
  CreateCustomerDto,
  CreateFollowUpDto,
  CustomerListQueryDto,
  TransferCustomerDto,
  UpdateCustomerDto,
} from './customer.dto';

const DEFAULT_PAGE: number = 1;
const DEFAULT_PAGE_SIZE: number = 20;
const MAX_PAGE_SIZE: number = 50;

@Controller('api/customers')
export class CustomerController {
  constructor(
    private readonly customerService: CustomerService,
    private readonly projectService: ProjectService,
    private readonly authorizationSDK: AuthorizationSDK,
  ) {}

  @Can('read', 'Customer')
  @Get()
  async list(
    @Req() req: Request,
    @Query() query: CustomerListQueryDto,
  ): Promise<CustomerListResponse> {
    const page: number = this.toPositiveInt(query.page, DEFAULT_PAGE);
    const rawPageSize: number = this.toPositiveInt(
      query.pageSize,
      DEFAULT_PAGE_SIZE,
    );
    const pageSize: number = Math.min(rawPageSize, MAX_PAGE_SIZE);
    const keyword: string | undefined = query.keyword?.trim() || undefined;
    const industry: string | undefined = query.industry?.trim() || undefined;
    const ownerId: string | undefined = query.ownerId?.trim() || undefined;
    return this.customerService.list(
      { keyword, industry, ownerId, page, pageSize },
      await this.toViewer(req),
    );
  }

  @Can('operate', 'Customer')
  @Post()
  async create(
    @Req() req: Request,
    @Body() dto: CreateCustomerDto,
  ): Promise<CreateCustomerResponse> {
    const name: string = (dto.name ?? '').trim();
    if (!name) {
      throw new BadRequestException('客户名称不能为空');
    }
    const ownerId: string | undefined = dto.ownerId?.trim() || undefined;
    return this.customerService.create(
      {
        name,
        industry: dto.industry,
        contactName: dto.contactName,
        contactPhone: dto.contactPhone,
        address: dto.address,
        ownerId,
      },
      await this.toViewer(req),
    );
  }

  @Can('read', 'Customer')
  @Get('me/role')
  async currentRole(@Req() req: Request): Promise<CurrentUserRoleResponse> {
    return { isAdmin: await this.isAdmin(req) };
  }

  @Can('read', 'Customer')
  @Get('owners')
  async listOwners(
    @Req() req: Request,
  ): Promise<CustomerOwnerListResponse> {
    return this.customerService.listOwnerOptions(await this.toViewer(req));
  }

  @Can('read', 'Customer')
  @Get('unassigned-count')
  unassignedCount(): Promise<CustomerUnassignedCountResponse> {
    return this.customerService.countUnassigned();
  }

  @Can('operate', 'Customer')
  @Post('batch-assign')
  async batchAssign(
    @Req() req: Request,
    @Body() dto: BatchAssignCustomerDto,
  ): Promise<SuccessResponse> {
    const ownerId: string = (dto.ownerId ?? '').trim();
    if (!ownerId) {
      throw new BadRequestException('请选择负责人');
    }
    const customerIds: string[] = (dto.customerIds ?? []).filter(
      (id: string) => Boolean(id),
    );
    if (customerIds.length === 0) {
      throw new BadRequestException('请选择客户');
    }
    return this.customerService.batchAssign(
      customerIds,
      ownerId,
      await this.toViewer(req),
    );
  }

  @Can('read', 'Customer')
  @Get(':id')
  async detail(
    @Req() req: Request,
    @Param('id') id: string,
  ): Promise<CustomerDetail> {
    return this.customerService.detail(id, await this.toViewer(req));
  }

  @Can('operate', 'Customer')
  @Patch(':id')
  async update(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateCustomerDto,
  ): Promise<SuccessResponse> {
    return this.customerService.update(
      id,
      {
        name: dto.name?.trim(),
        industry: dto.industry,
        contactName: dto.contactName,
        contactPhone: dto.contactPhone,
        address: dto.address,
        ownerId: dto.ownerId,
      },
      await this.toViewer(req),
    );
  }

  @Can('operate', 'Customer')
  @Post(':id/transfer')
  async transfer(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: TransferCustomerDto,
  ): Promise<SuccessResponse> {
    const ownerId: string = (dto.ownerId ?? '').trim();
    if (!ownerId) {
      throw new BadRequestException('请选择新负责人');
    }
    return this.customerService.transfer(
      id,
      { ownerId, reason: dto.reason?.trim() || undefined },
      await this.toViewer(req),
    );
  }

  @Can('read', 'Customer')
  @Get(':id/follow-ups')
  listFollowUps(@Param('id') id: string): Promise<FollowUpListResponse> {
    return this.customerService.listFollowUps(id);
  }

  @Can('operate', 'Customer')
  @Post(':id/follow-ups')
  createFollowUp(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: CreateFollowUpDto,
  ): Promise<CreateFollowUpResponse> {
    const method: string = (dto.method ?? '').trim();
    const content: string = (dto.content ?? '').trim();
    if (!method || !content) {
      throw new BadRequestException('跟进方式与跟进内容不能为空');
    }
    const userId: string = req.userContext.userId;
    return this.customerService.createFollowUp(
      id,
      {
        method,
        content,
        nextFollowAt: dto.nextFollowAt?.trim() || undefined,
      },
      userId,
    );
  }

  @Can('read', 'Customer')
  @Get(':id/quotations')
  listQuotations(
    @Param('id') id: string,
  ): Promise<CustomerQuotationListResponse> {
    return this.customerService.listQuotations(id);
  }

  @Can('read', 'Customer')
  @Get(':id/projects')
  listProjects(
    @Param('id') id: string,
  ): Promise<CustomerProjectListResponse> {
    return this.projectService.listByCustomer(id).then((items) => ({ items }));
  }

  private toPositiveInt(value: unknown, fallback: number): number {
    const parsed: number = Number(value);
    return Number.isFinite(parsed) && parsed > 0
      ? Math.floor(parsed)
      : fallback;
  }

  private async isAdmin(req: Request): Promise<boolean> {
    const injectedRoles: string[] | null = req.userContext.roles ?? null;
    if (injectedRoles !== null) {
      return injectedRoles.includes(ROLE_KEYS.admin);
    }
    const userId: string | undefined = req.userContext?.userId;
    if (!userId) {
      return false;
    }
    const res = await this.authorizationSDK.members.list(ROLE_KEYS.admin, {
      userID: userId,
    });
    const members: UserSimpleDTO[] = res.members.userList ?? [];
    return members.some(
      (member: UserSimpleDTO) => member.userID === userId,
    );
  }

  private async toViewer(req: Request): Promise<CustomerViewerContext> {
    return {
      isAdmin: await this.isAdmin(req),
      userId: req.userContext.userId,
    };
  }
}
