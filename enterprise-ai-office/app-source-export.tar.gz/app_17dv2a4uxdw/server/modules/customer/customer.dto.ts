import { Type } from 'class-transformer';
import {
  ArrayNotEmpty,
  IsArray,
  IsInt,
  IsOptional,
  IsString,
  Max,
  Min,
  ValidateIf,
} from 'class-validator';

export class CustomerListQueryDto {
  @IsOptional()
  @IsString()
  keyword?: string;

  @IsOptional()
  @IsString()
  industry?: string;

  @IsOptional()
  @IsString()
  ownerId?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(50)
  pageSize?: number;
}

export class CreateCustomerDto {
  @IsString()
  name!: string;

  @IsOptional()
  @IsString()
  industry?: string;

  @IsOptional()
  @IsString()
  contactName?: string;

  @IsOptional()
  @IsString()
  contactPhone?: string;

  @IsOptional()
  @IsString()
  address?: string;

  @IsOptional()
  @IsString()
  ownerId?: string;
}

export class UpdateCustomerDto {
  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsString()
  industry?: string;

  @IsOptional()
  @IsString()
  contactName?: string;

  @IsOptional()
  @IsString()
  contactPhone?: string;

  @IsOptional()
  @IsString()
  address?: string;

  @IsOptional()
  @ValidateIf((_object: UpdateCustomerDto, value: unknown) => value !== null)
  @IsString()
  ownerId?: string | null;
}

export class CreateFollowUpDto {
  @IsString()
  method!: string;

  @IsString()
  content!: string;

  @IsOptional()
  @IsString()
  nextFollowAt?: string;
}

export class BatchAssignCustomerDto {
  @IsArray()
  @ArrayNotEmpty()
  @IsString({ each: true })
  customerIds!: string[];

  @IsString()
  ownerId!: string;
}

export class TransferCustomerDto {
  @IsString()
  ownerId!: string;

  @IsOptional()
  @IsString()
  reason?: string;
}
