import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Inject } from '@nestjs/common';
import {
  and,
  count,
  desc,
  eq,
  ilike,
  inArray,
  isNotNull,
  isNull,
  ne,
  or,
  sql,
} from 'drizzle-orm';
import type { SQL } from 'drizzle-orm';
import {
  AuthNPaasService,
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { customer, followUp, quotation } from '@server/database/schema';
import type {
  CreateCustomerResponse,
  CreateFollowUpResponse,
  CustomerDetail,
  CustomerListResponse,
  CustomerOwnerListResponse,
  CustomerOwnerOption,
  CustomerQuotationItem,
  CustomerQuotationListResponse,
  CustomerUnassignedCountResponse,
  FollowUpItem,
  FollowUpListResponse,
  QuotationStatus,
  SuccessResponse,
} from '@shared/api.interface';

export interface CustomerListQuery {
  keyword?: string;
  industry?: string;
  ownerId?: string;
  page: number;
  pageSize: number;
}

export interface CustomerViewerContext {
  isAdmin: boolean;
  userId: string;
}

export interface CustomerWriteInput {
  name: string;
  industry?: string;
  contactName?: string;
  contactPhone?: string;
  address?: string;
  ownerId?: string;
}

export interface CustomerPatchInput {
  name?: string;
  industry?: string;
  contactName?: string;
  contactPhone?: string;
  address?: string;
  ownerId?: string | null;
}

export interface FollowUpWriteInput {
  method: string;
  content: string;
  nextFollowAt?: string;
}

export interface TransferCustomerInput {
  ownerId: string;
  reason?: string;
}

const UNASSIGNED_FILTER: string = 'unassigned';
const TRANSFER_METHOD: string = '客户转移';

@Injectable()
export class CustomerService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
    private readonly authn: AuthNPaasService,
  ) {}

  async list(
    params: CustomerListQuery,
    viewer: CustomerViewerContext,
  ): Promise<CustomerListResponse> {
    const conditions: SQL[] = [];
    if (!viewer.isAdmin) {
      const scopeCondition: SQL | undefined = or(
        sql`(${customer.owner}).user_id = ${viewer.userId}`,
        isNull(customer.owner),
      );
      if (scopeCondition) {
        conditions.push(scopeCondition);
      }
    }
    if (params.keyword) {
      const likePattern: string = `%${params.keyword}%`;
      const keywordCondition: SQL | undefined = or(
        ilike(customer.name, likePattern),
        ilike(customer.contactName, likePattern),
      );
      if (keywordCondition) {
        conditions.push(keywordCondition);
      }
    }
    if (params.industry) {
      conditions.push(eq(customer.industry, params.industry));
    }
    if (params.ownerId === UNASSIGNED_FILTER) {
      conditions.push(isNull(customer.owner));
    } else if (params.ownerId) {
      conditions.push(sql`(${customer.owner}).user_id = ${params.ownerId}`);
    }
    const whereClause: SQL | undefined =
      conditions.length > 0 ? and(...conditions) : undefined;

    const rows: Array<typeof customer.$inferSelect> = await this.db
      .select()
      .from(customer)
      .where(whereClause)
      .orderBy(desc(customer.createdAt))
      .limit(params.pageSize)
      .offset((params.page - 1) * params.pageSize);

    const countRows: Array<{ count: number }> = await this.db
      .select({ count: count() })
      .from(customer)
      .where(whereClause);

    const nameById: Map<string, string> = await this.resolveUserNames(
      rows
        .map((row: typeof customer.$inferSelect) => row.owner)
        .filter((owner: string | null): owner is string => owner !== null),
    );

    return {
      items: rows.map(
        (row: typeof customer.$inferSelect) => ({
          id: row.id,
          name: row.name,
          industry: row.industry ?? '',
          contactName: row.contactName ?? '',
          contactPhone: row.contactPhone ?? '',
          lastFollowedAt: row.lastFollowedAt
            ? row.lastFollowedAt.toISOString()
            : null,
          ownerId: row.owner ?? null,
          ownerName: row.owner ? nameById.get(row.owner) ?? '' : '',
        }),
      ),
      total: Number(countRows[0]?.count ?? '0'),
    };
  }

  async create(
    input: CustomerWriteInput,
    viewer: CustomerViewerContext,
  ): Promise<CreateCustomerResponse> {
    const duplicated: Array<{ id: string }> = await this.db
      .select({ id: customer.id })
      .from(customer)
      .where(ilike(customer.name, input.name))
      .limit(1);
    if (duplicated.length > 0) {
      throw new ConflictException('客户名称已存在');
    }

    const ownerId: string = input.ownerId ?? viewer.userId;
    const inserted: Array<{ id: string }> = await this.db
      .insert(customer)
      .values({
        name: input.name,
        industry: input.industry,
        contactName: input.contactName,
        contactPhone: input.contactPhone,
        address: input.address,
        owner: ownerId,
      })
      .returning({ id: customer.id });
    return { id: inserted[0].id };
  }

  async update(
    id: string,
    patchInput: CustomerPatchInput,
    viewer: CustomerViewerContext,
  ): Promise<SuccessResponse> {
    if (patchInput.ownerId !== undefined && !viewer.isAdmin) {
      throw new ForbiddenException('仅管理员可以修改客户负责人');
    }
    const patch: Partial<typeof customer.$inferInsert> = {};
    if (patchInput.name !== undefined) {
      patch.name = patchInput.name;
    }
    if (patchInput.industry !== undefined) {
      patch.industry = patchInput.industry;
    }
    if (patchInput.contactName !== undefined) {
      patch.contactName = patchInput.contactName;
    }
    if (patchInput.contactPhone !== undefined) {
      patch.contactPhone = patchInput.contactPhone;
    }
    if (patchInput.address !== undefined) {
      patch.address = patchInput.address;
    }
    if (patchInput.ownerId !== undefined) {
      patch.owner = patchInput.ownerId === '' ? null : patchInput.ownerId;
    }
    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }

    if (patchInput.name !== undefined) {
      const duplicated: Array<{ id: string }> = await this.db
        .select({ id: customer.id })
        .from(customer)
        .where(and(ilike(customer.name, patchInput.name), ne(customer.id, id)))
        .limit(1);
      if (duplicated.length > 0) {
        throw new ConflictException('客户名称已存在');
      }
    }

    patch.updatedAt = new Date();
    patch.updatedBy = viewer.userId;

    const updated: Array<{ id: string }> = await this.db
      .update(customer)
      .set(patch)
      .where(eq(customer.id, id))
      .returning({ id: customer.id });
    if (updated.length === 0) {
      throw new NotFoundException('客户不存在');
    }
    return { success: true };
  }

  async detail(
    id: string,
    viewer: CustomerViewerContext,
  ): Promise<CustomerDetail> {
    const rows: Array<typeof customer.$inferSelect> = await this.db
      .select()
      .from(customer)
      .where(eq(customer.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('客户不存在');
    }
    const row: typeof customer.$inferSelect = rows[0];
    if (!viewer.isAdmin && row.owner !== null && row.owner !== viewer.userId) {
      throw new ForbiddenException('无权查看该客户');
    }
    const nameById: Map<string, string> = await this.resolveUserNames(
      row.owner !== null ? [row.owner] : [],
    );
    return {
      id: row.id,
      name: row.name,
      industry: row.industry ?? '',
      contactName: row.contactName ?? '',
      contactPhone: row.contactPhone ?? '',
      address: row.address ?? '',
      ownerId: row.owner ?? null,
      ownerName: row.owner ? nameById.get(row.owner) ?? '' : '',
    };
  }

  async listFollowUps(customerId: string): Promise<FollowUpListResponse> {
    const rows: Array<typeof followUp.$inferSelect> = await this.db
      .select()
      .from(followUp)
      .where(eq(followUp.customerId, customerId))
      .orderBy(desc(followUp.createdAt));

    const operatorIds: string[] = [
      ...new Set(rows.map((row: typeof followUp.$inferSelect) => row.operator)),
    ];
    const nameById: Map<string, string> = await this.resolveUserNames(operatorIds);

    const items: FollowUpItem[] = rows.map(
      (row: typeof followUp.$inferSelect) => ({
        id: row.id,
        method: row.method,
        content: row.content,
        operatorName: nameById.get(row.operator) ?? '',
        nextFollowAt: row.nextFollowAt,
        createdAt: row.createdAt.toISOString(),
      }),
    );
    return { items };
  }

  async createFollowUp(
    customerId: string,
    input: FollowUpWriteInput,
    userId: string,
  ): Promise<CreateFollowUpResponse> {
    let newId: string = '';
    await this.db.transaction(async (tx) => {
      const target: Array<{ id: string }> = await tx
        .select({ id: customer.id })
        .from(customer)
        .where(eq(customer.id, customerId))
        .limit(1);
      if (target.length === 0) {
        throw new NotFoundException('客户不存在');
      }

      const inserted: Array<{ id: string }> = await tx
        .insert(followUp)
        .values({
          customerId,
          method: input.method,
          content: input.content,
          nextFollowAt: input.nextFollowAt ?? null,
          operator: userId,
        })
        .returning({ id: followUp.id });
      newId = inserted[0].id;

      await tx
        .update(customer)
        .set({
          lastFollowedAt: new Date(),
          updatedAt: new Date(),
          updatedBy: userId,
        })
        .where(eq(customer.id, customerId));
    });
    return { id: newId };
  }

  async listQuotations(
    customerId: string,
  ): Promise<CustomerQuotationListResponse> {
    const rows: Array<{
      id: string;
      quotationNo: string;
      totalAmount: string;
      status: string;
    }> = await this.db
      .select({
        id: quotation.id,
        quotationNo: quotation.quotationNo,
        totalAmount: quotation.totalAmount,
        status: quotation.status,
      })
      .from(quotation)
      .where(eq(quotation.customerId, customerId))
      .orderBy(desc(quotation.createdAt));

    const items: CustomerQuotationItem[] = rows.map((row) => ({
      id: row.id,
      quotationNo: row.quotationNo,
      totalAmount: Number(row.totalAmount),
      status: row.status as QuotationStatus,
    }));
    return { items };
  }

  async batchAssign(
    customerIds: string[],
    ownerId: string,
    viewer: CustomerViewerContext,
  ): Promise<SuccessResponse> {
    if (!viewer.isAdmin) {
      throw new ForbiddenException('仅管理员可以分配客户负责人');
    }
    const uniqueIds: string[] = [...new Set(customerIds)];
    const existing: Array<{ id: string }> = await this.db
      .select({ id: customer.id })
      .from(customer)
      .where(inArray(customer.id, uniqueIds));
    if (existing.length !== uniqueIds.length) {
      throw new NotFoundException('部分客户不存在');
    }

    const updated: Array<{ id: string }> = await this.db
      .update(customer)
      .set({ owner: ownerId, updatedAt: new Date(), updatedBy: viewer.userId })
      .where(inArray(customer.id, uniqueIds))
      .returning({ id: customer.id });
    if (updated.length === 0) {
      throw new NotFoundException('部分客户不存在');
    }
    return { success: true };
  }

  async transfer(
    id: string,
    input: TransferCustomerInput,
    viewer: CustomerViewerContext,
  ): Promise<SuccessResponse> {
    if (!viewer.isAdmin) {
      throw new ForbiddenException('仅管理员可以转移客户');
    }
    const rows: Array<{ id: string; owner: string | null }> = await this.db
      .select({ id: customer.id, owner: customer.owner })
      .from(customer)
      .where(eq(customer.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('客户不存在');
    }
    const currentOwnerId: string | null = rows[0].owner;
    if (currentOwnerId === input.ownerId) {
      throw new BadRequestException('新负责人与当前负责人相同');
    }

    const nameById: Map<string, string> = await this.resolveUserNames(
      [input.ownerId, ...(currentOwnerId !== null ? [currentOwnerId] : [])],
    );
    const fromName: string =
      currentOwnerId !== null ? nameById.get(currentOwnerId) ?? '' : '未分配';
    const toName: string = nameById.get(input.ownerId) ?? '';
    let content: string = `客户负责人由「${fromName}」转移至「${toName}」`;
    if (input.reason && input.reason.trim()) {
      content += `。转移原因：${input.reason.trim()}`;
    }

    await this.db.transaction(async (tx) => {
      await tx
        .update(customer)
        .set({
          owner: input.ownerId,
          updatedAt: new Date(),
          updatedBy: viewer.userId,
        })
        .where(eq(customer.id, id));
      await tx.insert(followUp).values({
        customerId: id,
        method: TRANSFER_METHOD,
        content,
        nextFollowAt: null,
        operator: viewer.userId,
      });
    });
    return { success: true };
  }

  async listOwnerOptions(
    viewer: CustomerViewerContext,
  ): Promise<CustomerOwnerListResponse> {
    const rows: Array<{ owner: string }> = await this.db
      .select({ owner: customer.owner })
      .from(customer)
      .where(isNotNull(customer.owner));
    const ownerIds: string[] = [
      ...new Set(
        rows
          .map((row: { owner: string | null }) => row.owner)
          .filter((owner: string | null): owner is string => owner !== null),
      ),
      viewer.userId,
    ];
    const nameById: Map<string, string> = await this.resolveUserNames(ownerIds);
    const items: CustomerOwnerOption[] = ownerIds.map((userId: string) => ({
      userId,
      name: nameById.get(userId) ?? '',
    }));
    items.sort((a: CustomerOwnerOption, b: CustomerOwnerOption) =>
      a.name.localeCompare(b.name, 'zh-CN'),
    );
    return { items };
  }

  async countUnassigned(): Promise<CustomerUnassignedCountResponse> {
    const countRows: Array<{ count: number }> = await this.db
      .select({ count: count() })
      .from(customer)
      .where(isNull(customer.owner));
    return { count: Number(countRows[0]?.count ?? '0') };
  }

  private async resolveUserNames(
    userIds: string[],
  ): Promise<Map<string, string>> {
    const uniqueIds: string[] = [...new Set(userIds)];
    const nameById: Map<string, string> = new Map<string, string>();
    if (uniqueIds.length === 0) {
      return nameById;
    }
    const users = await this.authn.listUsersByIds(uniqueIds);
    uniqueIds.forEach((uid: string, index: number) => {
      const user = users[index];
      nameById.set(uid, user?.name?.zh_cn ?? user?.name?.en_us ?? '');
    });
    return nameById;
  }
}
