import {
  BadRequestException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { and, desc, eq, gte, lte, sql } from 'drizzle-orm';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { customer, meetingMinutes } from '@server/database/schema';
import type {
  CustomerTimelineMinutesResponse,
  MeetingActionItem,
  MeetingAttendee,
  MeetingMinuteDetail,
  MeetingMinuteListItem,
  MeetingMinuteListParams,
  MeetingMinuteListResponse,
  MeetingSource,
  MeetingType,
  SaveMeetingMinuteRequest,
  SaveMeetingMinuteResponse,
} from '@shared/api.interface';

interface MinuteRow {
  id: string;
  title: string;
  meetingDate: string;
  meetingType: string;
  customerId: string | null;
  customerName: string | null;
  attendees: unknown;
  keyTopics: unknown;
  actionItems: unknown;
  decisions: string | null;
  source: string;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

interface ActionItemDb {
  content: string;
  assignee: string;
  due_date: string;
  status: string;
}

const MEETING_TYPES: MeetingType[] = [
  '客户拜访',
  '内部会议',
  '项目评审',
  '其他',
];
const MEETING_SOURCES: MeetingSource[] = [
  '手动录入',
  'AI生成',
  '飞书妙记导入',
];
const ACTION_STATUSES: string[] = ['未开始', '进行中', '已完成'];

@Injectable()
export class MeetingMinutesService {
  constructor(
    @Inject(DRIZZLE_DATABASE)
    private readonly db: PostgresJsDatabase,
  ) {}

  private validateBody(body: SaveMeetingMinuteRequest): void {
    if (!body.title || body.title.trim().length === 0) {
      throw new BadRequestException('会议标题不能为空');
    }
    if (!MEETING_TYPES.includes(body.meetingType)) {
      throw new BadRequestException('会议类型不合法');
    }
    if (!MEETING_SOURCES.includes(body.source)) {
      throw new BadRequestException('纪要来源不合法');
    }
    if (!Array.isArray(body.attendees)) {
      throw new BadRequestException('参会人必须为数组');
    }
    for (const attendee of body.attendees) {
      const item: MeetingAttendee = attendee as MeetingAttendee;
      if (!item.name || !item.role) {
        throw new BadRequestException('参会人姓名与角色不能为空');
      }
    }
    if (!Array.isArray(body.keyTopics)) {
      throw new BadRequestException('核心议题必须为数组');
    }
    if (!Array.isArray(body.actionItems)) {
      throw new BadRequestException('待办事项必须为数组');
    }
    for (const item of body.actionItems) {
      const action: MeetingActionItem = item as MeetingActionItem;
      if (!action.content) {
        throw new BadRequestException('待办事项内容不能为空');
      }
      if (!ACTION_STATUSES.includes(action.status)) {
        throw new BadRequestException('待办事项状态不合法');
      }
    }
  }

  private toItem(row: MinuteRow): MeetingMinuteDetail {
    const actionItemsDb: ActionItemDb[] = Array.isArray(row.actionItems)
      ? (row.actionItems as ActionItemDb[])
      : [];
    const actionItems: MeetingActionItem[] = actionItemsDb.map(
      (item: ActionItemDb) => ({
        content: item.content,
        assignee: item.assignee ?? '',
        dueDate: item.due_date ?? '',
        status: ACTION_STATUSES.includes(item.status)
          ? (item.status as MeetingActionItem['status'])
          : '未开始',
      }),
    );
    return {
      id: row.id,
      title: row.title,
      meetingDate: row.meetingDate,
      meetingType: row.meetingType as MeetingType,
      customerId: row.customerId,
      customerName: row.customerName,
      attendees: Array.isArray(row.attendees)
        ? (row.attendees as MeetingAttendee[])
        : [],
      keyTopics: Array.isArray(row.keyTopics)
        ? (row.keyTopics as string[])
        : [],
      actionItems,
      decisions: row.decisions ?? '',
      source: row.source as MeetingSource,
      createdBy: row.createdBy,
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  private buildInsertValues(body: SaveMeetingMinuteRequest) {
    return {
      title: body.title.trim(),
      meetingDate: body.meetingDate,
      meetingType: body.meetingType,
      customerId: body.customerId ?? null,
      attendees: sql`${JSON.stringify(body.attendees)}::jsonb`,
      keyTopics: sql`${JSON.stringify(body.keyTopics)}::jsonb`,
      actionItems: sql`${JSON.stringify(
        body.actionItems.map((item: MeetingActionItem) => ({
          content: item.content,
          assignee: item.assignee ?? '',
          due_date: item.dueDate ?? '',
          status: item.status,
        })),
      )}::jsonb`,
      decisions: body.decisions ?? '',
      source: body.source,
    };
  }

  async list(
    params: MeetingMinuteListParams,
  ): Promise<MeetingMinuteListResponse> {
    const conditions = [];
    if (params.startDate) {
      conditions.push(gte(meetingMinutes.meetingDate, params.startDate));
    }
    if (params.endDate) {
      conditions.push(lte(meetingMinutes.meetingDate, params.endDate));
    }
    if (params.meetingType) {
      conditions.push(eq(meetingMinutes.meetingType, params.meetingType));
    }
    if (params.customerId) {
      conditions.push(eq(meetingMinutes.customerId, params.customerId));
    }
    const whereClause =
      conditions.length > 0 ? and(...conditions) : undefined;

    const rows: Array<{
      id: string;
      title: string;
      meetingDate: string;
      meetingType: string;
      customerId: string | null;
      customerName: string | null;
      source: string;
      createdBy: string;
    }> = await this.db
      .select({
        id: meetingMinutes.id,
        title: meetingMinutes.title,
        meetingDate: meetingMinutes.meetingDate,
        meetingType: meetingMinutes.meetingType,
        customerId: meetingMinutes.customerId,
        customerName: customer.name,
        source: meetingMinutes.source,
        createdBy: meetingMinutes.createdBy,
      })
      .from(meetingMinutes)
      .leftJoin(customer, eq(meetingMinutes.customerId, customer.id))
      .where(whereClause)
      .orderBy(desc(meetingMinutes.meetingDate), desc(meetingMinutes.createdAt))
      .limit(params.pageSize)
      .offset((params.page - 1) * params.pageSize);

    const countRows: Array<{ count: string }> = await this.db
      .select({ count: sql<string>`count(*)` })
      .from(meetingMinutes)
      .where(whereClause);

    return {
      items: rows.map(
        (row): MeetingMinuteListItem => ({
          id: row.id,
          title: row.title,
          meetingDate: row.meetingDate,
          meetingType: row.meetingType as MeetingType,
          customerId: row.customerId,
          customerName: row.customerName,
          source: row.source as MeetingSource,
          createdBy: row.createdBy,
        }),
      ),
      total: Number(countRows[0]?.count ?? 0),
    };
  }

  async getById(id: string): Promise<MeetingMinuteDetail> {
    const rows: MinuteRow[] = await this.db
      .select({
        id: meetingMinutes.id,
        title: meetingMinutes.title,
        meetingDate: meetingMinutes.meetingDate,
        meetingType: meetingMinutes.meetingType,
        customerId: meetingMinutes.customerId,
        customerName: customer.name,
        attendees: sql`COALESCE(${meetingMinutes.attendees}, '[]'::jsonb)`,
        keyTopics: sql`COALESCE(${meetingMinutes.keyTopics}, '[]'::jsonb)`,
        actionItems: sql`COALESCE(${meetingMinutes.actionItems}, '[]'::jsonb)`,
        decisions: meetingMinutes.decisions,
        source: meetingMinutes.source,
        createdBy: meetingMinutes.createdBy,
        createdAt: meetingMinutes.createdAt,
        updatedAt: meetingMinutes.updatedAt,
      })
      .from(meetingMinutes)
      .leftJoin(customer, eq(meetingMinutes.customerId, customer.id))
      .where(eq(meetingMinutes.id, id));
    if (rows.length === 0) {
      throw new NotFoundException('会议纪要不存在');
    }
    return this.toItem(rows[0]);
  }

  async create(
    userName: string,
    body: SaveMeetingMinuteRequest,
  ): Promise<SaveMeetingMinuteResponse> {
    this.validateBody(body);
    const inserted: Array<{ id: string }> = await this.db
      .insert(meetingMinutes)
      .values({
        ...this.buildInsertValues(body),
        createdBy: userName || '未知用户',
      })
      .returning({ id: meetingMinutes.id });
    return { id: inserted[0].id };
  }

  async update(
    id: string,
    body: SaveMeetingMinuteRequest,
  ): Promise<SaveMeetingMinuteResponse> {
    this.validateBody(body);
    const updated: Array<{ id: string }> = await this.db
      .update(meetingMinutes)
      .set({ ...this.buildInsertValues(body), updatedAt: new Date() })
      .where(eq(meetingMinutes.id, id))
      .returning({ id: meetingMinutes.id });
    if (updated.length === 0) {
      throw new NotFoundException('会议纪要不存在');
    }
    return { id };
  }

  async remove(id: string): Promise<void> {
    const deleted: Array<{ id: string }> = await this.db
      .delete(meetingMinutes)
      .where(eq(meetingMinutes.id, id))
      .returning({ id: meetingMinutes.id });
    if (deleted.length === 0) {
      throw new NotFoundException('会议纪要不存在');
    }
  }

  async listByCustomer(
    customerId: string,
  ): Promise<CustomerTimelineMinutesResponse> {
    const rows: Array<{
      id: string;
      title: string;
      meetingDate: string;
      meetingType: string;
      decisions: string | null;
    }> = await this.db
      .select({
        id: meetingMinutes.id,
        title: meetingMinutes.title,
        meetingDate: meetingMinutes.meetingDate,
        meetingType: meetingMinutes.meetingType,
        decisions: meetingMinutes.decisions,
      })
      .from(meetingMinutes)
      .where(eq(meetingMinutes.customerId, customerId))
      .orderBy(desc(meetingMinutes.meetingDate), desc(meetingMinutes.createdAt));
    return {
      items: rows.map((row) => ({
        id: row.id,
        title: row.title,
        meetingDate: row.meetingDate,
        meetingType: row.meetingType as MeetingType,
        decisions: row.decisions ?? '',
      })),
    };
  }
}
