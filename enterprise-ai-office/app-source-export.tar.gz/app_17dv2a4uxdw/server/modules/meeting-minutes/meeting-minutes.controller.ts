import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Req,
} from '@nestjs/common';
import { Can } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import type {
  CustomerTimelineMinutesResponse,
  MeetingMinuteDetail,
  MeetingMinuteListParams,
  MeetingMinuteListResponse,
  MeetingType,
  SaveMeetingMinuteRequest,
  SaveMeetingMinuteResponse,
  SuccessResponse,
} from '@shared/api.interface';
import { MeetingMinutesService } from './meeting-minutes.service';

const DATE_PATTERN: RegExp = /^\d{4}-\d{2}-\d{2}$/;

@Controller('api/meeting-minutes')
export class MeetingMinutesController {
  constructor(private readonly meetingMinutesService: MeetingMinutesService) {}

  @Can('read', 'MeetingMinutes')
  @Get()
  async list(
    @Query('page') page: string = '1',
    @Query('pageSize') pageSize: string = '10',
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('meetingType') meetingType?: MeetingType,
    @Query('customerId') customerId?: string,
  ): Promise<MeetingMinuteListResponse> {
    const pageNum: number = Math.max(1, parseInt(page, 10) || 1);
    const size: number = Math.min(50, Math.max(1, parseInt(pageSize, 10) || 10));
    if (startDate && !DATE_PATTERN.test(startDate)) {
      throw new BadRequestException('开始日期格式必须为 YYYY-MM-DD');
    }
    if (endDate && !DATE_PATTERN.test(endDate)) {
      throw new BadRequestException('结束日期格式必须为 YYYY-MM-DD');
    }
    const params: MeetingMinuteListParams = {
      page: pageNum,
      pageSize: size,
      ...(startDate ? { startDate } : {}),
      ...(endDate ? { endDate } : {}),
      ...(meetingType ? { meetingType } : {}),
      ...(customerId ? { customerId } : {}),
    };
    return this.meetingMinutesService.list(params);
  }

  @Can('read', 'MeetingMinutes')
  @Get('customer/:customerId')
  async listByCustomer(
    @Param('customerId') customerId: string,
  ): Promise<CustomerTimelineMinutesResponse> {
    return this.meetingMinutesService.listByCustomer(customerId);
  }

  @Can('read', 'MeetingMinutes')
  @Get(':id')
  async getById(@Param('id') id: string): Promise<MeetingMinuteDetail> {
    return this.meetingMinutesService.getById(id);
  }

  @Can('operate', 'MeetingMinutes')
  @Post()
  async create(
    @Req() req: Request,
    @Body() body: SaveMeetingMinuteRequest,
  ): Promise<SaveMeetingMinuteResponse> {
    return this.meetingMinutesService.create(
      req.userContext.userName,
      body,
    );
  }

  @Can('operate', 'MeetingMinutes')
  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() body: SaveMeetingMinuteRequest,
  ): Promise<SaveMeetingMinuteResponse> {
    return this.meetingMinutesService.update(id, body);
  }

  @Can('operate', 'MeetingMinutes')
  @Delete(':id')
  async remove(@Param('id') id: string): Promise<SuccessResponse> {
    await this.meetingMinutesService.remove(id);
    return { success: true };
  }
}
