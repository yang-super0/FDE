export const ALERT_RULES = {
  nearingDueDays: 7,
  nearingDueProgressThreshold: 80,
  customerNoFollowDays: 15,
  quotationHighRatio: 1.5,
  quotationLowRatio: 0.5,
} as const;

export const ALERT_TYPE_ORDER = [
  'project_delay',
  'report_missing',
  'customer_no_follow',
  'quotation_anomaly',
] as const;
