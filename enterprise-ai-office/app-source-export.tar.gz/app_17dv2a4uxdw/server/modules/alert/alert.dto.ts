import { IsIn, IsOptional, IsString } from 'class-validator';

const ALERT_TYPES = [
  'project_delay',
  'report_missing',
  'customer_no_follow',
  'quotation_anomaly',
] as const;

export class AlertListQueryDto {
  @IsOptional()
  @IsString()
  @IsIn(ALERT_TYPES)
  type?: string;
}

export class AlertDismissDto {
  @IsString()
  @IsIn(ALERT_TYPES)
  type: string;

  @IsString()
  targetId: string;
}
