import { Logger } from '@nestjs/common';
import { Automation, BindTrigger } from '@lark-apaas/fullstack-nestjs-core';
import { AlertPushService } from './alert-push.service';

@Automation()
export class AlertAutomationTasksService {
  private readonly logger = new Logger(AlertAutomationTasksService.name);

  constructor(private readonly alertPushService: AlertPushService) {}

  @BindTrigger('daily_alert_summary_push')
  async pushDailyAlertSummary(): Promise<void> {
    this.logger.log('开始执行每日异常预警摘要推送');
    const result = await this.alertPushService.pushAlertSummary();
    this.logger.log(`每日异常预警摘要推送结束: ${JSON.stringify(result)}`);
  }
}
