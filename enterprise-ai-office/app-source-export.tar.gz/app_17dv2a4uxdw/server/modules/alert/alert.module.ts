import { Module } from '@nestjs/common';
import { AlertController } from './alert.controller';
import { AlertService } from './alert.service';
import { AlertPushService } from './alert-push.service';
import { AlertAutomationTasksService } from './alert.automation';

@Module({
  controllers: [AlertController],
  providers: [
    AlertService,
    AlertPushService,
    AlertAutomationTasksService,
  ],
})
export class AlertModule {}
