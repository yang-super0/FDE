import { Inject, Injectable, Logger } from '@nestjs/common';
import {
  AuthorizationSDK,
  CapabilityService,
  type UserSimpleDTO,
} from '@lark-apaas/fullstack-nestjs-core';
import { ROLE_KEYS } from '@shared/permissions';
import type {
  AbnormalAlertDailySummaryPushOneInput,
  AbnormalAlertDailySummaryPushOneOutput,
} from '@shared/plugin-types';
import type {
  AlertGroup,
  AlertItem,
  AlertListResponse,
  AlertType,
} from '@shared/api.interface';
import { AlertService } from './alert.service';

const PUSH_PLUGIN_INSTANCE_ID: string = 'abnormal_alert_daily_summary_push_1';
const MAX_ITEMS_PER_GROUP: number = 5;

const isPushOutput = (
  value: unknown,
): value is AbnormalAlertDailySummaryPushOneOutput => {
  if (typeof value !== 'object' || value === null) {
    return false;
  }
  return typeof (value as { success?: unknown }).success === 'boolean';
};

const ALERT_TYPE_LABEL: Record<AlertType, string> = {
  project_delay: '项目延期',
  report_missing: '日报未提交',
  customer_no_follow: '客户未跟进',
  quotation_anomaly: '报价异常',
};

export interface AlertPushResult {
  success: boolean;
  skipped: boolean;
  reason: string;
}

@Injectable()
export class AlertPushService {
  private readonly logger = new Logger(AlertPushService.name);

  constructor(
    private readonly alertService: AlertService,
    private readonly authorizationSDK: AuthorizationSDK,
    @Inject(CapabilityService)
    private readonly capabilityService: CapabilityService,
  ) {}

  async pushAlertSummary(): Promise<AlertPushResult> {
    const receivers: string[] = await this.getAdminUserIds();
    if (receivers.length === 0) {
      this.logger.log('未找到管理员成员，跳过推送');
      return { success: false, skipped: true, reason: '未找到管理员成员' };
    }

    const response: AlertListResponse = await this.alertService.listAlerts();
    if (response.total === 0) {
      this.logger.log('当前无待处理预警，跳过推送');
      return { success: true, skipped: true, reason: '当前无待处理预警' };
    }

    const content: string = this.buildSummaryText(
      response.groups,
      response.total,
    );
    const input: AbnormalAlertDailySummaryPushOneInput = {
      content,
      receiverUserList: receivers,
    };

    try {
      const raw: unknown = await this.capabilityService
        .load(PUSH_PLUGIN_INSTANCE_ID)
        .call('send_feishu_message', input);
      if (!isPushOutput(raw)) {
        this.logger.error(
          `预警摘要推送返回结构异常: ${JSON.stringify(raw)}`,
        );
        return {
          success: false,
          skipped: false,
          reason: '推送返回结构异常',
        };
      }
      if (raw.success) {
        this.logger.log(`预警摘要推送成功，接收人 ${receivers.length} 位`);
        return { success: true, skipped: false, reason: '' };
      }
      this.logger.error(
        `预警摘要推送失败: ${JSON.stringify(raw)}`,
      );
      return {
        success: false,
        skipped: false,
        reason: '飞书消息发送失败',
      };
    } catch (err) {
      this.logger.error(`预警摘要推送异常: ${String(err)}`);
      return { success: false, skipped: false, reason: String(err) };
    }
  }

  private async getAdminUserIds(): Promise<string[]> {
    const res = await this.authorizationSDK.members.list(ROLE_KEYS.admin);
    const members: UserSimpleDTO[] = res.members.userList ?? [];
    return members
      .map((member: UserSimpleDTO): string => member.userID)
      .filter((userId: string): boolean => Boolean(userId));
  }

  private buildSummaryText(groups: AlertGroup[], total: number): string {
    const today: string = new Date(
      Date.now() + 8 * 3600 * 1000,
    ).toISOString().slice(0, 10);
    const lines: string[] = [
      `**异常预警日报（${today}）**`,
      `当前共有 ${total} 项异常待处理：`,
    ];
    for (const group of groups) {
      if (group.items.length === 0) {
        continue;
      }
      lines.push('', `**${ALERT_TYPE_LABEL[group.type]}（${group.count} 项）**`);
      for (const item of group.items.slice(0, MAX_ITEMS_PER_GROUP)) {
        lines.push(`- ${item.title}：${item.detail}`);
      }
      if (group.items.length > MAX_ITEMS_PER_GROUP) {
        lines.push(`- …… 另有 ${group.items.length - MAX_ITEMS_PER_GROUP} 项`);
      }
    }
    lines.push('', '请前往 CRM 工作台「异常预警」模块查看详情并处理。');
    return lines.join('\n');
  }
}
