import { Inject, Injectable } from '@nestjs/common';
import { and, eq, isNull, lt, ne, or, sql } from 'drizzle-orm';
import {
  AuthNPaasService,
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import {
  alertDismiss,
  customer,
  dailyReport,
  project,
  quotation,
} from '@server/database/schema';
import type {
  AlertGroup,
  AlertItem,
  AlertListResponse,
  AlertType,
} from '@shared/api.interface';
import { ALERT_RULES, ALERT_TYPE_ORDER } from './alert-rules';

const MS_PER_DAY = 86400000;
const SHANGHAI_OFFSET_MS = 8 * 3600 * 1000;

interface DismissRow {
  alertType: string;
  targetId: string;
}

@Injectable()
export class AlertService {
  constructor(
    @Inject(DRIZZLE_DATABASE)
    private readonly db: PostgresJsDatabase,
    private readonly authnPaasService: AuthNPaasService,
  ) {}

  async listAlerts(type?: AlertType): Promise<AlertListResponse> {
    const dismissedKeys: Set<string> = await this.loadDismissedKeys();
    const items: AlertItem[] = [];
    if (!type || type === 'project_delay') {
      items.push(...(await this.collectProjectDelayAlerts()));
    }
    if (!type || type === 'report_missing') {
      items.push(...(await this.collectReportMissingAlerts()));
    }
    if (!type || type === 'customer_no_follow') {
      items.push(...(await this.collectCustomerNoFollowAlerts()));
    }
    if (!type || type === 'quotation_anomaly') {
      items.push(...(await this.collectQuotationAnomalyAlerts()));
    }

    const visible: AlertItem[] = items.filter(
      (item: AlertItem) =>
        !dismissedKeys.has(`${item.type}:${item.targetId}`),
    );
    const byType: Map<AlertType, AlertItem[]> = new Map();
    for (const item of visible) {
      byType.set(item.type, [...(byType.get(item.type) ?? []), item]);
    }

    const groups: AlertGroup[] = ALERT_TYPE_ORDER
      .map((alertType: AlertType): AlertGroup => {
        const groupItems: AlertItem[] = byType.get(alertType) ?? [];
        return { type: alertType, count: groupItems.length, items: groupItems };
      })
      .filter((group: AlertGroup) => type === undefined || group.type === type);

    const total: number = groups.reduce(
      (sum: number, group: AlertGroup) => sum + group.count,
      0,
    );
    return { groups, total };
  }

  async dismiss(type: AlertType, targetId: string, userId: string): Promise<void> {
    await this.db
      .insert(alertDismiss)
      .values({ alertType: type, targetId, dismissedBy: userId })
      .onConflictDoNothing({
        target: [alertDismiss.alertType, alertDismiss.targetId],
      });
  }

  async markAllRead(userId: string): Promise<number> {
    const response: AlertListResponse = await this.listAlerts();
    let dismissedCount = 0;
    for (const group of response.groups) {
      for (const item of group.items) {
        const inserted = await this.db
          .insert(alertDismiss)
          .values({
            alertType: item.type,
            targetId: item.targetId,
            dismissedBy: userId,
          })
          .onConflictDoNothing({
            target: [alertDismiss.alertType, alertDismiss.targetId],
          })
          .returning({ id: alertDismiss.id });
        if (inserted.length > 0) {
          dismissedCount += 1;
        }
      }
    }
    return dismissedCount;
  }

  private async loadDismissedKeys(): Promise<Set<string>> {
    const rows: DismissRow[] = await this.db
      .select({
        alertType: alertDismiss.alertType,
        targetId: alertDismiss.targetId,
      })
      .from(alertDismiss);
    return new Set(
      rows.map((row: DismissRow) => `${row.alertType}:${row.targetId}`),
    );
  }

  private todayShanghai(offsetDays = 0): string {
    const shifted: Date = new Date(
      Date.now() + offsetDays * MS_PER_DAY + SHANGHAI_OFFSET_MS,
    );
    return shifted.toISOString().slice(0, 10);
  }

  private async collectProjectDelayAlerts(): Promise<AlertItem[]> {
    const today: string = this.todayShanghai();
    const dueSoonLimit: string = this.todayShanghai(
      ALERT_RULES.nearingDueDays,
    );
    const rows: Array<{
      id: string;
      name: string;
      endDate: string;
      progress: number;
    }> = await this.db
      .select({
        id: project.id,
        name: project.name,
        endDate: project.endDate,
        progress: project.progress,
      })
      .from(project)
      .where(
        and(
          ne(project.status, 'completed'),
          sql`${project.endDate} <= ${dueSoonLimit}`,
        ),
      );

    return rows.map((row): AlertItem => {
      const overdue: boolean = row.endDate < today;
      const daysLeft: number = Math.round(
        (new Date(row.endDate).getTime() - new Date(today).getTime()) /
          MS_PER_DAY,
      );
      const detail: string = overdue
        ? `已于 ${row.endDate} 到期，进度仅 ${row.progress}%，已延期`
        : `计划 ${row.endDate} 结束（剩 ${daysLeft} 天），进度仅 ${row.progress}%`;
      return {
        type: 'project_delay',
        level: overdue ? 'danger' : 'warning',
        targetId: row.id,
        objectId: row.id,
        title: row.name,
        detail,
        occurredAt: row.endDate,
      };
    });
  }

  private async collectReportMissingAlerts(): Promise<AlertItem[]> {
    const today: string = this.todayShanghai();
    const authorRows: Array<{ userId: string }> = await this.db
      .selectDistinct({
        userId: sql<string>`(${dailyReport.author}).user_id`,
      })
      .from(dailyReport);
    const memberIds: string[] = authorRows.map(
      (row: { userId: string }): string => row.userId,
    );
    if (memberIds.length === 0) {
      return [];
    }

    const submittedRows: Array<{ userId: string }> = await this.db
      .selectDistinct({
        userId: sql<string>`(${dailyReport.author}).user_id`,
      })
      .from(dailyReport)
      .where(eq(dailyReport.reportDate, today));
    const submittedSet: Set<string> = new Set(
      submittedRows.map((row: { userId: string }): string => row.userId),
    );

    const missingIds: string[] = memberIds.filter(
      (memberId: string) => !submittedSet.has(memberId),
    );
    if (missingIds.length === 0) {
      return [];
    }

    const users = await this.authnPaasService.listUsersByIds(missingIds);
    return missingIds.map((memberId: string, index: number): AlertItem => {
      const user = users[index];
      const userName: string =
        user?.name?.zh_cn ?? user?.name?.en_us ?? memberId;
      return {
        type: 'report_missing',
        level: 'warning',
        targetId: `${memberId}_${today}`,
        objectId: memberId,
        title: userName,
        detail: `今日（${today}）日报尚未提交`,
        occurredAt: today,
      };
    });
  }

  private async collectCustomerNoFollowAlerts(): Promise<AlertItem[]> {
    const threshold: Date = new Date(
      Date.now() - ALERT_RULES.customerNoFollowDays * MS_PER_DAY,
    );
    const rows: Array<{
      id: string;
      name: string;
      lastFollowedAt: Date | null;
    }> = await this.db
      .select({
        id: customer.id,
        name: customer.name,
        lastFollowedAt: customer.lastFollowedAt,
      })
      .from(customer)
      .where(
        or(
          isNull(customer.lastFollowedAt),
          lt(customer.lastFollowedAt, threshold),
        ),
      );

    return rows.map((row): AlertItem => {
      const daysIdle: number =
        row.lastFollowedAt === null
          ? ALERT_RULES.customerNoFollowDays
          : Math.floor(
              (Date.now() - row.lastFollowedAt.getTime()) / MS_PER_DAY,
            );
      const detail: string =
        row.lastFollowedAt === null
          ? '创建后无任何跟进记录'
          : `已 ${daysIdle} 天无跟进记录（上次跟进 ${row.lastFollowedAt.toISOString().slice(0, 10)}）`;
      return {
        type: 'customer_no_follow',
        level: 'warning',
        targetId: row.id,
        objectId: row.id,
        title: row.name,
        detail,
        occurredAt:
          row.lastFollowedAt?.toISOString() ?? new Date().toISOString(),
      };
    });
  }

  private async collectQuotationAnomalyAlerts(): Promise<AlertItem[]> {
    const rows: Array<{
      id: string;
      quotationNo: string;
      totalAmount: string;
      productId: string | null;
    }> = await this.db
      .select({
        id: quotation.id,
        quotationNo: quotation.quotationNo,
        totalAmount: quotation.totalAmount,
        productId: quotation.productId,
      })
      .from(quotation);

    const sums: Map<string, { total: number; count: number }> = new Map();
    for (const row of rows) {
      if (row.productId === null) continue;
      const amount: number = parseFloat(row.totalAmount);
      if (!Number.isFinite(amount)) continue;
      const current = sums.get(row.productId) ?? { total: 0, count: 0 };
      sums.set(row.productId, {
        total: current.total + amount,
        count: current.count + 1,
      });
    }

    const alerts: AlertItem[] = [];
    for (const row of rows) {
      if (row.productId === null) continue;
      const stat = sums.get(row.productId);
      if (!stat || stat.count < 2) continue;
      const avg: number = stat.total / stat.count;
      if (avg <= 0) continue;
      const amount: number = parseFloat(row.totalAmount);
      const ratio: number = amount / avg;
      if (
        ratio <= ALERT_RULES.quotationLowRatio ||
        ratio >= ALERT_RULES.quotationHighRatio
      ) {
        const direction: string =
          ratio >= ALERT_RULES.quotationHighRatio
            ? `exceeds the same-product average by ${Math.round(ratio * 100)}%`
            : `only ${Math.round(ratio * 100)}% of the same-product average`;
        alerts.push({
          type: 'quotation_anomaly',
          level: 'danger',
          targetId: row.id,
          objectId: row.id,
          title: `Quotation ${row.quotationNo}`,
          detail: `Amount ¥${Math.round(amount)}, same-product average ¥${Math.round(avg)}, ${direction}`,
          occurredAt: new Date().toISOString(),
        });
      }
    }
    return alerts;
  }
}
