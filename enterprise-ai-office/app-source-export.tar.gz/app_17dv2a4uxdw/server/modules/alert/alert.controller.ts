import { Body, Controller, Get, Post, Query, Req } from '@nestjs/common';
import {
  AuthorizationSDK,
  type UserSimpleDTO,
} from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import type {
  AlertDismissRequest,
  AlertListResponse,
  AlertMarkAllReadResponse,
  AlertPushNowResponse,
  AlertSuccessResponse,
  AlertType,
} from '@shared/api.interface';
import { ROLE_KEYS } from '@shared/permissions';
import { AlertService } from './alert.service';
import { AlertPushService, type AlertPushResult } from './alert-push.service';
import { AlertDismissDto, AlertListQueryDto } from './alert.dto';

@Controller('api/alerts')
export class AlertController {
  constructor(
    private readonly alertService: AlertService,
    private readonly alertPushService: AlertPushService,
    private readonly authorizationSDK: AuthorizationSDK,
  ) {}

  @Get()
  async list(
    @Req() req: Request,
    @Query() query: AlertListQueryDto,
  ): Promise<AlertListResponse> {
    if (!(await this.isAdmin(req))) {
      return { groups: [], total: 0 };
    }
    return this.alertService.listAlerts(query.type as AlertType | undefined);
  }

  @Post('dismiss')
  async dismiss(
    @Req() req: Request,
    @Body() dto: AlertDismissDto,
  ): Promise<AlertSuccessResponse> {
    await this.alertService.dismiss(
      dto.type as AlertType,
      dto.targetId,
      req.userContext.userId,
    );
    return { success: true };
  }

  @Post('mark-all-read')
  async markAllRead(@Req() req: Request): Promise<AlertMarkAllReadResponse> {
    const dismissed: number = await this.alertService.markAllRead(
      req.userContext.userId,
    );
    return { dismissed };
  }

  @Post('push-now')
  async pushNow(): Promise<AlertPushNowResponse> {
    const result: AlertPushResult =
      await this.alertPushService.pushAlertSummary();
    if (result.success && !result.skipped) {
      return { success: true, message: '预警摘要已推送给管理员' };
    }
    if (result.success && result.skipped) {
      return { success: true, message: `未推送：${result.reason}` };
    }
    return { success: false, message: result.reason || '推送失败' };
  }

  private async isAdmin(req: Request): Promise<boolean> {
    const injectedRoles: string[] | null = req.userContext.roles ?? null;
    if (injectedRoles !== null) {
      return injectedRoles.includes(ROLE_KEYS.admin);
    }
    const userId: string | undefined = req.userContext?.userId;
    if (!userId) {
      return false;
    }
    const res = await this.authorizationSDK.members.list(ROLE_KEYS.admin, {
      userID: userId,
    });
    const members: UserSimpleDTO[] = res.members.userList ?? [];
    return members.some(
      (member: UserSimpleDTO) => member.userID === userId,
    );
  }
}
