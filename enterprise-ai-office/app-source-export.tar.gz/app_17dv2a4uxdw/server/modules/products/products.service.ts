import { Injectable, NotFoundException } from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { and, asc, eq, isNotNull } from 'drizzle-orm';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { customItems, pricingRules, products } from '@server/database/schema';
import type {
  ProductCustomOption,
  ProductCustomOptionsResponse,
  ProductListResponse,
  ProductOption,
  ProjectScene,
  SceneConditionalPrice,
} from '@shared/api.interface';
import {
  scenesMatchingConditions,
  type RuleConditions,
} from '@server/common/utils/scene-rules';

interface CustomOptionRuleRow {
  customItemId: string | null;
  priceAdjustment: string;
  priority: number;
  ruleType: string;
  conditions: RuleConditions | null;
  description: string | null;
  itemName: string;
  unit: string | null;
}

interface CustomOptionAggregate {
  itemName: string;
  unit: string | null;
  baseRule: CustomOptionRuleRow | null;
  conditionalScenes: SceneConditionalPrice[];
}

@Injectable()
export class ProductsService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async listActive(): Promise<ProductListResponse> {
    const rows: Array<typeof products.$inferSelect> = await this.db
      .select()
      .from(products)
      .where(eq(products.status, 'active'))
      .orderBy(asc(products.productCode));

    const items: ProductOption[] = rows.map(
      (row: typeof products.$inferSelect) => ({
        id: row.id,
        productCode: row.productCode,
        name: row.name,
        category: row.category ?? '',
        basePrice: Number(row.basePrice),
      }),
    );
    return { items };
  }

  async customOptions(productId: string): Promise<ProductCustomOptionsResponse> {
    const productRows: Array<{
      id: string;
      name: string;
      basePrice: string;
    }> = await this.db
      .select({
        id: products.id,
        name: products.name,
        basePrice: products.basePrice,
      })
      .from(products)
      .where(eq(products.id, productId))
      .limit(1);
    if (productRows.length === 0) {
      throw new NotFoundException('产品不存在');
    }
    const product: { id: string; name: string; basePrice: string } =
      productRows[0];

    const rawRows: Array<{
      customItemId: string | null;
      priceAdjustment: string;
      priority: number;
      ruleType: string;
      conditions: unknown;
      description: string | null;
      itemName: string;
      unit: string | null;
    }> = await this.db
      .select({
        customItemId: pricingRules.customItemId,
        priceAdjustment: pricingRules.priceAdjustment,
        priority: pricingRules.priority,
        ruleType: pricingRules.ruleType,
        conditions: pricingRules.conditions,
        description: pricingRules.description,
        itemName: customItems.name,
        unit: customItems.unit,
      })
      .from(pricingRules)
      .innerJoin(customItems, eq(pricingRules.customItemId, customItems.id))
      .where(
        and(
          eq(pricingRules.productId, productId),
          isNotNull(pricingRules.customItemId),
          eq(pricingRules.status, 'active'),
          eq(customItems.status, 'active'),
        ),
      );

    const ruleRows: CustomOptionRuleRow[] = rawRows.map(
      (row): CustomOptionRuleRow => ({
        ...row,
        conditions:
          row.conditions && typeof row.conditions === 'object'
            ? (row.conditions as RuleConditions)
            : null,
      }),
    );

    const byItem: Map<string, CustomOptionAggregate> = new Map();
    for (const rule of ruleRows) {
      if (!rule.customItemId) {
        continue;
      }
      let aggregate: CustomOptionAggregate | undefined = byItem.get(
        rule.customItemId,
      );
      if (!aggregate) {
        aggregate = {
          itemName: rule.itemName,
          unit: rule.unit,
          baseRule: null,
          conditionalScenes: [],
        };
        byItem.set(rule.customItemId, aggregate);
      }
      if (rule.ruleType === 'conditional') {
        const scenes: ProjectScene[] = scenesMatchingConditions(
          rule.conditions,
        );
        for (const scene of scenes) {
          aggregate.conditionalScenes.push({
            scene,
            priceAdjustment: Number(rule.priceAdjustment),
          });
        }
      } else if (
        !aggregate.baseRule ||
        rule.priority > aggregate.baseRule.priority
      ) {
        aggregate.baseRule = rule;
      }
    }

    const items: ProductCustomOption[] = [];
    byItem.forEach(
      (aggregate: CustomOptionAggregate, customItemId: string) => {
        const base: CustomOptionRuleRow | null =
          aggregate.baseRule ??
          (aggregate.conditionalScenes.length > 0
            ? ruleRows.find(
                (rule: CustomOptionRuleRow) =>
                  rule.customItemId === customItemId,
              ) ?? null
            : null);
        if (!base) {
          return;
        }
        items.push({
          customItemId,
          itemName: aggregate.itemName,
          priceAdjustment: Number(base.priceAdjustment),
          ruleType: base.ruleType,
          description: base.description ?? '',
          unit: aggregate.unit,
          conditionalScenes: aggregate.conditionalScenes,
        });
      },
    );

    return {
      productId: product.id,
      productName: product.name,
      basePrice: Number(product.basePrice),
      items,
    };
  }
}
