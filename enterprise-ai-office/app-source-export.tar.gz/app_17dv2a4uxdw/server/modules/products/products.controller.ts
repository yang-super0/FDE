import { Controller, Get, Param } from '@nestjs/common';
import type {
  ProductCustomOptionsResponse,
  ProductListResponse,
} from '@shared/api.interface';
import { ProductsService } from './products.service';

@Controller('api/products')
export class ProductsController {
  constructor(private readonly productsService: ProductsService) {}

  @Get()
  list(): Promise<ProductListResponse> {
    return this.productsService.listActive();
  }

  @Get(':id/custom-options')
  customOptions(
    @Param('id') id: string,
  ): Promise<ProductCustomOptionsResponse> {
    return this.productsService.customOptions(id);
  }
}
