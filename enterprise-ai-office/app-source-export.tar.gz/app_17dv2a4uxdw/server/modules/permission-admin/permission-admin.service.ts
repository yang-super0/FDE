import {
  BadRequestException,
  ConflictException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import {
  AuthNPaasService,
  AuthorizationSDK,
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { eq, inArray } from 'drizzle-orm';
import type {
  MemberListResponse,
  MemberRoleInfo,
  PermissionPointInfo,
  RoleInfo,
  RoleListResponse,
} from '@shared/api.interface';
import {
  authzPermissions,
  authzRolePermissions,
} from '@server/database/schema';

const BUILTIN_ROLE_BIZ_ID: string = 'admin';
const MEMBER_PAGE_SIZE: number = 50;
const MAX_MEMBER_PAGES: number = 20;

interface SdkRole {
  bizID?: string;
  name?: string;
  description?: string;
}

interface SdkUserMember {
  userID?: string;
  name?: { zh_cn?: string; en_us?: string };
  department?: { name?: { zh_cn?: string; en_us?: string } };
}

interface RoleMemberAggregation {
  roleIds: string[];
  roleNames: string[];
  departmentName: string | null;
}

@Injectable()
export class PermissionAdminService {
  private readonly logger: Logger = new Logger(PermissionAdminService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
    private readonly authzSDK: AuthorizationSDK,
    private readonly authnPaasService: AuthNPaasService,
  ) {}

  async listRoles(): Promise<RoleListResponse> {
    const sdkRoles: SdkRole[] = await this.fetchSdkRoles();
    const bizIds: string[] = sdkRoles.map(
      (role: SdkRole) => role.bizID ?? '',
    );
    const permissionMap: Map<string, string[]> =
      await this.fetchRolePermissionMap(bizIds);
    const items: RoleInfo[] = [];
    for (const role of sdkRoles) {
      const bizId: string = role.bizID ?? '';
      if (!bizId) {
        continue;
      }
      const memberCount: number = await this.fetchMemberCount(bizId);
      items.push({
        id: bizId,
        name: role.name ?? bizId,
        bizId,
        isBuiltin: bizId === BUILTIN_ROLE_BIZ_ID,
        permissions: permissionMap.get(bizId) ?? [],
        memberCount,
      });
    }
    items.sort((a: RoleInfo, b: RoleInfo) => {
      if (a.isBuiltin !== b.isBuiltin) {
        return a.isBuiltin ? -1 : 1;
      }
      return a.bizId.localeCompare(b.bizId);
    });
    return { items };
  }

  async createRole(
    name: string,
    permissionKeys: string[],
    creatorUserId: string,
  ): Promise<{ id: string }> {
    const bizId: string = `role_${Date.now()}`;
    await this.authzSDK.roles.create({
      role: { bizID: bizId, name },
    });
    await this.replaceRolePermissions(bizId, permissionKeys, creatorUserId);
    this.logger.log(`角色创建成功: ${bizId} (${name})`);
    return { id: bizId };
  }

  async updateRole(
    bizId: string,
    name: string | undefined,
    permissionKeys: string[] | undefined,
    operatorUserId: string,
  ): Promise<void> {
    await this.ensureRoleExists(bizId);
    if (name !== undefined) {
      await this.authzSDK.roles.update(bizId, { role: { name } });
    }
    if (permissionKeys !== undefined) {
      await this.replaceRolePermissions(
        bizId,
        permissionKeys,
        operatorUserId,
      );
    }
    this.logger.log(`角色更新成功: ${bizId}`);
  }

  async deleteRole(bizId: string): Promise<void> {
    if (bizId === BUILTIN_ROLE_BIZ_ID) {
      throw new BadRequestException('内置管理员角色不可删除');
    }
    await this.ensureRoleExists(bizId);
    const memberCount: number = await this.fetchMemberCount(bizId);
    if (memberCount > 0) {
      throw new ConflictException('该角色仍有成员，请先移除成员');
    }
    await this.authzSDK.roles.delete(bizId);
    await this.db
      .delete(authzRolePermissions)
      .where(eq(authzRolePermissions.roleKey, bizId));
    this.logger.log(`角色删除成功: ${bizId}`);
  }

  async listPermissionPoints(): Promise<PermissionPointInfo[]> {
    const rows: Array<{
      id: string;
      action: string;
      subject: string;
      description: string | null;
    }> = await this.db
      .select({
        id: authzPermissions.id,
        action: authzPermissions.action,
        subject: authzPermissions.subject,
        description: authzPermissions.description,
      })
      .from(authzPermissions);
    return rows.map(
      (row: {
        id: string;
        action: string;
        subject: string;
        description: string | null;
      }): PermissionPointInfo => ({
        id: row.id,
        action: row.action,
        subject: row.subject,
        description: row.description ?? '',
      }),
    );
  }

  async listMembers(): Promise<MemberListResponse> {
    const sdkRoles: SdkRole[] = await this.fetchSdkRoles();
    const aggregation: Map<string, RoleMemberAggregation> = new Map();
    for (const role of sdkRoles) {
      const bizId: string = role.bizID ?? '';
      if (!bizId || bizId === BUILTIN_ROLE_BIZ_ID) {
        continue;
      }
      const roleName: string = role.name ?? bizId;
      const members: SdkUserMember[] =
        await this.fetchRoleUserMembers(bizId);
      for (const member of members) {
        const userId: string = member.userID ?? '';
        if (!userId) {
          continue;
        }
        const existing: RoleMemberAggregation = aggregation.get(userId) ?? {
          roleIds: [],
          roleNames: [],
          departmentName: null,
        };
        existing.roleIds.push(bizId);
        existing.roleNames.push(roleName);
        if (!existing.departmentName) {
          existing.departmentName =
            member.department?.name?.zh_cn ??
            member.department?.name?.en_us ??
            null;
        }
        aggregation.set(userId, existing);
      }
    }
    const userIds: string[] = Array.from(aggregation.keys());
    const userInfos =
      userIds.length > 0
        ? await this.authnPaasService.listUsersByIds(userIds)
        : [];
    const items: MemberRoleInfo[] = userIds.map(
      (userId: string, index: number): MemberRoleInfo => {
        const info = userInfos[index];
        const agg: RoleMemberAggregation =
          aggregation.get(userId) ?? {
            roleIds: [],
            roleNames: [],
            departmentName: null,
          };
        return {
          userId,
          name: info?.name?.zh_cn ?? info?.name?.en_us ?? '未知用户',
          avatar: info?.avatar?.image?.large ?? '',
          departmentName: agg.departmentName,
          roleIds: agg.roleIds,
          roleNames: agg.roleNames,
        };
      },
    );
    items.sort((a: MemberRoleInfo, b: MemberRoleInfo) =>
      a.name.localeCompare(b.name, 'zh-CN'),
    );
    return { items };
  }

  async assignMemberRoles(
    userId: string,
    roleIds: string[],
  ): Promise<void> {
    const sdkRoles: SdkRole[] = await this.fetchSdkRoles();
    const validBizIds: Set<string> = new Set(
      sdkRoles
        .map((role: SdkRole) => role.bizID ?? '')
        .filter((bizId: string) => bizId.length > 0),
    );
    const targetSet: Set<string> = new Set();
    for (const roleId of roleIds) {
      if (!validBizIds.has(roleId)) {
        throw new BadRequestException(`角色不存在: ${roleId}`);
      }
      targetSet.add(roleId);
    }
    for (const role of sdkRoles) {
      const bizId: string = role.bizID ?? '';
      if (!bizId || bizId === BUILTIN_ROLE_BIZ_ID) {
        continue;
      }
      const isMember: boolean = await this.isRoleMember(bizId, userId);
      const shouldHave: boolean = targetSet.has(bizId);
      if (isMember && !shouldHave) {
        await this.authzSDK.members.remove(bizId, {
          members: { userList: [{ userID: userId }] },
        });
      } else if (!isMember && shouldHave) {
        await this.authzSDK.members.add(bizId, {
          members: { userList: [{ userID: userId }] },
        });
      }
    }
    this.logger.log(
      `成员角色分配完成: ${JSON.stringify({ userId, roleIds })}`,
    );
  }

  private async fetchSdkRoles(): Promise<SdkRole[]> {
    const roles = await this.authzSDK.roles.list();
    return (roles ?? []) as SdkRole[];
  }

  private async ensureRoleExists(bizId: string): Promise<void> {
    const roles: SdkRole[] = await this.fetchSdkRoles();
    const found: boolean = roles.some(
      (role: SdkRole) => role.bizID === bizId,
    );
    if (!found) {
      throw new NotFoundException('角色不存在');
    }
  }

  private async fetchRolePermissionMap(
    bizIds: string[],
  ): Promise<Map<string, string[]>> {
    const map: Map<string, string[]> = new Map();
    if (bizIds.length === 0) {
      return map;
    }
    const rows: Array<{
      roleKey: string;
      action: string;
      subject: string;
    }> = await this.db
      .select({
        roleKey: authzRolePermissions.roleKey,
        action: authzPermissions.action,
        subject: authzPermissions.subject,
      })
      .from(authzRolePermissions)
      .innerJoin(
        authzPermissions,
        eq(authzRolePermissions.permissionId, authzPermissions.id),
      )
      .where(inArray(authzRolePermissions.roleKey, bizIds));
    for (const row of rows) {
      const key: string = `${row.action}:${row.subject}`;
      const list: string[] = map.get(row.roleKey) ?? [];
      if (!list.includes(key)) {
        list.push(key);
      }
      map.set(row.roleKey, list);
    }
    return map;
  }

  private async fetchMemberCount(bizId: string): Promise<number> {
    const result = await this.authzSDK.members.list(bizId, {
      page: 1,
      pageSize: 1,
    });
    return result?.total ?? 0;
  }

  private async fetchRoleUserMembers(bizId: string): Promise<SdkUserMember[]> {
    const collected: SdkUserMember[] = [];
    for (let page = 1; page <= MAX_MEMBER_PAGES; page += 1) {
      const result = await this.authzSDK.members.list(bizId, {
        type: 'User',
        page,
        pageSize: MEMBER_PAGE_SIZE,
      });
      const userList = (result?.members?.userList ?? []) as SdkUserMember[];
      collected.push(...userList);
      if (!result?.hasMore) {
        break;
      }
    }
    return collected;
  }

  private async isRoleMember(bizId: string, userId: string): Promise<boolean> {
    const members: SdkUserMember[] =
      await this.fetchRoleUserMembers(bizId);
    return members.some((member: SdkUserMember) => member.userID === userId);
  }

  private async replaceRolePermissions(
    bizId: string,
    permissionKeys: string[],
    operatorUserId: string,
  ): Promise<void> {
    const points: Array<{
      id: string;
      action: string;
      subject: string;
    }> = await this.db
      .select({
        id: authzPermissions.id,
        action: authzPermissions.action,
        subject: authzPermissions.subject,
      })
      .from(authzPermissions);
    const keyToId: Map<string, string> = new Map(
      points.map(
        (point: { id: string; action: string; subject: string }) =>
          [`${point.action}:${point.subject}`, point.id] as [
            string,
            string,
          ],
      ),
    );
    const permissionIds: string[] = [];
    for (const key of permissionKeys) {
      const permissionId: string | undefined = keyToId.get(key);
      if (permissionId === undefined) {
        throw new BadRequestException(`权限点位不存在: ${key}`);
      }
      if (!permissionIds.includes(permissionId)) {
        permissionIds.push(permissionId);
      }
    }
    await this.db.transaction(async (tx) => {
      await tx
        .delete(authzRolePermissions)
        .where(eq(authzRolePermissions.roleKey, bizId));
      if (permissionIds.length > 0) {
        await tx.insert(authzRolePermissions).values(
          permissionIds.map(
            (permissionId: string) =>
              ({
                roleKey: bizId,
                permissionId,
                creator: operatorUserId,
              }) as typeof authzRolePermissions.$inferInsert,
          ),
        );
      }
    });
  }
}
