import { Module } from '@nestjs/common';

import { PermissionAdminController } from './permission-admin.controller';
import { PermissionAdminService } from './permission-admin.service';

@Module({
  controllers: [PermissionAdminController],
  providers: [PermissionAdminService],
})
export class PermissionAdminModule {}
