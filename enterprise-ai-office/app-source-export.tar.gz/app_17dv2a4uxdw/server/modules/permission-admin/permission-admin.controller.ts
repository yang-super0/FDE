import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common';
import { Can } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import type {
  CreateRoleResponse,
  MemberListResponse,
  PermissionPointInfo,
  RoleListResponse,
  SuccessResponse,
} from '@shared/api.interface';
import {
  AssignMemberRolesDto,
  CreateRoleDto,
  UpdateRoleDto,
} from './permission-admin.dto';
import { PermissionAdminService } from './permission-admin.service';

@Controller('api/permission-admin')
export class PermissionAdminController {
  constructor(private readonly service: PermissionAdminService) {}

  @Can('read', 'Permission')
  @Get('permission-points')
  listPermissionPoints(): Promise<PermissionPointInfo[]> {
    return this.service.listPermissionPoints();
  }

  @Can('manage', 'Permission')
  @Get('roles')
  listRoles(): Promise<RoleListResponse> {
    return this.service.listRoles();
  }

  @Can('manage', 'Permission')
  @Post('roles')
  async createRole(
    @Req() req: Request,
    @Body() dto: CreateRoleDto,
  ): Promise<CreateRoleResponse> {
    const name: string = (dto.name ?? '').trim();
    if (!name) {
      throw new BadRequestException('角色名称不能为空');
    }
    const permissionKeys: string[] = Array.isArray(dto.permissionKeys)
      ? dto.permissionKeys
      : [];
    const { userId } = req.userContext;
    return this.service.createRole(name, permissionKeys, userId);
  }

  @Can('manage', 'Permission')
  @Patch('roles/:id')
  async updateRole(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateRoleDto,
  ): Promise<SuccessResponse> {
    const name: string | undefined = dto.name?.trim()
      ? dto.name.trim()
      : undefined;
    if (name === undefined && dto.permissionKeys === undefined) {
      throw new BadRequestException('未提供可更新字段');
    }
    const { userId } = req.userContext;
    await this.service.updateRole(id, name, dto.permissionKeys, userId);
    return { success: true };
  }

  @Can('manage', 'Permission')
  @Delete('roles/:id')
  async deleteRole(@Param('id') id: string): Promise<SuccessResponse> {
    await this.service.deleteRole(id);
    return { success: true };
  }

  @Can('manage', 'Permission')
  @Get('members')
  listMembers(): Promise<MemberListResponse> {
    return this.service.listMembers();
  }

  @Can('manage', 'Permission')
  @Post('members/:userId/roles')
  async assignMemberRoles(
    @Param('userId') userId: string,
    @Body() dto: AssignMemberRolesDto,
  ): Promise<SuccessResponse> {
    if (!userId) {
      throw new BadRequestException('缺少成员用户标识');
    }
    const roleIds: string[] = Array.isArray(dto.roleIds) ? dto.roleIds : [];
    await this.service.assignMemberRoles(userId, roleIds);
    return { success: true };
  }
}
