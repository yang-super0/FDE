import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
} from '@nestjs/common';
import { Can } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import type {
  CreateQuotationResponse,
  QuotationDetail,
  QuotationListResponse,
  QuotationStatus,
  SuccessResponse,
} from '@shared/api.interface';
import { QuotationService } from './quotation.service';
import {
  CreateQuotationDto,
  CreateQuotationUnitDto,
  QuotationListQueryDto,
  UpdateQuotationDto,
  UpdateQuotationStatusDto,
} from './quotation.dto';

const DEFAULT_PAGE: number = 1;
const DEFAULT_PAGE_SIZE: number = 20;
const MAX_PAGE_SIZE: number = 50;

@Controller('api/quotations')
export class QuotationController {
  constructor(private readonly quotationService: QuotationService) {}

  @Can('read', 'Quotation')
  @Get()
  list(@Query() query: QuotationListQueryDto): Promise<QuotationListResponse> {
    const page: number = this.toPositiveInt(query.page, DEFAULT_PAGE);
    const rawPageSize: number = this.toPositiveInt(
      query.pageSize,
      DEFAULT_PAGE_SIZE,
    );
    const pageSize: number = Math.min(rawPageSize, MAX_PAGE_SIZE);
    const status: QuotationStatus | undefined =
      (query.status?.trim() as QuotationStatus) || undefined;
    return this.quotationService.list({ status, page, pageSize });
  }

  @Can('read', 'Quotation')
  @Get(':id')
  detail(@Param('id') id: string): Promise<QuotationDetail> {
    return this.quotationService.detail(id);
  }

  @Can('operate', 'Quotation')
  @Post()
  create(
    @Req() req: Request,
    @Body() dto: CreateQuotationDto,
  ): Promise<CreateQuotationResponse> {
    const userId: string = req.userContext.userId;
    return this.quotationService.create(
      {
        customerId: dto.customerId,
        units: dto.units.map((unit: CreateQuotationUnitDto) => ({
          productId: unit.productId,
          projectScene: unit.projectScene ?? '普通项目',
          customItemIds: unit.customItemIds ?? [],
        })),
        remark: dto.remark,
      },
      userId,
    );
  }

  @Can('operate', 'Quotation')
  @Patch(':id/status')
  updateStatus(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateQuotationStatusDto,
  ): Promise<SuccessResponse> {
    const userId: string = req.userContext.userId;
    return this.quotationService.updateStatus(id, dto.status, userId);
  }

  @Can('operate', 'Quotation')
  @Patch(':id')
  update(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateQuotationDto,
  ): Promise<SuccessResponse> {
    const userId: string = req.userContext.userId;
    return this.quotationService.update(
      id,
      {
        customerId: dto.customerId,
        units: dto.units.map((unit: CreateQuotationUnitDto) => ({
          productId: unit.productId,
          projectScene: unit.projectScene ?? '普通项目',
          customItemIds: unit.customItemIds ?? [],
        })),
        remark: dto.remark,
      },
      userId,
    );
  }

  private toPositiveInt(value: unknown, fallback: number): number {
    const parsed: number = Number(value);
    return Number.isFinite(parsed) && parsed > 0
      ? Math.floor(parsed)
      : fallback;
  }
}
