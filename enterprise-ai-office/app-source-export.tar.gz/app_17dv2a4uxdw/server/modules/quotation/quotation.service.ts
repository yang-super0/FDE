import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { and, count, desc, eq, ilike, inArray } from 'drizzle-orm';
import type { SQL } from 'drizzle-orm';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import {
  customer,
  products,
  quotation,
  quotationItem,
  quotationUnits,
} from '@server/database/schema';
import { isValidProjectScene } from '@server/common/utils/scene-rules';
import type {
  CreateQuotationResponse,
  ProjectScene,
  QuotationDetail,
  QuotationItemDetail,
  QuotationListItem,
  QuotationListResponse,
  QuotationStatus,
  QuotationUnitDetail,
  QuotationUnitSummary,
  SuccessResponse,
} from '@shared/api.interface';
import {
  getProductRuleGroups,
  getRequiredItemIdsFromGroups,
  resolveUnitPricing,
  round2,
  type ItemRuleGroup,
  type ResolvedCustomItem,
} from './quotation-pricing';

export interface QuotationListQuery {
  status?: QuotationStatus;
  page: number;
  pageSize: number;
}

export interface QuotationUnitInput {
  productId: string;
  projectScene: string;
  customItemIds: string[];
}

export interface QuotationWriteInput {
  customerId: string;
  units: QuotationUnitInput[];
  remark?: string;
}

interface PlannedUnit {
  productId: string;
  productCode: string;
  basePrice: number;
  projectScene: ProjectScene;
  unitSubtotal: number;
  resolved: ResolvedCustomItem[];
}

const QUOTATION_STATUSES: QuotationStatus[] = [
  'draft',
  'sent',
  'confirmed',
  'closed',
];

const TARGET_STATUSES: Array<Exclude<QuotationStatus, 'draft'>> = [
  'sent',
  'confirmed',
  'closed',
];

const STATUS_TRANSITIONS: Record<
  QuotationStatus,
  Array<Exclude<QuotationStatus, 'draft'>>
> = {
  draft: ['sent'],
  sent: ['confirmed', 'closed'],
  confirmed: [],
  closed: [],
};

const QUOTATION_NO_MAX_RETRY: number = 5;
const LEGACY_UNIT_ID: string = 'legacy-unit';

function extractPostgresErrorCode(error: unknown): string | undefined {
  let current: unknown = error;
  for (
    let depth: number = 0;
    depth < 4 && current && typeof current === 'object';
    depth += 1
  ) {
    const { code, cause } = current as { code?: unknown; cause?: unknown };
    if (typeof code === 'string') {
      return code;
    }
    current = cause;
  }
  return undefined;
}

@Injectable()
export class QuotationService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: QuotationListQuery): Promise<QuotationListResponse> {
    const conditions: SQL[] = [];
    if (params.status && QUOTATION_STATUSES.includes(params.status)) {
      conditions.push(eq(quotation.status, params.status));
    }
    const whereClause: SQL | undefined =
      conditions.length > 0 ? and(...conditions) : undefined;

    const rows: Array<typeof quotation.$inferSelect> = await this.db
      .select()
      .from(quotation)
      .where(whereClause)
      .orderBy(desc(quotation.updatedAt))
      .limit(params.pageSize)
      .offset((params.page - 1) * params.pageSize);

    const countRows: Array<{ count: number }> = await this.db
      .select({ count: count() })
      .from(quotation)
      .where(whereClause);

    const customerNameById: Map<string, string> = new Map<string, string>();
    const productNameById: Map<string, string> = new Map<string, string>();
    const unitsByQuotation: Map<
      string,
      Array<{ productId: string }>
    > = new Map();
    if (rows.length > 0) {
      const customerIds: string[] = [
        ...new Set(rows.map((row) => row.customerId)),
      ];
      const customers: Array<{ id: string; name: string }> = await this.db
        .select({ id: customer.id, name: customer.name })
        .from(customer)
        .where(inArray(customer.id, customerIds));
      customers.forEach((item: { id: string; name: string }) => {
        customerNameById.set(item.id, item.name);
      });

      const quotationIds: string[] = rows.map((row) => row.id);
      const unitRows: Array<{ quotationId: string; productId: string }> =
        await this.db
          .select({
            quotationId: quotationUnits.quotationId,
            productId: quotationUnits.productId,
          })
          .from(quotationUnits)
          .where(inArray(quotationUnits.quotationId, quotationIds));
      unitRows.forEach((unit: { quotationId: string; productId: string }) => {
        const bucket: Array<{ productId: string }> =
          unitsByQuotation.get(unit.quotationId) ?? [];
        bucket.push({ productId: unit.productId });
        unitsByQuotation.set(unit.quotationId, bucket);
      });

      const productIds: string[] = [
        ...new Set([
          ...unitRows.map((unit) => unit.productId),
          ...rows
            .map((row) => row.productId)
            .filter((id: string | null): id is string => id !== null),
        ]),
      ];
      if (productIds.length > 0) {
        const productRows: Array<{ id: string; name: string }> = await this.db
          .select({ id: products.id, name: products.name })
          .from(products)
          .where(inArray(products.id, productIds));
        productRows.forEach((item: { id: string; name: string }) => {
          productNameById.set(item.id, item.name);
        });
      }
    }

    const items: QuotationListItem[] = rows.map(
      (row: typeof quotation.$inferSelect) => {
        const unitList: Array<{ productId: string }> =
          unitsByQuotation.get(row.id) ?? [];
        const summaryByKey: Map<string, QuotationUnitSummary> = new Map();
        for (const unit of unitList) {
          const key: string = unit.productId;
          const existing: QuotationUnitSummary | undefined =
            summaryByKey.get(key);
          if (existing) {
            existing.count += 1;
          } else {
            summaryByKey.set(key, {
              productId: unit.productId,
              productName: productNameById.get(unit.productId) ?? '',
              count: 1,
            });
          }
        }
        if (unitList.length === 0 && row.productId) {
          summaryByKey.set(row.productId, {
            productId: row.productId,
            productName: productNameById.get(row.productId) ?? '',
            count: 1,
          });
        }
        return {
          id: row.id,
          quotationNo: row.quotationNo,
          customerName: customerNameById.get(row.customerId) ?? '',
          productName: row.productId
            ? productNameById.get(row.productId) ?? ''
            : '',
          totalUnits: row.totalUnits,
          unitSummary: [...summaryByKey.values()],
          totalAmount: Number(row.totalAmount),
          status: row.status as QuotationStatus,
          updatedAt: row.updatedAt.toISOString(),
        };
      },
    );

    return { items, total: Number(countRows[0]?.count ?? '0') };
  }

  async detail(id: string): Promise<QuotationDetail> {
    const rows: Array<typeof quotation.$inferSelect> = await this.db
      .select()
      .from(quotation)
      .where(eq(quotation.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('报价单不存在');
    }
    const row: typeof quotation.$inferSelect = rows[0];

    const customerRows: Array<{ name: string }> = await this.db
      .select({ name: customer.name })
      .from(customer)
      .where(eq(customer.id, row.customerId))
      .limit(1);

    const unitRows: Array<typeof quotationUnits.$inferSelect> = await this.db
      .select()
      .from(quotationUnits)
      .where(eq(quotationUnits.quotationId, id))
      .orderBy(quotationUnits.unitNo);

    const itemRows: Array<typeof quotationItem.$inferSelect> = await this.db
      .select()
      .from(quotationItem)
      .where(eq(quotationItem.quotationId, id))
      .orderBy(quotationItem.createdAt);

    const productIds: string[] = [
      ...new Set([
        ...unitRows.map((unit) => unit.productId),
        ...(row.productId ? [row.productId] : []),
      ]),
    ];
    const productInfoById: Map<
      string,
      { name: string; code: string; basePrice: number }
    > = new Map();
    if (productIds.length > 0) {
      const productRows: Array<{
        id: string;
        name: string;
        productCode: string;
        basePrice: string;
      }> = await this.db
        .select({
          id: products.id,
          name: products.name,
          productCode: products.productCode,
          basePrice: products.basePrice,
        })
        .from(products)
        .where(inArray(products.id, productIds));
      productRows.forEach((item) => {
        productInfoById.set(item.id, {
          name: item.name,
          code: item.productCode,
          basePrice: Number(item.basePrice),
        });
      });
    }

    const groupsCache: Map<string, Map<string, ItemRuleGroup>> = new Map();
    const requiredIdsCache: Map<string, Set<string>> = new Map();
    const loadRequiredIds = async (
      productId: string,
      scene: ProjectScene,
    ): Promise<Set<string>> => {
      const cacheKey: string = `${productId}:${scene}`;
      const cached: Set<string> | undefined = requiredIdsCache.get(cacheKey);
      if (cached) {
        return cached;
      }
      let groups: Map<string, ItemRuleGroup> | undefined =
        groupsCache.get(productId);
      if (!groups) {
        groups = await getProductRuleGroups(this.db, productId);
        groupsCache.set(productId, groups);
      }
      const required: Set<string> = getRequiredItemIdsFromGroups(
        groups,
        scene,
      );
      requiredIdsCache.set(cacheKey, required);
      return required;
    };

    const toItemDetail = async (
      item: typeof quotationItem.$inferSelect,
      requiredItemIds: Set<string>,
    ): Promise<QuotationItemDetail> => ({
      id: item.id,
      itemName: item.itemName,
      quantity: Number(item.quantity),
      unitPrice: Number(item.unitPrice),
      amount: Number(item.amount),
      customItemId: item.customItemId ?? null,
      priceAdjustment:
        item.priceAdjustment === null ? null : Number(item.priceAdjustment),
      requiredByScene:
        item.customItemId !== null && requiredItemIds.has(item.customItemId),
    });

    const units: QuotationUnitDetail[] = [];
    if (unitRows.length > 0) {
      const itemsByUnit: Map<string, Array<typeof quotationItem.$inferSelect>> =
        new Map();
      for (const item of itemRows) {
        if (!item.quotationUnitId) {
          continue;
        }
        const bucket: Array<typeof quotationItem.$inferSelect> =
          itemsByUnit.get(item.quotationUnitId) ?? [];
        bucket.push(item);
        itemsByUnit.set(item.quotationUnitId, bucket);
      }
      for (const unit of unitRows) {
        const productInfo:
          | { name: string; code: string; basePrice: number }
          | undefined = productInfoById.get(unit.productId);
        const scene: ProjectScene = isValidProjectScene(unit.projectScene)
          ? unit.projectScene
          : '普通项目';
        const requiredItemIds: Set<string> = await loadRequiredIds(
          unit.productId,
          scene,
        );
        const unitItems: Array<typeof quotationItem.$inferSelect> =
          itemsByUnit.get(unit.id) ?? [];
        const itemDetails: QuotationItemDetail[] = [];
        for (const item of unitItems) {
          itemDetails.push(await toItemDetail(item, requiredItemIds));
        }
        units.push({
          id: unit.id,
          unitNo: unit.unitNo,
          productId: unit.productId,
          productName: productInfo?.name ?? '',
          basePrice: productInfo?.basePrice ?? 0,
          projectScene: scene,
          unitSubtotal: Number(unit.unitSubtotal),
          remark: unit.remark,
          items: itemDetails,
        });
      }
    } else {
      const productInfo:
        | { name: string; code: string; basePrice: number }
        | undefined = row.productId
        ? productInfoById.get(row.productId)
        : undefined;
      const scene: ProjectScene = isValidProjectScene(row.projectScene)
        ? row.projectScene
        : '普通项目';
      const requiredItemIds: Set<string> = row.productId
        ? await loadRequiredIds(row.productId, scene)
        : new Set<string>();
      const itemDetails: QuotationItemDetail[] = [];
      for (const item of itemRows) {
        itemDetails.push(await toItemDetail(item, requiredItemIds));
      }
      units.push({
        id: LEGACY_UNIT_ID,
        unitNo: 1,
        productId: row.productId ?? '',
        productName: productInfo?.name ?? '',
        basePrice: productInfo?.basePrice ?? 0,
        projectScene: scene,
        unitSubtotal: Number(row.totalAmount),
        remark: null,
        items: itemDetails,
      });
    }

    const flatItems: QuotationItemDetail[] = units.flatMap(
      (unit: QuotationUnitDetail) => unit.items,
    );

    return {
      id: row.id,
      quotationNo: row.quotationNo,
      customerId: row.customerId,
      customerName: customerRows[0]?.name ?? '',
      productId: row.productId ?? null,
      productName: units[0]?.productName ?? '',
      basePrice: units[0]?.basePrice ?? null,
      projectScene: units[0]?.projectScene ?? '普通项目',
      totalAmount: Number(row.totalAmount),
      totalUnits: row.totalUnits,
      status: row.status as QuotationStatus,
      remark: row.remark,
      aiSuggestion: row.aiSuggestion,
      units,
      items: flatItems,
      updatedAt: row.updatedAt.toISOString(),
    };
  }

  async create(
    input: QuotationWriteInput,
    userId: string,
  ): Promise<CreateQuotationResponse> {
    if (!input.units || input.units.length === 0) {
      throw new BadRequestException('报价单至少包含一台产品');
    }

    const { plannedUnits, totalAmount } = await this.planUnits(input);

    const dayPart: string = this.getDayPart();
    let newId: string = '';
    for (
      let attempt: number = 0;
      attempt < QUOTATION_NO_MAX_RETRY;
      attempt += 1
    ) {
      const countRows: Array<{ count: number }> = await this.db
        .select({ count: count() })
        .from(quotation)
        .where(ilike(quotation.quotationNo, `QT-${dayPart}-%`));
      const seq: number = Number(countRows[0]?.count ?? '0') + 1 + attempt;
      const quotationNo: string = `QT-${dayPart}-${String(seq).padStart(3, '0')}`;

      try {
        await this.db.transaction(async (tx) => {
          const inserted: Array<{ id: string }> = await tx
            .insert(quotation)
            .values({
              quotationNo,
              customerId: input.customerId,
              productId: plannedUnits[0].productId,
              projectScene: plannedUnits[0].projectScene,
              totalAmount: totalAmount.toFixed(2),
              totalUnits: plannedUnits.length,
              status: 'draft',
              remark: input.remark?.trim() || null,
              createdBy: userId,
              updatedBy: userId,
            })
            .returning({ id: quotation.id });
          newId = inserted[0].id;

          const unitInserted: Array<{ id: string }> = await tx
            .insert(quotationUnits)
            .values(
              plannedUnits.map((unit: PlannedUnit, index: number) => ({
                quotationId: newId,
                unitNo: index + 1,
                productId: unit.productId,
                projectScene: unit.projectScene,
                unitSubtotal: unit.unitSubtotal.toFixed(2),
                remark: null,
                createdBy: userId,
                updatedBy: userId,
              })),
            )
            .returning({ id: quotationUnits.id });

          const itemValues: Array<typeof quotationItem.$inferInsert> = [];
          plannedUnits.forEach((unit: PlannedUnit, index: number) => {
            const unitId: string = unitInserted[index].id;
            for (const item of unit.resolved) {
              itemValues.push({
                quotationId: newId,
                quotationUnitId: unitId,
                customItemId: item.customItemId,
                itemName: item.itemName,
                quantity: '1',
                unitPrice: item.priceAdjustment.toFixed(2),
                amount: item.priceAdjustment.toFixed(2),
                priceAdjustment: item.priceAdjustment.toFixed(2),
                createdBy: userId,
                updatedBy: userId,
              });
            }
          });
          if (itemValues.length > 0) {
            await tx.insert(quotationItem).values(itemValues);
          }
        });
        break;
      } catch (error: unknown) {
        if (extractPostgresErrorCode(error) === '23505') {
          newId = '';
          continue;
        }
        throw error;
      }
    }

    if (!newId) {
      throw new ConflictException('报价单号生成冲突，请重试');
    }
    return { id: newId };
  }

  async update(
    id: string,
    input: QuotationWriteInput,
    userId: string,
  ): Promise<SuccessResponse> {
    if (!input.units || input.units.length === 0) {
      throw new BadRequestException('报价单至少包含一台产品');
    }

    const rows: Array<{ id: string; status: string }> = await this.db
      .select({ id: quotation.id, status: quotation.status })
      .from(quotation)
      .where(eq(quotation.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('报价单不存在');
    }
    if (rows[0].status !== 'draft') {
      throw new ForbiddenException('仅草稿状态的报价单可编辑');
    }

    const { plannedUnits, totalAmount } = await this.planUnits(input);

    await this.db.transaction(async (tx) => {
      const updated: Array<{ id: string }> = await tx
        .update(quotation)
        .set({
          customerId: input.customerId,
          productId: plannedUnits[0].productId,
          projectScene: plannedUnits[0].projectScene,
          totalAmount: totalAmount.toFixed(2),
          totalUnits: plannedUnits.length,
          remark: input.remark?.trim() || null,
          updatedAt: new Date(),
          updatedBy: userId,
        })
        .where(eq(quotation.id, id))
        .returning({ id: quotation.id });
      if (updated.length === 0) {
        throw new NotFoundException('报价单不存在');
      }

      await tx
        .delete(quotationUnits)
        .where(eq(quotationUnits.quotationId, id));

      const unitInserted: Array<{ id: string }> = await tx
        .insert(quotationUnits)
        .values(
          plannedUnits.map((unit: PlannedUnit, index: number) => ({
            quotationId: id,
            unitNo: index + 1,
            productId: unit.productId,
            projectScene: unit.projectScene,
            unitSubtotal: unit.unitSubtotal.toFixed(2),
            remark: null,
            createdBy: userId,
            updatedBy: userId,
          })),
        )
        .returning({ id: quotationUnits.id });

      const itemValues: Array<typeof quotationItem.$inferInsert> = [];
      plannedUnits.forEach((unit: PlannedUnit, index: number) => {
        const unitId: string = unitInserted[index].id;
        for (const item of unit.resolved) {
          itemValues.push({
            quotationId: id,
            quotationUnitId: unitId,
            customItemId: item.customItemId,
            itemName: item.itemName,
            quantity: '1',
            unitPrice: item.priceAdjustment.toFixed(2),
            amount: item.priceAdjustment.toFixed(2),
            priceAdjustment: item.priceAdjustment.toFixed(2),
            createdBy: userId,
            updatedBy: userId,
          });
        }
      });
      if (itemValues.length > 0) {
        await tx.insert(quotationItem).values(itemValues);
      }
    });
    return { success: true };
  }

  async updateStatus(
    id: string,
    nextStatus: string,
    userId: string,
  ): Promise<SuccessResponse> {
    const target: Exclude<QuotationStatus, 'draft'> | undefined =
      TARGET_STATUSES.find((status) => status === nextStatus);
    if (!target) {
      throw new BadRequestException('非法的状态值');
    }

    const rows: Array<{ id: string; status: string }> = await this.db
      .select({ id: quotation.id, status: quotation.status })
      .from(quotation)
      .where(eq(quotation.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('报价单不存在');
    }

    const currentStatus: QuotationStatus = rows[0].status as QuotationStatus;
    if (currentStatus === 'closed') {
      throw new BadRequestException('已关闭的报价单不可流转');
    }
    if (!STATUS_TRANSITIONS[currentStatus].includes(target)) {
      throw new BadRequestException('当前状态不允许执行该流转操作');
    }

    const updated: Array<{ id: string }> = await this.db
      .update(quotation)
      .set({
        status: target,
        updatedAt: new Date(),
        updatedBy: userId,
      })
      .where(and(eq(quotation.id, id), eq(quotation.status, currentStatus)))
      .returning({ id: quotation.id });
    if (updated.length === 0) {
      throw new NotFoundException('报价单不存在');
    }
    return { success: true };
  }

  private async planUnits(input: QuotationWriteInput): Promise<{
    plannedUnits: PlannedUnit[];
    totalAmount: number;
  }> {
    const customerRows: Array<{ id: string }> = await this.db
      .select({ id: customer.id })
      .from(customer)
      .where(eq(customer.id, input.customerId))
      .limit(1);
    if (customerRows.length === 0) {
      throw new NotFoundException('客户不存在');
    }

    const productIds: string[] = [
      ...new Set(input.units.map((unit) => unit.productId)),
    ];
    const productRows: Array<{
      id: string;
      productCode: string;
      basePrice: string;
      status: string;
    }> = await this.db
      .select({
        id: products.id,
        productCode: products.productCode,
        basePrice: products.basePrice,
        status: products.status,
      })
      .from(products)
      .where(inArray(products.id, productIds));
    const productById: Map<
      string,
      { id: string; productCode: string; basePrice: string; status: string }
    > = new Map();
    productRows.forEach((item) => {
      productById.set(item.id, item);
    });

    const groupsCache: Map<string, Map<string, ItemRuleGroup>> = new Map();
    const plannedUnits: PlannedUnit[] = [];
    let totalAmount: number = 0;
    for (const unit of input.units) {
      const product:
        | { id: string; productCode: string; basePrice: string; status: string }
        | undefined = productById.get(unit.productId);
      if (!product) {
        throw new NotFoundException('产品不存在');
      }
      if (product.status !== 'active') {
        throw new BadRequestException('该产品已停用，无法报价');
      }
      const projectScene: ProjectScene = isValidProjectScene(unit.projectScene)
        ? unit.projectScene
        : '普通项目';
      let groups: Map<string, ItemRuleGroup> | undefined = groupsCache.get(
        product.id,
      );
      if (!groups) {
        groups = await getProductRuleGroups(this.db, product.id);
        groupsCache.set(product.id, groups);
      }
      const pricing = resolveUnitPricing(
        Number(product.basePrice),
        groups,
        projectScene,
        unit.customItemIds ?? [],
      );
      plannedUnits.push({
        productId: product.id,
        productCode: product.productCode,
        basePrice: Number(product.basePrice),
        projectScene,
        unitSubtotal: pricing.unitSubtotal,
        resolved: pricing.resolved,
      });
      totalAmount = round2(totalAmount + pricing.unitSubtotal);
    }
    return { plannedUnits, totalAmount };
  }

  private getDayPart(): string {
    const day: string = new Date().toLocaleDateString('en-CA', {
      timeZone: 'Asia/Shanghai',
    });
    return day.replace(/-/g, '');
  }
}
