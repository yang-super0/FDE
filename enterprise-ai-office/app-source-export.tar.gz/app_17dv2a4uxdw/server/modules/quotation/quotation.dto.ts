import { Type } from 'class-transformer';
import {
  ArrayMinSize,
  IsArray,
  IsInt,
  IsOptional,
  IsString,
  Max,
  Min,
  ValidateNested,
} from 'class-validator';

export class QuotationListQueryDto {
  @IsOptional()
  @IsString()
  status?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  page?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(50)
  pageSize?: number;
}

export class CreateQuotationUnitDto {
  @IsString()
  productId!: string;

  @IsOptional()
  @IsString()
  projectScene?: string;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  customItemIds?: string[];
}

export class CreateQuotationDto {
  @IsString()
  customerId!: string;

  @IsArray()
  @ArrayMinSize(1)
  @ValidateNested({ each: true })
  @Type(() => CreateQuotationUnitDto)
  units!: CreateQuotationUnitDto[];

  @IsOptional()
  @IsString()
  remark?: string;
}

export class UpdateQuotationStatusDto {
  @IsString()
  status!: string;
}

export class UpdateQuotationDto extends CreateQuotationDto {}
