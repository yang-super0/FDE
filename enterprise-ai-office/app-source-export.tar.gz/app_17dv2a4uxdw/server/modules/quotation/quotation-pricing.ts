import { BadRequestException } from '@nestjs/common';
import { and, eq, isNotNull } from 'drizzle-orm';
import type { PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import {
  customItems,
  pricingRules,
} from '@server/database/schema';
import {
  sceneMatchesConditions,
  type RuleConditions,
} from '@server/common/utils/scene-rules';
import type { ProjectScene } from '@shared/api.interface';

export interface ProductRuleRow {
  customItemId: string | null;
  priceAdjustment: string;
  priority: number;
  ruleType: string;
  conditions: RuleConditions | null;
  itemName: string;
}

export interface ItemRuleGroup {
  itemName: string;
  baseRule: ProductRuleRow | null;
  conditionalRules: ProductRuleRow[];
}

export interface ResolvedCustomItem {
  customItemId: string;
  itemName: string;
  priceAdjustment: number;
}

export interface UnitPricingResult {
  unitSubtotal: number;
  resolved: ResolvedCustomItem[];
}

export function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

export async function getProductRuleGroups(
  db: PostgresJsDatabase,
  productId: string,
): Promise<Map<string, ItemRuleGroup>> {
  const rawRows: Array<{
    customItemId: string | null;
    priceAdjustment: string;
    priority: number;
    ruleType: string;
    conditions: unknown;
    itemName: string;
  }> = await db
    .select({
      customItemId: pricingRules.customItemId,
      priceAdjustment: pricingRules.priceAdjustment,
      priority: pricingRules.priority,
      ruleType: pricingRules.ruleType,
      conditions: pricingRules.conditions,
      itemName: customItems.name,
    })
    .from(pricingRules)
    .innerJoin(customItems, eq(pricingRules.customItemId, customItems.id))
    .where(
      and(
        eq(pricingRules.productId, productId),
        isNotNull(pricingRules.customItemId),
        eq(pricingRules.status, 'active'),
        eq(customItems.status, 'active'),
      ),
    );

  const groups: Map<string, ItemRuleGroup> = new Map();
  for (const raw of rawRows) {
    if (!raw.customItemId) {
      continue;
    }
    const rule: ProductRuleRow = {
      customItemId: raw.customItemId,
      priceAdjustment: raw.priceAdjustment,
      priority: raw.priority,
      ruleType: raw.ruleType,
      conditions:
        raw.conditions && typeof raw.conditions === 'object'
          ? (raw.conditions as RuleConditions)
          : null,
      itemName: raw.itemName,
    };
    let group: ItemRuleGroup | undefined = groups.get(rule.customItemId);
    if (!group) {
      group = { itemName: rule.itemName, baseRule: null, conditionalRules: [] };
      groups.set(rule.customItemId, group);
    }
    if (rule.ruleType === 'conditional') {
      group.conditionalRules.push(rule);
    } else if (!group.baseRule || rule.priority > group.baseRule.priority) {
      group.baseRule = rule;
    }
  }
  return groups;
}

export function resolveUnitPricing(
  basePrice: number,
  groups: Map<string, ItemRuleGroup>,
  projectScene: ProjectScene,
  customItemIds: string[],
): UnitPricingResult {
  const selectedIds: string[] = [...new Set(customItemIds ?? [])];
  for (const itemId of selectedIds) {
    if (!groups.has(itemId)) {
      throw new BadRequestException('所选定制项不适用于该产品或已停用');
    }
  }

  const finalIds: string[] = [...selectedIds];
  for (const [itemId, group] of groups) {
    const matched: boolean = group.conditionalRules.some(
      (rule: ProductRuleRow) =>
        sceneMatchesConditions(projectScene, rule.conditions),
    );
    if (matched && !finalIds.includes(itemId)) {
      finalIds.push(itemId);
    }
  }

  const resolved: ResolvedCustomItem[] = [];
  let unitSubtotal: number = basePrice;
  for (const itemId of finalIds) {
    const group: ItemRuleGroup | undefined = groups.get(itemId);
    if (!group) {
      throw new BadRequestException('所选定制项不适用于该产品或已停用');
    }
    const matchedConditional: ProductRuleRow | undefined = group
      .conditionalRules.filter((rule: ProductRuleRow) =>
        sceneMatchesConditions(projectScene, rule.conditions),
      )
      .sort((a: ProductRuleRow, b: ProductRuleRow) => b.priority - a.priority)
      .at(0);
    const effective: ProductRuleRow | null =
      matchedConditional ??
      group.baseRule ??
      group.conditionalRules.sort(
        (a: ProductRuleRow, b: ProductRuleRow) => b.priority - a.priority,
      )[0] ??
      null;
    if (!effective) {
      throw new BadRequestException('所选定制项无可用定价规则');
    }
    const priceAdjustment: number = Number(effective.priceAdjustment);
    resolved.push({
      customItemId: itemId,
      itemName: group.itemName,
      priceAdjustment,
    });
    unitSubtotal = round2(unitSubtotal + priceAdjustment);
  }

  return { unitSubtotal, resolved };
}

export function getRequiredItemIdsFromGroups(
  groups: Map<string, ItemRuleGroup>,
  scene: ProjectScene,
): Set<string> {
  if (scene === '普通项目') {
    return new Set<string>();
  }
  const required: Set<string> = new Set<string>();
  for (const [itemId, group] of groups) {
    const matched: boolean = group.conditionalRules.some(
      (rule: ProductRuleRow) => sceneMatchesConditions(scene, rule.conditions),
    );
    if (matched) {
      required.add(itemId);
    }
  }
  return required;
}
