import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { and, count, desc, eq, ilike } from 'drizzle-orm';
import type { SQL } from 'drizzle-orm';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { customCategories, customItems } from '@server/database/schema';
import type {
  BaseDataStatus,
  CreateCustomItemRequest,
  CustomItemAdminItem,
  CustomItemAdminListResponse,
  SuccessResponse,
  UpdateCustomItemRequest,
} from '@shared/api.interface';

export interface CustomItemAdminListQuery {
  page: number;
  pageSize: number;
  keyword?: string;
  status?: BaseDataStatus;
  categoryId?: string;
}

interface CustomItemRow {
  id: string;
  name: string;
  categoryId: string;
  categoryName: string;
  description: string | null;
  defaultPrice: string;
  priceType: string;
  unit: string | null;
  status: string;
  updatedAt: Date;
}

@Injectable()
export class CustomItemsAdminService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(
    params: CustomItemAdminListQuery,
  ): Promise<CustomItemAdminListResponse> {
    const conditions: SQL[] = [];
    if (params.keyword) {
      conditions.push(ilike(customItems.name, `%${params.keyword}%`));
    }
    if (params.status) {
      conditions.push(eq(customItems.status, params.status));
    }
    if (params.categoryId) {
      conditions.push(eq(customItems.categoryId, params.categoryId));
    }
    const whereClause: SQL | undefined =
      conditions.length > 0 ? and(...conditions) : undefined;

    const rows: CustomItemRow[] = await this.db
      .select({
        id: customItems.id,
        name: customItems.name,
        categoryId: customItems.categoryId,
        categoryName: customCategories.name,
        description: customItems.description,
        defaultPrice: customItems.defaultPrice,
        priceType: customItems.priceType,
        unit: customItems.unit,
        status: customItems.status,
        updatedAt: customItems.updatedAt,
      })
      .from(customItems)
      .leftJoin(
        customCategories,
        eq(customItems.categoryId, customCategories.id),
      )
      .where(whereClause)
      .orderBy(desc(customItems.updatedAt))
      .limit(params.pageSize)
      .offset((params.page - 1) * params.pageSize);

    const countRows: Array<{ count: number }> = await this.db
      .select({ count: count() })
      .from(customItems)
      .where(whereClause);

    return {
      items: rows.map((row: CustomItemRow) => ({
        id: row.id,
        name: row.name,
        categoryId: row.categoryId,
        categoryName: row.categoryName,
        description: row.description,
        defaultPrice: Number(row.defaultPrice),
        priceType: row.priceType,
        unit: row.unit,
        status: row.status as BaseDataStatus,
        updatedAt: row.updatedAt.toISOString(),
      })),
      total: Number(countRows[0]?.count ?? '0'),
    };
  }

  async options(): Promise<{ items: Array<{ id: string; name: string }> }> {
    const rows: Array<{ id: string; name: string }> = await this.db
      .select({ id: customItems.id, name: customItems.name })
      .from(customItems)
      .where(eq(customItems.status, 'active'))
      .orderBy(customItems.name);
    return { items: rows };
  }

  async create(input: CreateCustomItemRequest): Promise<{ id: string }> {
    await this.assertCategoryExists(input.categoryId);
    const inserted: Array<{ id: string }> = await this.db
      .insert(customItems)
      .values({
        name: input.name,
        categoryId: input.categoryId,
        description: input.description ?? null,
        defaultPrice: input.defaultPrice.toFixed(2),
        priceType: input.priceType,
        unit: input.unit ?? null,
        status: 'active',
      })
      .returning({ id: customItems.id });
    return { id: inserted[0].id };
  }

  async update(
    id: string,
    input: UpdateCustomItemRequest,
  ): Promise<SuccessResponse> {
    if (input.categoryId !== undefined) {
      await this.assertCategoryExists(input.categoryId);
    }
    const patch: Partial<typeof customItems.$inferInsert> = {};
    if (input.name !== undefined) {
      patch.name = input.name;
    }
    if (input.categoryId !== undefined) {
      patch.categoryId = input.categoryId;
    }
    if (input.description !== undefined) {
      patch.description = input.description;
    }
    if (input.defaultPrice !== undefined) {
      patch.defaultPrice = input.defaultPrice.toFixed(2);
    }
    if (input.priceType !== undefined) {
      patch.priceType = input.priceType;
    }
    if (input.unit !== undefined) {
      patch.unit = input.unit;
    }
    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }
    patch.updatedAt = new Date();

    const updated: Array<{ id: string }> = await this.db
      .update(customItems)
      .set(patch)
      .where(eq(customItems.id, id))
      .returning({ id: customItems.id });
    if (updated.length === 0) {
      throw new NotFoundException('定制项不存在');
    }
    return { success: true };
  }

  async updateStatus(
    id: string,
    status: BaseDataStatus,
  ): Promise<SuccessResponse> {
    const updated: Array<{ id: string }> = await this.db
      .update(customItems)
      .set({ status, updatedAt: new Date() })
      .where(eq(customItems.id, id))
      .returning({ id: customItems.id });
    if (updated.length === 0) {
      throw new NotFoundException('定制项不存在');
    }
    return { success: true };
  }

  private async assertCategoryExists(id: string): Promise<void> {
    const rows: Array<{ id: string }> = await this.db
      .select({ id: customCategories.id })
      .from(customCategories)
      .where(eq(customCategories.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new BadRequestException('所选分类不存在');
    }
  }
}
