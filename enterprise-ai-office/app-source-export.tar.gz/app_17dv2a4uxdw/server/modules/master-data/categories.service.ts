import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { asc, eq } from 'drizzle-orm';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { customCategories } from '@server/database/schema';
import type {
  BaseDataStatus,
  CreateCustomCategoryRequest,
  CustomCategoryNode,
  CustomCategoryOption,
  SuccessResponse,
  UpdateCustomCategoryRequest,
} from '@shared/api.interface';

type CategoryRow = typeof customCategories.$inferSelect;

@Injectable()
export class CategoriesService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async tree(keyword?: string): Promise<{ items: CustomCategoryNode[] }> {
    const rows: CategoryRow[] = await this.db
      .select()
      .from(customCategories)
      .orderBy(asc(customCategories.sortOrder), asc(customCategories.name));

    const nodes: Map<string, CustomCategoryNode> = new Map();
    for (const row of rows) {
      nodes.set(row.id, {
        id: row.id,
        name: row.name,
        parentId: row.parentId,
        sortOrder: row.sortOrder,
        status: row.status as BaseDataStatus,
        children: [],
      });
    }

    const roots: CustomCategoryNode[] = [];
    for (const node of nodes.values()) {
      const parent: CustomCategoryNode | undefined = node.parentId
        ? nodes.get(node.parentId)
        : undefined;
      if (parent) {
        parent.children.push(node);
      } else {
        roots.push(node);
      }
    }

    if (!keyword) {
      return { items: roots };
    }
    const filterTree = (
      list: CustomCategoryNode[],
    ): CustomCategoryNode[] =>
      list
        .map((node: CustomCategoryNode) => ({
          ...node,
          children: filterTree(node.children),
        }))
        .filter(
          (node: CustomCategoryNode) =>
            node.name.includes(keyword) || node.children.length > 0,
        );
    return { items: filterTree(roots) };
  }

  async options(): Promise<{ items: CustomCategoryOption[] }> {
    const rows: CategoryRow[] = await this.db
      .select()
      .from(customCategories)
      .where(eq(customCategories.status, 'active'))
      .orderBy(asc(customCategories.sortOrder), asc(customCategories.name));

    const nameById: Map<string, string> = new Map();
    const parentById: Map<string, string | null> = new Map();
    for (const row of rows) {
      nameById.set(row.id, row.name);
      parentById.set(row.id, row.parentId);
    }

    const fullNameOf = (row: CategoryRow): string => {
      const parts: string[] = [row.name];
      let parentId: string | null = row.parentId;
      let guard: number = 0;
      while (parentId && guard < 10) {
        const parentName: string | undefined = nameById.get(parentId);
        if (!parentName) {
          break;
        }
        parts.unshift(parentName);
        parentId = parentById.get(parentId) ?? null;
        guard += 1;
      }
      return parts.join(' / ');
    };

    return {
      items: rows.map((row: CategoryRow) => ({
        id: row.id,
        name: row.name,
        fullName: fullNameOf(row),
      })),
    };
  }

  async create(input: CreateCustomCategoryRequest): Promise<{ id: string }> {
    if (input.parentId) {
      await this.assertCategoryExists(input.parentId);
    }
    const inserted: Array<{ id: string }> = await this.db
      .insert(customCategories)
      .values({
        name: input.name,
        parentId: input.parentId ?? null,
        sortOrder: input.sortOrder ?? 0,
        status: 'active',
      })
      .returning({ id: customCategories.id });
    return { id: inserted[0].id };
  }

  async update(
    id: string,
    input: UpdateCustomCategoryRequest,
  ): Promise<SuccessResponse> {
    if (input.parentId === id) {
      throw new BadRequestException('上级分类不能是自身');
    }
    if (input.parentId) {
      await this.assertCategoryExists(input.parentId);
    }
    const patch: Partial<typeof customCategories.$inferInsert> = {};
    if (input.name !== undefined) {
      patch.name = input.name;
    }
    if (input.parentId !== undefined) {
      patch.parentId = input.parentId;
    }
    if (input.sortOrder !== undefined) {
      patch.sortOrder = input.sortOrder;
    }
    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }
    patch.updatedAt = new Date();

    const updated: Array<{ id: string }> = await this.db
      .update(customCategories)
      .set(patch)
      .where(eq(customCategories.id, id))
      .returning({ id: customCategories.id });
    if (updated.length === 0) {
      throw new NotFoundException('分类不存在');
    }
    return { success: true };
  }

  async updateStatus(
    id: string,
    status: BaseDataStatus,
  ): Promise<SuccessResponse> {
    const updated: Array<{ id: string }> = await this.db
      .update(customCategories)
      .set({ status, updatedAt: new Date() })
      .where(eq(customCategories.id, id))
      .returning({ id: customCategories.id });
    if (updated.length === 0) {
      throw new NotFoundException('分类不存在');
    }
    return { success: true };
  }

  private async assertCategoryExists(id: string): Promise<void> {
    const rows: Array<{ id: string }> = await this.db
      .select({ id: customCategories.id })
      .from(customCategories)
      .where(eq(customCategories.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new NotFoundException('上级分类不存在');
    }
  }
}
