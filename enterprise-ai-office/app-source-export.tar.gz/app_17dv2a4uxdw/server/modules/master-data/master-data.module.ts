import { Module } from '@nestjs/common';
import { CategoriesController } from './categories.controller';
import { CategoriesService } from './categories.service';
import { CustomItemsAdminController } from './custom-items-admin.controller';
import { CustomItemsAdminService } from './custom-items-admin.service';
import { PricingRulesAdminController } from './pricing-rules-admin.controller';
import { PricingRulesAdminService } from './pricing-rules-admin.service';
import { ProductsAdminController } from './products-admin.controller';
import { ProductsAdminService } from './products-admin.service';

@Module({
  controllers: [
    ProductsAdminController,
    CategoriesController,
    CustomItemsAdminController,
    PricingRulesAdminController,
  ],
  providers: [
    ProductsAdminService,
    CategoriesService,
    CustomItemsAdminService,
    PricingRulesAdminService,
  ],
})
export class MasterDataModule {}
