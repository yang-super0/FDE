import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type {
  CustomCategoryNode,
  CustomCategoryOption,
  SuccessResponse,
} from '@shared/api.interface';
import { CategoriesService } from './categories.service';
import {
  CategoryTreeQueryDto,
  CreateCustomCategoryDto,
  UpdateBaseDataStatusDto,
  UpdateCustomCategoryDto,
} from './master-data.dto';

@Controller('api/master-data/custom-categories')
export class CategoriesController {
  constructor(private readonly categoriesService: CategoriesService) {}

  @Get('tree')
  tree(@Query() query: CategoryTreeQueryDto): Promise<{ items: CustomCategoryNode[] }> {
    return this.categoriesService.tree(query.keyword?.trim() || undefined);
  }

  @Get('options')
  options(): Promise<{ items: CustomCategoryOption[] }> {
    return this.categoriesService.options();
  }

  @NeedLogin()
  @Post()
  create(@Body() dto: CreateCustomCategoryDto): Promise<{ id: string }> {
    return this.categoriesService.create(dto);
  }

  @NeedLogin()
  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() dto: UpdateCustomCategoryDto,
  ): Promise<SuccessResponse> {
    return this.categoriesService.update(id, dto);
  }

  @NeedLogin()
  @Patch(':id/status')
  updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateBaseDataStatusDto,
  ): Promise<SuccessResponse> {
    return this.categoriesService.updateStatus(id, dto.status);
  }
}
