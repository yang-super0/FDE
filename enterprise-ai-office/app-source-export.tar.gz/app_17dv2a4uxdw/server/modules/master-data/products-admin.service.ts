import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { and, count, desc, eq, ilike, or } from 'drizzle-orm';
import type { SQL } from 'drizzle-orm';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { products } from '@server/database/schema';
import type {
  BaseDataStatus,
  CreateProductRequest,
  ProductAdminItem,
  ProductAdminListResponse,
  SuccessResponse,
  UpdateProductRequest,
} from '@shared/api.interface';

export interface ProductAdminListQuery {
  page: number;
  pageSize: number;
  keyword?: string;
  status?: BaseDataStatus;
}

type ProductRow = typeof products.$inferSelect;

function extractPostgresErrorCode(error: unknown): string | undefined {
  let current: unknown = error;
  for (
    let depth: number = 0;
    depth < 4 && current && typeof current === 'object';
    depth += 1
  ) {
    const { code, cause } = current as { code?: unknown; cause?: unknown };
    if (typeof code === 'string') {
      return code;
    }
    current = cause;
  }
  return undefined;
}

@Injectable()
export class ProductsAdminService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(params: ProductAdminListQuery): Promise<ProductAdminListResponse> {
    const conditions: SQL[] = [];
    if (params.keyword) {
      const keyword: string = `%${params.keyword}%`;
      conditions.push(
        or(
          ilike(products.productCode, keyword),
          ilike(products.name, keyword),
        ) as SQL,
      );
    }
    if (params.status) {
      conditions.push(eq(products.status, params.status));
    }
    const whereClause: SQL | undefined =
      conditions.length > 0 ? and(...conditions) : undefined;

    const rows: ProductRow[] = await this.db
      .select()
      .from(products)
      .where(whereClause)
      .orderBy(desc(products.updatedAt))
      .limit(params.pageSize)
      .offset((params.page - 1) * params.pageSize);

    const countRows: Array<{ count: number }> = await this.db
      .select({ count: count() })
      .from(products)
      .where(whereClause);

    return {
      items: rows.map((row: ProductRow) => this.toItem(row)),
      total: Number(countRows[0]?.count ?? '0'),
    };
  }

  async create(
    input: CreateProductRequest,
    userId: string,
  ): Promise<{ id: string }> {
    try {
      const inserted: Array<{ id: string }> = await this.db
        .insert(products)
        .values({
          productCode: input.productCode,
          name: input.name,
          category: input.category ?? null,
          basePrice: input.basePrice.toFixed(2),
          spec: input.spec ?? null,
          description: input.description ?? null,
          status: 'active',
          createdBy: userId,
          updatedBy: userId,
        })
        .returning({ id: products.id });
      return { id: inserted[0].id };
    } catch (error: unknown) {
      if (extractPostgresErrorCode(error) === '23505') {
        throw new ConflictException('产品编码已存在');
      }
      throw error;
    }
  }

  async update(
    id: string,
    input: UpdateProductRequest,
    userId: string,
  ): Promise<SuccessResponse> {
    const patch: Partial<typeof products.$inferInsert> = {};
    if (input.productCode !== undefined) {
      patch.productCode = input.productCode;
    }
    if (input.name !== undefined) {
      patch.name = input.name;
    }
    if (input.category !== undefined) {
      patch.category = input.category;
    }
    if (input.basePrice !== undefined) {
      patch.basePrice = input.basePrice.toFixed(2);
    }
    if (input.spec !== undefined) {
      patch.spec = input.spec;
    }
    if (input.description !== undefined) {
      patch.description = input.description;
    }
    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }
    patch.updatedAt = new Date();
    patch.updatedBy = userId;

    try {
      const updated: Array<{ id: string }> = await this.db
        .update(products)
        .set(patch)
        .where(eq(products.id, id))
        .returning({ id: products.id });
      if (updated.length === 0) {
        throw new NotFoundException('产品不存在');
      }
    } catch (error: unknown) {
      if (extractPostgresErrorCode(error) === '23505') {
        throw new ConflictException('产品编码已存在');
      }
      throw error;
    }
    return { success: true };
  }

  async updateStatus(
    id: string,
    status: BaseDataStatus,
    userId: string,
  ): Promise<SuccessResponse> {
    const updated: Array<{ id: string }> = await this.db
      .update(products)
      .set({ status, updatedAt: new Date(), updatedBy: userId })
      .where(eq(products.id, id))
      .returning({ id: products.id });
    if (updated.length === 0) {
      throw new NotFoundException('产品不存在');
    }
    return { success: true };
  }

  private toItem(row: ProductRow): ProductAdminItem {
    return {
      id: row.id,
      productCode: row.productCode,
      name: row.name,
      category: row.category,
      basePrice: Number(row.basePrice),
      description: row.description,
      spec: (row.spec as Record<string, string> | null) ?? null,
      status: row.status as BaseDataStatus,
      updatedAt: row.updatedAt.toISOString(),
    };
  }
}
