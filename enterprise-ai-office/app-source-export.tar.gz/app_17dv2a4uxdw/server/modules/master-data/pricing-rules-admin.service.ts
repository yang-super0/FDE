import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { Inject } from '@nestjs/common';
import { and, count, desc, eq, ilike, or } from 'drizzle-orm';
import type { SQL } from 'drizzle-orm';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import {
  customItems,
  pricingRules,
  products,
} from '@server/database/schema';
import type {
  BaseDataStatus,
  CreatePricingRuleRequest,
  PricingRuleAdminItem,
  PricingRuleAdminListResponse,
  PricingRuleType,
  SuccessResponse,
  UpdatePricingRuleRequest,
} from '@shared/api.interface';

export interface PricingRuleAdminListQuery {
  page: number;
  pageSize: number;
  keyword?: string;
  status?: BaseDataStatus;
  ruleType?: PricingRuleType;
}

interface PricingRuleRow {
  id: string;
  name: string;
  productId: string;
  productName: string | null;
  customItemId: string | null;
  customItemName: string | null;
  ruleType: string;
  priceAdjustment: string;
  conditions: unknown;
  priority: number;
  description: string | null;
  status: string;
  updatedAt: Date;
}

const RULE_TYPES: PricingRuleType[] = [
  'base_price',
  'standard',
  'conditional',
  'package',
];

@Injectable()
export class PricingRulesAdminService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async list(
    params: PricingRuleAdminListQuery,
  ): Promise<PricingRuleAdminListResponse> {
    const conditions: SQL[] = [];
    if (params.keyword) {
      const keyword: string = `%${params.keyword}%`;
      conditions.push(
        or(
          ilike(products.name, keyword),
          ilike(customItems.name, keyword),
          ilike(pricingRules.description, keyword),
        ) as SQL,
      );
    }
    if (params.status) {
      conditions.push(eq(pricingRules.status, params.status));
    }
    if (params.ruleType && RULE_TYPES.includes(params.ruleType)) {
      conditions.push(eq(pricingRules.ruleType, params.ruleType));
    }
    const whereClause: SQL | undefined =
      conditions.length > 0 ? and(...conditions) : undefined;

    const rows: PricingRuleRow[] = await this.db
      .select({
        id: pricingRules.id,
        name: pricingRules.name,
        productId: pricingRules.productId,
        productName: products.name,
        customItemId: pricingRules.customItemId,
        customItemName: customItems.name,
        ruleType: pricingRules.ruleType,
        priceAdjustment: pricingRules.priceAdjustment,
        conditions: pricingRules.conditions,
        priority: pricingRules.priority,
        description: pricingRules.description,
        status: pricingRules.status,
        updatedAt: pricingRules.updatedAt,
      })
      .from(pricingRules)
      .leftJoin(products, eq(pricingRules.productId, products.id))
      .leftJoin(customItems, eq(pricingRules.customItemId, customItems.id))
      .where(whereClause)
      .orderBy(desc(pricingRules.updatedAt))
      .limit(params.pageSize)
      .offset((params.page - 1) * params.pageSize);

    const countRows: Array<{ count: number }> = await this.db
      .select({ count: count() })
      .from(pricingRules)
      .leftJoin(products, eq(pricingRules.productId, products.id))
      .leftJoin(customItems, eq(pricingRules.customItemId, customItems.id))
      .where(whereClause);

    return {
      items: rows.map((row: PricingRuleRow) => this.toItem(row)),
      total: Number(countRows[0]?.count ?? '0'),
    };
  }

  async create(input: CreatePricingRuleRequest): Promise<{ id: string }> {
    await this.assertValid(input.ruleType, input.productId, input.customItemId);
    const inserted: Array<{ id: string }> = await this.db
      .insert(pricingRules)
      .values({
        name: input.name,
        productId: input.productId,
        customItemId:
          input.ruleType === 'base_price' ? null : input.customItemId ?? null,
        ruleType: input.ruleType,
        priceAdjustment: input.priceAdjustment.toFixed(2),
        conditions: input.conditions ?? null,
        priority: input.priority,
        description: input.description ?? null,
        status: 'active',
      })
      .returning({ id: pricingRules.id });
    return { id: inserted[0].id };
  }

  async update(
    id: string,
    input: UpdatePricingRuleRequest,
  ): Promise<SuccessResponse> {
    const nextRuleType: PricingRuleType | undefined = input.ruleType;
    if (
      input.customItemId !== undefined ||
      nextRuleType !== undefined
    ) {
      const existing: Array<{
        ruleType: string;
        productId: string;
        customItemId: string | null;
      }> = await this.db
        .select({
          ruleType: pricingRules.ruleType,
          productId: pricingRules.productId,
          customItemId: pricingRules.customItemId,
        })
        .from(pricingRules)
        .where(eq(pricingRules.id, id))
        .limit(1);
      if (existing.length === 0) {
        throw new NotFoundException('定价规则不存在');
      }
      const effectiveRuleType: PricingRuleType =
        nextRuleType ?? (existing[0].ruleType as PricingRuleType);
      const effectiveCustomItemId: string | null | undefined =
        input.customItemId !== undefined
          ? input.customItemId
          : existing[0].customItemId;
      await this.assertValid(
        effectiveRuleType,
        input.productId ?? existing[0].productId,
        effectiveCustomItemId ?? undefined,
      );
    } else if (input.productId !== undefined) {
      await this.assertProductExists(input.productId);
    }

    const patch: Partial<typeof pricingRules.$inferInsert> = {};
    if (input.name !== undefined) {
      patch.name = input.name;
    }
    if (input.productId !== undefined) {
      patch.productId = input.productId;
    }
    if (input.ruleType === 'base_price' && input.customItemId === undefined) {
      patch.customItemId = null;
    }
    if (input.customItemId !== undefined) {
      patch.customItemId = input.customItemId;
    }
    if (input.ruleType !== undefined) {
      patch.ruleType = input.ruleType;
    }
    if (input.priceAdjustment !== undefined) {
      patch.priceAdjustment = input.priceAdjustment.toFixed(2);
    }
    if (input.conditions !== undefined) {
      patch.conditions = input.conditions;
    }
    if (input.priority !== undefined) {
      patch.priority = input.priority;
    }
    if (input.description !== undefined) {
      patch.description = input.description;
    }
    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }
    patch.updatedAt = new Date();

    const updated: Array<{ id: string }> = await this.db
      .update(pricingRules)
      .set(patch)
      .where(eq(pricingRules.id, id))
      .returning({ id: pricingRules.id });
    if (updated.length === 0) {
      throw new NotFoundException('定价规则不存在');
    }
    return { success: true };
  }

  async updateStatus(
    id: string,
    status: BaseDataStatus,
  ): Promise<SuccessResponse> {
    const updated: Array<{ id: string }> = await this.db
      .update(pricingRules)
      .set({ status, updatedAt: new Date() })
      .where(eq(pricingRules.id, id))
      .returning({ id: pricingRules.id });
    if (updated.length === 0) {
      throw new NotFoundException('定价规则不存在');
    }
    return { success: true };
  }

  private async assertValid(
    ruleType: PricingRuleType,
    productId: string,
    customItemId?: string,
  ): Promise<void> {
    if (!RULE_TYPES.includes(ruleType)) {
      throw new BadRequestException('非法的规则类型');
    }
    await this.assertProductExists(productId);
    if (ruleType === 'package' || ruleType === 'base_price') {
      if (customItemId) {
        await this.assertCustomItemExists(customItemId);
      }
      return;
    }
    if (!customItemId) {
      throw new BadRequestException('该规则类型必须选择定制项');
    }
    await this.assertCustomItemExists(customItemId);
  }

  private async assertProductExists(id: string): Promise<void> {
    const rows: Array<{ id: string }> = await this.db
      .select({ id: products.id })
      .from(products)
      .where(eq(products.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new BadRequestException('所选产品不存在');
    }
  }

  private async assertCustomItemExists(id: string): Promise<void> {
    const rows: Array<{ id: string }> = await this.db
      .select({ id: customItems.id })
      .from(customItems)
      .where(eq(customItems.id, id))
      .limit(1);
    if (rows.length === 0) {
      throw new BadRequestException('所选定制项不存在');
    }
  }

  private toItem(row: PricingRuleRow): PricingRuleAdminItem {
    return {
      id: row.id,
      name: row.name,
      productId: row.productId,
      productName: row.productName ?? '',
      customItemId: row.customItemId,
      customItemName: row.customItemName,
      ruleType: row.ruleType as PricingRuleType,
      priceAdjustment: Number(row.priceAdjustment),
      conditions:
        row.conditions && typeof row.conditions === 'object'
          ? (row.conditions as Record<string, string | number | boolean>)
          : null,
      priority: row.priority,
      description: row.description,
      status: row.status as BaseDataStatus,
      updatedAt: row.updatedAt.toISOString(),
    };
  }
}
