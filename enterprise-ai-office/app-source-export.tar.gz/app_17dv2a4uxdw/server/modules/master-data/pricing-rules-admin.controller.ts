import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type {
  BaseDataStatus,
  PricingRuleAdminListResponse,
  PricingRuleType,
  SuccessResponse,
} from '@shared/api.interface';
import {
  PricingRulesAdminService,
  type PricingRuleAdminListQuery,
} from './pricing-rules-admin.service';
import {
  CreatePricingRuleDto,
  PricingRuleAdminListQueryDto,
  UpdateBaseDataStatusDto,
  UpdatePricingRuleDto,
} from './master-data.dto';
import { toPageQuery } from './master-data.utils';

@Controller('api/master-data/pricing-rules')
export class PricingRulesAdminController {
  constructor(
    private readonly pricingRulesAdminService: PricingRulesAdminService,
  ) {}

  @Get()
  list(
    @Query() query: PricingRuleAdminListQueryDto,
  ): Promise<PricingRuleAdminListResponse> {
    const pageQuery: PricingRuleAdminListQuery = {
      ...toPageQuery(query.page, query.pageSize),
      keyword: query.keyword?.trim() || undefined,
      status: query.status as BaseDataStatus | undefined,
      ruleType: query.ruleType as PricingRuleType | undefined,
    };
    return this.pricingRulesAdminService.list(pageQuery);
  }

  @NeedLogin()
  @Post()
  create(@Body() dto: CreatePricingRuleDto): Promise<{ id: string }> {
    return this.pricingRulesAdminService.create(dto);
  }

  @NeedLogin()
  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() dto: UpdatePricingRuleDto,
  ): Promise<SuccessResponse> {
    return this.pricingRulesAdminService.update(id, dto);
  }

  @NeedLogin()
  @Patch(':id/status')
  updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateBaseDataStatusDto,
  ): Promise<SuccessResponse> {
    return this.pricingRulesAdminService.updateStatus(id, dto.status);
  }
}
