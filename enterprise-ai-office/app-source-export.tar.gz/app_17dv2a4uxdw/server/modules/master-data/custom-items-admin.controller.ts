import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type {
  BaseDataStatus,
  CustomItemAdminListResponse,
  SuccessResponse,
} from '@shared/api.interface';
import {
  CustomItemsAdminService,
  type CustomItemAdminListQuery,
} from './custom-items-admin.service';
import {
  CreateCustomItemDto,
  CustomItemAdminListQueryDto,
  UpdateBaseDataStatusDto,
  UpdateCustomItemDto,
} from './master-data.dto';
import { toPageQuery } from './master-data.utils';

@Controller('api/master-data/custom-items')
export class CustomItemsAdminController {
  constructor(private readonly customItemsAdminService: CustomItemsAdminService) {}

  @Get()
  list(
    @Query() query: CustomItemAdminListQueryDto,
  ): Promise<CustomItemAdminListResponse> {
    const pageQuery: CustomItemAdminListQuery = {
      ...toPageQuery(query.page, query.pageSize),
      keyword: query.keyword?.trim() || undefined,
      status: query.status as BaseDataStatus | undefined,
      categoryId: query.categoryId?.trim() || undefined,
    };
    return this.customItemsAdminService.list(pageQuery);
  }

  @Get('options')
  options(): Promise<{ items: Array<{ id: string; name: string }> }> {
    return this.customItemsAdminService.options();
  }

  @NeedLogin()
  @Post()
  create(@Body() dto: CreateCustomItemDto): Promise<{ id: string }> {
    return this.customItemsAdminService.create(dto);
  }

  @NeedLogin()
  @Patch(':id')
  update(
    @Param('id') id: string,
    @Body() dto: UpdateCustomItemDto,
  ): Promise<SuccessResponse> {
    return this.customItemsAdminService.update(id, dto);
  }

  @NeedLogin()
  @Patch(':id/status')
  updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateBaseDataStatusDto,
  ): Promise<SuccessResponse> {
    return this.customItemsAdminService.updateStatus(id, dto.status);
  }
}
