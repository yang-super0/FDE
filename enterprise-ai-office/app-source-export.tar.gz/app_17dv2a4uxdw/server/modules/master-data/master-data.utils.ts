const DEFAULT_PAGE: number = 1;
const DEFAULT_PAGE_SIZE: number = 20;
const MAX_PAGE_SIZE: number = 50;

export function toPageQuery(
  page: unknown,
  pageSize: unknown,
): { page: number; pageSize: number } {
  const parsedPage: number = Number(page);
  const parsedPageSize: number = Number(pageSize);
  return {
    page:
      Number.isFinite(parsedPage) && parsedPage > 0
        ? Math.floor(parsedPage)
        : DEFAULT_PAGE,
    pageSize:
      Math.min(
        Number.isFinite(parsedPageSize) && parsedPageSize > 0
          ? Math.floor(parsedPageSize)
          : DEFAULT_PAGE_SIZE,
        MAX_PAGE_SIZE,
      ),
  };
}
