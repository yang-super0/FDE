import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
} from '@nestjs/common';
import { NeedLogin } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import type {
  BaseDataStatus,
  ProductAdminListResponse,
  SuccessResponse,
} from '@shared/api.interface';
import {
  ProductsAdminService,
  type ProductAdminListQuery,
} from './products-admin.service';
import {
  BaseDataListQueryDto,
  CreateProductDto,
  UpdateBaseDataStatusDto,
  UpdateProductDto,
} from './master-data.dto';
import { toPageQuery } from './master-data.utils';

@Controller('api/master-data/products')
export class ProductsAdminController {
  constructor(private readonly productsAdminService: ProductsAdminService) {}

  @Get()
  list(@Query() query: BaseDataListQueryDto): Promise<ProductAdminListResponse> {
    const pageQuery: ProductAdminListQuery = {
      ...toPageQuery(query.page, query.pageSize),
      keyword: query.keyword?.trim() || undefined,
      status: query.status as BaseDataStatus | undefined,
    };
    return this.productsAdminService.list(pageQuery);
  }

  @NeedLogin()
  @Post()
  create(@Req() req: Request, @Body() dto: CreateProductDto): Promise<{ id: string }> {
    const userId: string = req.userContext.userId;
    return this.productsAdminService.create(dto, userId);
  }

  @NeedLogin()
  @Patch(':id')
  update(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateProductDto,
  ): Promise<SuccessResponse> {
    const userId: string = req.userContext.userId;
    return this.productsAdminService.update(id, dto, userId);
  }

  @NeedLogin()
  @Patch(':id/status')
  updateStatus(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: UpdateBaseDataStatusDto,
  ): Promise<SuccessResponse> {
    const userId: string = req.userContext.userId;
    return this.productsAdminService.updateStatus(id, dto.status, userId);
  }
}
