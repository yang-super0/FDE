import {
  IsIn,
  IsNumber,
  IsObject,
  IsOptional,
  IsString,
  MaxLength,
  Min,
  MinLength,
} from 'class-validator';
import { Type } from 'class-transformer';

const BASE_DATA_STATUSES: string[] = ['active', 'disabled'];
const RULE_TYPES: string[] = [
  'base_price',
  'standard',
  'conditional',
  'package',
];

export class BaseDataListQueryDto {
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  pageSize?: number;

  @IsOptional()
  @IsString()
  keyword?: string;

  @IsOptional()
  @IsIn(BASE_DATA_STATUSES)
  status?: 'active' | 'disabled';
}

export class CustomItemAdminListQueryDto extends BaseDataListQueryDto {
  @IsOptional()
  @IsString()
  categoryId?: string;
}

export class PricingRuleAdminListQueryDto extends BaseDataListQueryDto {
  @IsOptional()
  @IsIn(RULE_TYPES)
  ruleType?: 'base_price' | 'standard' | 'conditional' | 'package';
}

export class CategoryTreeQueryDto {
  @IsOptional()
  @IsString()
  keyword?: string;
}

export class UpdateBaseDataStatusDto {
  @IsIn(BASE_DATA_STATUSES)
  status!: 'active' | 'disabled';
}

export class CreateProductDto {
  @IsString()
  @MinLength(1)
  @MaxLength(50)
  productCode!: string;

  @IsString()
  @MinLength(1)
  @MaxLength(255)
  name!: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  category?: string;

  @Type(() => Number)
  @IsNumber()
  @Min(0)
  basePrice!: number;

  @IsOptional()
  @IsObject()
  spec?: Record<string, string>;

  @IsOptional()
  @IsString()
  description?: string;
}

export class UpdateProductDto {
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(50)
  productCode?: string;

  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(255)
  name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  category?: string;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  basePrice?: number;

  @IsOptional()
  @IsObject()
  spec?: Record<string, string>;

  @IsOptional()
  @IsString()
  description?: string;
}

export class CreateCustomCategoryDto {
  @IsString()
  @MinLength(1)
  @MaxLength(255)
  name!: string;

  @IsOptional()
  @IsString()
  parentId?: string;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  sortOrder?: number;
}

export class UpdateCustomCategoryDto {
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(255)
  name?: string;

  @IsOptional()
  @IsString()
  parentId?: string | null;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  sortOrder?: number;
}

export class CreateCustomItemDto {
  @IsString()
  @MinLength(1)
  @MaxLength(255)
  name!: string;

  @IsString()
  categoryId!: string;

  @IsOptional()
  @IsString()
  description?: string;

  @Type(() => Number)
  @IsNumber()
  @Min(0)
  defaultPrice!: number;

  @IsString()
  @IsIn(['fixed', 'percent'])
  priceType!: string;

  @IsOptional()
  @IsString()
  @MaxLength(20)
  unit?: string;
}

export class UpdateCustomItemDto {
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(255)
  name?: string;

  @IsOptional()
  @IsString()
  categoryId?: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  defaultPrice?: number;

  @IsOptional()
  @IsString()
  @IsIn(['fixed', 'percent'])
  priceType?: string;

  @IsOptional()
  @IsString()
  @MaxLength(20)
  unit?: string;
}

export class CreatePricingRuleDto {
  @IsString()
  @MinLength(1)
  @MaxLength(200)
  name!: string;

  @IsString()
  productId!: string;

  @IsOptional()
  @IsString()
  customItemId?: string;

  @IsIn(RULE_TYPES)
  ruleType!: 'base_price' | 'standard' | 'conditional' | 'package';

  @Type(() => Number)
  @IsNumber()
  priceAdjustment!: number;

  @IsOptional()
  @IsObject()
  conditions?: Record<string, string | number | boolean>;

  @Type(() => Number)
  @IsNumber()
  @Min(0)
  priority!: number;

  @IsOptional()
  @IsString()
  description?: string;
}

export class UpdatePricingRuleDto {
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(200)
  name?: string;

  @IsOptional()
  @IsString()
  productId?: string;

  @IsOptional()
  @IsString()
  customItemId?: string | null;

  @IsOptional()
  @IsIn(RULE_TYPES)
  ruleType?: 'base_price' | 'standard' | 'conditional' | 'package';

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  priceAdjustment?: number;

  @IsOptional()
  @IsObject()
  conditions?: Record<string, string | number | boolean> | null;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  priority?: number;

  @IsOptional()
  @IsString()
  description?: string;
}
