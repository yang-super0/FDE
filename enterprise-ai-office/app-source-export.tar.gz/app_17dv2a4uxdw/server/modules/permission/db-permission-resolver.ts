import { Inject, Injectable } from '@nestjs/common';
import type { IPermissionResolver, PermissionPoint } from '@lark-apaas/fullstack-nestjs-core';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { eq, inArray } from 'drizzle-orm';

import {
  authzPermissions,
  authzRolePermissions,
} from '@server/database/schema';

interface PermissionRow {
  id: string;
  action: string;
  subject: string;
  description: string | null;
}

@Injectable()
export class DbPermissionResolver implements IPermissionResolver {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  async resolvePermissions(roleKeys: string[]): Promise<PermissionPoint[]> {
    if (roleKeys.length === 0) return [];
    const rows: PermissionRow[] = await this.db
      .select({
        id: authzPermissions.id,
        action: authzPermissions.action,
        subject: authzPermissions.subject,
        description: authzPermissions.description,
      })
      .from(authzRolePermissions)
      .innerJoin(
        authzPermissions,
        eq(authzRolePermissions.permissionId, authzPermissions.id),
      )
      .where(inArray(authzRolePermissions.roleKey, roleKeys));
    const seen: Set<string> = new Set();
    return rows
      .filter((row: PermissionRow) => {
        const key = `${row.action}:${row.subject}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .map((row: PermissionRow) => ({
        id: row.id,
        action: row.action,
        subject: row.subject,
        description: row.description ?? undefined,
      }));
  }
}
