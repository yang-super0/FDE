import { Module } from '@nestjs/common';

import { DbPermissionResolver } from './db-permission-resolver';

@Module({
  providers: [DbPermissionResolver],
  exports: [DbPermissionResolver],
})
export class PermissionModule {}
