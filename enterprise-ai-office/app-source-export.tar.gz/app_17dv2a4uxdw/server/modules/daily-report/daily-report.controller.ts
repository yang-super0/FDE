import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Post,
  Query,
  Req,
} from '@nestjs/common';
import { Can } from '@lark-apaas/fullstack-nestjs-core';
import type { Request } from 'express';
import type {
  AutoDraftRequest,
  AutoDraftResponse,
  MyDailyReportItem,
  MyDailyReportListResponse,
  SaveDailyReportDraftRequest,
  SaveDailyReportDraftResponse,
  SubmitDailyReportRequest,
  SubmitDailyReportResponse,
  TeamDailyReportParams,
  TeamDailyReportResponse,
} from '@shared/api.interface';
import { DailyReportService } from './daily-report.service';

const DATE_PATTERN: RegExp = /^\d{4}-\d{2}-\d{2}$/;

@Controller('api/daily-reports')
export class DailyReportController {
  constructor(private readonly dailyReportService: DailyReportService) {}

  @Can('operate', 'DailyReport')
  @Post()
  async submit(
    @Req() req: Request,
    @Body() body: SubmitDailyReportRequest,
  ): Promise<SubmitDailyReportResponse> {
    const userId: string = req.userContext.userId;
    if (!body.reportDate || !DATE_PATTERN.test(body.reportDate)) {
      throw new BadRequestException('日报日期格式必须为 YYYY-MM-DD');
    }
    if (!body.todayContent || body.todayContent.trim().length === 0) {
      throw new BadRequestException('今日工作内容不能为空');
    }
    return this.dailyReportService.submit(userId, body);
  }

  @Can('operate', 'DailyReport')
  @Post('auto-draft')
  async autoDraft(
    @Req() req: Request,
    @Body() body: AutoDraftRequest,
  ): Promise<AutoDraftResponse> {
    if (!body.reportDate || !DATE_PATTERN.test(body.reportDate)) {
      throw new BadRequestException('日报日期格式必须为 YYYY-MM-DD');
    }
    return this.dailyReportService.generateAutoDraft(
      req.userContext.userId,
      body.reportDate,
    );
  }

  @Can('operate', 'DailyReport')
  @Post('draft')
  async saveDraft(
    @Req() req: Request,
    @Body() body: SaveDailyReportDraftRequest,
  ): Promise<SaveDailyReportDraftResponse> {
    if (!body.reportDate || !DATE_PATTERN.test(body.reportDate)) {
      throw new BadRequestException('日报日期格式必须为 YYYY-MM-DD');
    }
    return this.dailyReportService.saveDraft(req.userContext.userId, body);
  }

  @Can('read', 'DailyReport')
  @Get('mine/detail')
  async getMineByDate(
    @Req() req: Request,
    @Query('date') date: string,
  ): Promise<MyDailyReportItem | null> {
    if (!date || !DATE_PATTERN.test(date)) {
      throw new BadRequestException('日期参数格式必须为 YYYY-MM-DD');
    }
    return this.dailyReportService.getMineByDate(req.userContext.userId, date);
  }

  @Can('read', 'DailyReport')
  @Get('mine')
  async listMine(@Req() req: Request): Promise<MyDailyReportListResponse> {
    return this.dailyReportService.listMine(req.userContext.userId);
  }

  @Can('read', 'DailyReport')
  @Get('team')
  async listTeam(
    @Query('date') date: string,
    @Query('memberId') memberId?: string,
  ): Promise<TeamDailyReportResponse> {
    if (!date || !DATE_PATTERN.test(date)) {
      throw new BadRequestException('日期参数格式必须为 YYYY-MM-DD');
    }
    const params: TeamDailyReportParams = {
      date,
      ...(memberId ? { memberId } : {}),
    };
    return this.dailyReportService.listTeam(params);
  }
}
