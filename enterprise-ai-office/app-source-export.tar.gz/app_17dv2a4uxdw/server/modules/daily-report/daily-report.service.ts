import {
  ConflictException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { and, asc, desc, eq, gte, lt, sql } from 'drizzle-orm';
import dayjs from 'dayjs';
import {
  AuthNPaasService,
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import {
  customer,
  dailyReport,
  followUp,
  project,
  projectTask,
  quotation,
  workRecords,
} from '@server/database/schema';
import type {
  AutoDraftResponse,
  DailyReportContentStructure,
  DailyReportStatus,
  MyDailyReportItem,
  MyDailyReportListResponse,
  SaveDailyReportDraftRequest,
  SaveDailyReportDraftResponse,
  SubmitDailyReportRequest,
  SubmitDailyReportResponse,
  TeamDailyReportItem,
  TeamDailyReportParams,
  TeamDailyReportResponse,
  WorkDraftCategory,
  WorkDraftItem,
} from '@shared/api.interface';

interface DailyReportSelectRow {
  id: string;
  reportDate: string;
  authorUserId: string;
  todayContent: string;
  tomorrowPlan: string | null;
  risk: string | null;
  status: string;
  contentStructure: DailyReportContentStructure | null;
  createdAt: Date;
}

interface ReportContentInput {
  todayContent: string;
  tomorrowPlan?: string;
  risk?: string;
  contentStructure?: DailyReportContentStructure | null;
}

const CATEGORY_FOLLOW_UP = '客户跟进';
const CATEGORY_PROJECT = '项目进展';
const CATEGORY_QUOTATION = '报价工作';
const CATEGORY_OTHER = '其他';

@Injectable()
export class DailyReportService {
  constructor(
    @Inject(DRIZZLE_DATABASE)
    private readonly db: PostgresJsDatabase,
    private readonly authnPaasService: AuthNPaasService,
  ) {}

  private readonly reportFields = {
    id: dailyReport.id,
    reportDate: dailyReport.reportDate,
    authorUserId: sql<string>`(${dailyReport.author}).user_id`,
    todayContent: dailyReport.todayContent,
    tomorrowPlan: dailyReport.tomorrowPlan,
    risk: dailyReport.risk,
    status: dailyReport.status,
    contentStructure:
      sql<DailyReportContentStructure | null>`${dailyReport.contentStructure}`,
    createdAt: dailyReport.createdAt,
  };

  private authorEquals(userId: string) {
    return sql`(${dailyReport.author}).user_id = ${userId}`;
  }

  private dayRange(reportDate: string): { start: Date; end: Date } {
    const start: Date = new Date(`${reportDate}T00:00:00+08:00`);
    const end: Date = new Date(start.getTime() + 24 * 60 * 60 * 1000);
    return { start, end };
  }

  private toItem(row: DailyReportSelectRow): MyDailyReportItem {
    return {
      id: row.id,
      reportDate: row.reportDate,
      todayContent: row.todayContent,
      tomorrowPlan: row.tomorrowPlan ?? '',
      risk: row.risk ?? '',
      status: row.status === 'draft' ? 'draft' : 'submitted',
      contentStructure: row.contentStructure,
      createdAt: row.createdAt.toISOString(),
    };
  }

  async generateAutoDraft(
    userId: string,
    reportDate: string,
  ): Promise<AutoDraftResponse> {
    const { start, end } = this.dayRange(reportDate);
    const categories: WorkDraftCategory[] = [];

    const followRows: Array<{
      createdAt: Date;
      content: string;
      customerName: string | null;
    }> = await this.db
      .select({
        createdAt: followUp.createdAt,
        content: followUp.content,
        customerName: customer.name,
      })
      .from(followUp)
      .leftJoin(customer, eq(followUp.customerId, customer.id))
      .where(
        and(
          sql`(${followUp.operator}).user_id = ${userId}`,
          gte(followUp.createdAt, start),
          lt(followUp.createdAt, end),
        ),
      )
      .orderBy(asc(followUp.createdAt));
    if (followRows.length > 0) {
      categories.push({
        type: CATEGORY_FOLLOW_UP,
        items: followRows.map(
          (row): WorkDraftItem => ({
            time: dayjs(row.createdAt).format('HH:mm'),
            relatedObject: row.customerName ?? '',
            summary: row.content,
          }),
        ),
      });
    }

    const taskRows: Array<{
      updatedAt: Date;
      taskName: string;
      projectName: string | null;
    }> = await this.db
      .select({
        updatedAt: projectTask.updatedAt,
        taskName: projectTask.taskName,
        projectName: project.name,
      })
      .from(projectTask)
      .leftJoin(project, eq(projectTask.projectId, project.id))
      .where(
        and(
          sql`(${projectTask.assignee}).user_id = ${userId}`,
          gte(projectTask.updatedAt, start),
          lt(projectTask.updatedAt, end),
        ),
      )
      .orderBy(asc(projectTask.updatedAt));
    if (taskRows.length > 0) {
      categories.push({
        type: CATEGORY_PROJECT,
        items: taskRows.map(
          (row): WorkDraftItem => ({
            time: dayjs(row.updatedAt).format('HH:mm'),
            relatedObject: row.projectName ?? '',
            summary: row.taskName,
          }),
        ),
      });
    }

    const quotationRows: Array<{
      createdAt: Date;
      quotationNo: string;
      totalAmount: string;
      remark: string | null;
    }> = await this.db
      .select({
        createdAt: quotation.createdAt,
        quotationNo: quotation.quotationNo,
        totalAmount: quotation.totalAmount,
        remark: quotation.remark,
      })
      .from(quotation)
      .where(
        and(
          sql`(${quotation.createdBy}).user_id = ${userId}`,
          gte(quotation.createdAt, start),
          lt(quotation.createdAt, end),
        ),
      )
      .orderBy(asc(quotation.createdAt));
    if (quotationRows.length > 0) {
      categories.push({
        type: CATEGORY_QUOTATION,
        items: quotationRows.map(
          (row): WorkDraftItem => ({
            time: dayjs(row.createdAt).format('HH:mm'),
            relatedObject: row.quotationNo,
            summary: `创建报价，金额 ¥${Number(row.totalAmount).toLocaleString(
              'zh-CN',
            )}${row.remark ? `，备注：${row.remark}` : ''}`,
          }),
        ),
      });
    }

    const otherRows: Array<{ content: string; createdAt: Date }> =
      await this.db
        .select({
          content: workRecords.content,
          createdAt: workRecords.createdAt,
        })
        .from(workRecords)
        .where(
          and(
            eq(workRecords.employeeId, userId),
            eq(workRecords.workDate, reportDate),
            eq(workRecords.workType, CATEGORY_OTHER),
          ),
        )
        .orderBy(asc(workRecords.createdAt));
    if (otherRows.length > 0) {
      categories.push({
        type: CATEGORY_OTHER,
        items: otherRows.map(
          (row): WorkDraftItem => ({
            time: dayjs(row.createdAt).format('HH:mm'),
            relatedObject: '',
            summary: row.content,
          }),
        ),
      });
    }

    return { reportDate, categories };
  }

  private async findTodayReport(
    userId: string,
    reportDate: string,
  ): Promise<DailyReportSelectRow | null> {
    const rows: DailyReportSelectRow[] = await this.db
      .select(this.reportFields)
      .from(dailyReport)
      .where(and(this.authorEquals(userId), eq(dailyReport.reportDate, reportDate)));
    return rows[0] ?? null;
  }

  private assertNotSubmitted(existing: DailyReportSelectRow | null): void {
    if (existing && existing.status === 'submitted') {
      throw new ConflictException('今日日报已提交');
    }
  }

  async saveDraft(
    userId: string,
    dto: SaveDailyReportDraftRequest,
  ): Promise<SaveDailyReportDraftResponse> {
    const existing: DailyReportSelectRow | null = await this.findTodayReport(
      userId,
      dto.reportDate,
    );
    this.assertNotSubmitted(existing);

    const patch = {
      todayContent: dto.todayContent,
      tomorrowPlan: dto.tomorrowPlan ?? null,
      risk: dto.risk ?? null,
      contentStructure: dto.contentStructure ?? null,
      status: 'draft' as DailyReportStatus,
      updatedAt: new Date(),
      updatedBy: userId,
    };

    if (existing) {
      const updated = await this.db
        .update(dailyReport)
        .set(patch)
        .where(eq(dailyReport.id, existing.id))
        .returning({ id: dailyReport.id });
      if (updated.length === 0) {
        throw new NotFoundException('日报记录不存在');
      }
      return { id: updated[0].id, status: 'draft' };
    }

    const inserted = await this.db
      .insert(dailyReport)
      .values({
        reportDate: dto.reportDate,
        author: userId,
        todayContent: dto.todayContent,
        tomorrowPlan: dto.tomorrowPlan ?? null,
        risk: dto.risk ?? null,
        contentStructure: dto.contentStructure ?? null,
        status: 'draft',
      })
      .onConflictDoNothing()
      .returning({ id: dailyReport.id });
    if (inserted.length === 0) {
      throw new ConflictException('今日日报已提交');
    }
    return { id: inserted[0].id, status: 'draft' };
  }

  async submit(
    userId: string,
    dto: SubmitDailyReportRequest,
  ): Promise<SubmitDailyReportResponse> {
    const existing: DailyReportSelectRow | null = await this.findTodayReport(
      userId,
      dto.reportDate,
    );
    this.assertNotSubmitted(existing);

    const content: ReportContentInput = {
      todayContent: dto.todayContent,
      tomorrowPlan: dto.tomorrowPlan ?? null,
      risk: dto.risk ?? null,
      contentStructure: dto.contentStructure ?? null,
    };

    if (existing) {
      const updated = await this.db
        .update(dailyReport)
        .set({
          ...content,
          status: 'submitted' as DailyReportStatus,
          updatedAt: new Date(),
          updatedBy: userId,
        })
        .where(eq(dailyReport.id, existing.id))
        .returning({ id: dailyReport.id });
      if (updated.length === 0) {
        throw new NotFoundException('日报记录不存在');
      }
      return { id: updated[0].id, status: 'submitted' };
    }

    const inserted = await this.db
      .insert(dailyReport)
      .values({
        reportDate: dto.reportDate,
        author: userId,
        todayContent: dto.todayContent,
        tomorrowPlan: dto.tomorrowPlan ?? null,
        risk: dto.risk ?? null,
        contentStructure: dto.contentStructure ?? null,
        status: 'submitted',
      })
      .onConflictDoNothing()
      .returning({ id: dailyReport.id });
    if (inserted.length === 0) {
      throw new ConflictException('今日日报已提交');
    }
    return { id: inserted[0].id, status: 'submitted' };
  }

  async getMineByDate(
    userId: string,
    reportDate: string,
  ): Promise<MyDailyReportItem | null> {
    const row: DailyReportSelectRow | null = await this.findTodayReport(
      userId,
      reportDate,
    );
    return row ? this.toItem(row) : null;
  }

  async listMine(userId: string): Promise<MyDailyReportListResponse> {
    const rows: DailyReportSelectRow[] = await this.db
      .select(this.reportFields)
      .from(dailyReport)
      .where(this.authorEquals(userId))
      .orderBy(desc(dailyReport.reportDate));

    const items: MyDailyReportItem[] = rows.map(
      (row: DailyReportSelectRow): MyDailyReportItem => this.toItem(row),
    );
    return { items };
  }

  async listTeam(params: TeamDailyReportParams): Promise<TeamDailyReportResponse> {
    let memberIds: string[];
    if (params.memberId) {
      memberIds = [params.memberId];
    } else {
      const authorRows: Array<{ userId: string }> = await this.db
        .selectDistinct({
          userId: sql<string>`(${dailyReport.author}).user_id`,
        })
        .from(dailyReport);
      memberIds = authorRows.map((row: { userId: string }): string => row.userId);
    }
    if (memberIds.length === 0) {
      return { items: [] };
    }

    const reports: DailyReportSelectRow[] = await this.db
      .select(this.reportFields)
      .from(dailyReport)
      .where(
        and(
          eq(dailyReport.reportDate, params.date),
          eq(dailyReport.status, 'submitted'),
        ),
      );

    const memberSet: Set<string> = new Set(memberIds);
    const reportByUser: Map<string, DailyReportSelectRow> = new Map();
    for (const row of reports) {
      if (memberSet.has(row.authorUserId)) {
        reportByUser.set(row.authorUserId, row);
      }
    }

    const users = await this.authnPaasService.listUsersByIds(memberIds);

    const items: TeamDailyReportItem[] = memberIds.map(
      (memberId: string, index: number): TeamDailyReportItem => {
        const user = users[index];
        const userName: string =
          user?.name?.zh_cn ?? user?.name?.en_us ?? '';
        const report: DailyReportSelectRow | undefined =
          reportByUser.get(memberId);
        if (!report) {
          return {
            userId: memberId,
            userName,
            submitted: false,
            reportId: null,
            todayContent: null,
            tomorrowPlan: null,
            risk: null,
            submittedAt: null,
          };
        }
        return {
          userId: memberId,
          userName,
          submitted: true,
          reportId: report.id,
          todayContent: report.todayContent,
          tomorrowPlan: report.tomorrowPlan,
          risk: report.risk,
          submittedAt: report.createdAt.toISOString(),
        };
      },
    );

    items.sort((a: TeamDailyReportItem, b: TeamDailyReportItem): number => {
      if (a.submitted !== b.submitted) {
        return a.submitted ? -1 : 1;
      }
      return (b.submittedAt ?? '').localeCompare(a.submittedAt ?? '');
    });

    return { items };
  }
}
