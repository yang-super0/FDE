import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import { Can } from '@lark-apaas/fullstack-nestjs-core';
import type {
  AddProjectMembersRequest,
  CreateProjectRequest,
  CreateProjectResponse,
  CreateProjectTaskRequest,
  CreateProjectTaskResponse,
  ProjectDetail,
  ProjectListResponse,
  ProjectStatus,
  ProjectTaskListResponse,
  ProjectTaskStatus,
  SuccessResponse,
  UpdateProjectRequest,
  UpdateProjectStatusRequest,
  UpdateProjectTaskRequest,
} from '@shared/api.interface';
import { ProjectService } from './project.service';

const PROJECT_STATUSES: ProjectStatus[] = [
  'not_started',
  'in_progress',
  'completed',
  'delayed',
];

const TASK_STATUSES: ProjectTaskStatus[] = ['pending', 'completed'];

@Controller('api/projects')
export class ProjectController {
  constructor(private readonly projectService: ProjectService) {}

  @Can('read', 'Project')
  @Get()
  async list(@Query('status') status?: string): Promise<ProjectListResponse> {
    let filter: ProjectStatus | undefined;
    if (status !== undefined && status !== '') {
      if (!PROJECT_STATUSES.includes(status as ProjectStatus)) {
        throw new BadRequestException('无效的项目状态');
      }
      filter = status as ProjectStatus;
    }
    return this.projectService.list(filter);
  }

  @Can('operate', 'Project')
  @Post()
  async create(@Body() dto: CreateProjectRequest): Promise<CreateProjectResponse> {
    return this.projectService.create(dto);
  }

  @Can('read', 'Project')
  @Get(':id')
  async detail(@Param('id') id: string): Promise<ProjectDetail> {
    return this.projectService.detail(id);
  }

  @Can('operate', 'Project')
  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Req() req: Request,
    @Body() dto: UpdateProjectRequest,
  ): Promise<SuccessResponse> {
    return this.projectService.update(id, dto, req.userContext.userId);
  }

  @Can('operate', 'Project')
  @Patch(':id/status')
  async updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateProjectStatusRequest,
  ): Promise<SuccessResponse> {
    if (!PROJECT_STATUSES.includes(dto?.status)) {
      throw new BadRequestException('无效的项目状态');
    }
    return this.projectService.updateStatus(id, dto.status);
  }

  @Can('operate', 'Project')
  @Post(':id/members')
  async addMembers(
    @Param('id') id: string,
    @Body() dto: AddProjectMembersRequest,
  ): Promise<SuccessResponse> {
    if (!Array.isArray(dto?.memberIds)) {
      throw new BadRequestException('memberIds 必须为数组');
    }
    return this.projectService.addMembers(id, dto.memberIds);
  }

  @Can('read', 'Project')
  @Get(':id/tasks')
  async listTasks(@Param('id') id: string): Promise<ProjectTaskListResponse> {
    return this.projectService.listTasks(id);
  }

  @Can('operate', 'Project')
  @Post(':id/tasks')
  async createTask(
    @Param('id') id: string,
    @Body() dto: CreateProjectTaskRequest,
  ): Promise<CreateProjectTaskResponse> {
    return this.projectService.createTask(id, dto);
  }

  @Can('operate', 'Project')
  @Patch(':id/tasks/:taskId')
  async updateTaskStatus(
    @Param('id') id: string,
    @Param('taskId') taskId: string,
    @Body() dto: UpdateProjectTaskRequest,
  ): Promise<SuccessResponse> {
    if (!TASK_STATUSES.includes(dto?.status)) {
      throw new BadRequestException('无效的任务状态');
    }
    return this.projectService.updateTaskStatus(id, taskId, dto.status);
  }
}
