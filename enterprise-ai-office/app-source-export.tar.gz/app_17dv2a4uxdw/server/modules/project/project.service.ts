import {
  BadRequestException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import {
  AuthNPaasService,
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { and, asc, count, desc, eq, inArray } from 'drizzle-orm';
import {
  customer,
  project,
  projectMember,
  projectTask,
} from '@server/database/schema';
import type {
  CreateProjectRequest,
  CreateProjectResponse,
  CreateProjectTaskRequest,
  CreateProjectTaskResponse,
  ProjectDetail,
  ProjectListItem,
  ProjectListResponse,
  ProjectMemberInfo,
  ProjectStatus,
  ProjectTaskItem,
  ProjectTaskListResponse,
  ProjectTaskStatus,
  SuccessResponse,
  UpdateProjectRequest,
} from '@shared/api.interface';

type ProjectRow = typeof project.$inferSelect;
type ProjectTaskRow = typeof projectTask.$inferSelect;
type CustomerRow = typeof customer.$inferSelect;

interface UserInfoBrief {
  name: string;
  avatar: string;
}

@Injectable()
export class ProjectService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
    private readonly authn: AuthNPaasService,
  ) {}

  private async fetchUserInfoMap(
    userIds: string[],
  ): Promise<Map<string, UserInfoBrief>> {
    const uniqueIds: string[] = Array.from(new Set(userIds)).filter(
      (id: string) => id.length > 0,
    );
    const map: Map<string, UserInfoBrief> = new Map();
    if (uniqueIds.length === 0) {
      return map;
    }
    const users = await this.authn.listUsersByIds(uniqueIds);
    uniqueIds.forEach((id: string, index: number) => {
      const user = users[index];
      map.set(id, {
        name: user?.name?.zh_cn ?? user?.name?.en_us ?? '未知用户',
        avatar: user?.avatar?.image?.large ?? '',
      });
    });
    return map;
  }

  private async fetchCustomerNameMap(
    customerIds: Array<string | null>,
  ): Promise<Map<string, string>> {
    const uniqueIds: string[] = Array.from(
      new Set(customerIds.filter((id: string | null): id is string => Boolean(id))),
    );
    const map: Map<string, string> = new Map();
    if (uniqueIds.length === 0) {
      return map;
    }
    const rows: Array<{ id: string; name: string }> = await this.db
      .select({ id: customer.id, name: customer.name })
      .from(customer)
      .where(inArray(customer.id, uniqueIds));
    rows.forEach((row: { id: string; name: string }) => {
      map.set(row.id, row.name);
    });
    return map;
  }

  private async ensureCustomerExists(customerId: string): Promise<void> {
    const rows: Array<{ id: string }> = await this.db
      .select({ id: customer.id })
      .from(customer)
      .where(eq(customer.id, customerId));
    if (rows.length === 0) {
      throw new BadRequestException('关联客户不存在');
    }
  }

  private async ensureProject(projectId: string): Promise<ProjectRow> {
    const rows: ProjectRow[] = await this.db
      .select()
      .from(project)
      .where(eq(project.id, projectId));
    if (rows.length === 0) {
      throw new NotFoundException('项目不存在');
    }
    return rows[0];
  }

  async list(status?: ProjectStatus): Promise<ProjectListResponse> {
    const condition = status ? eq(project.status, status) : undefined;
    const rows: ProjectRow[] = condition
      ? await this.db
          .select()
          .from(project)
          .where(condition)
          .orderBy(desc(project.createdAt))
      : await this.db
          .select()
          .from(project)
          .orderBy(desc(project.createdAt));
    const totalRows: Array<{ count: number }> = condition
      ? await this.db
          .select({ count: count() })
          .from(project)
          .where(condition)
      : await this.db.select({ count: count() }).from(project);
    const total: number = Number(totalRows[0]?.count ?? 0);
    const userInfoMap: Map<string, UserInfoBrief> = await this.fetchUserInfoMap(
      rows.map((row: ProjectRow) => row.owner),
    );
    const customerNameMap: Map<string, string> = await this.fetchCustomerNameMap(
      rows.map((row: ProjectRow) => row.customerId),
    );
    const items: ProjectListItem[] = rows.map((row: ProjectRow) => ({
      id: row.id,
      name: row.name,
      ownerName: userInfoMap.get(row.owner)?.name ?? '未知用户',
      startDate: row.startDate,
      endDate: row.endDate,
      status: row.status as ProjectStatus,
      progress: row.progress,
      customerId: row.customerId,
      customerName: row.customerId
        ? customerNameMap.get(row.customerId) ?? null
        : null,
    }));
    return { items, total };
  }

  async listByCustomer(customerId: string): Promise<ProjectListItem[]> {
    const rows: ProjectRow[] = await this.db
      .select()
      .from(project)
      .where(eq(project.customerId, customerId))
      .orderBy(desc(project.createdAt));
    if (rows.length === 0) {
      return [];
    }
    const userInfoMap: Map<string, UserInfoBrief> = await this.fetchUserInfoMap(
      rows.map((row: ProjectRow) => row.owner),
    );
    const customerNameMap: Map<string, string> = await this.fetchCustomerNameMap(
      [customerId],
    );
    return rows.map((row: ProjectRow) => ({
      id: row.id,
      name: row.name,
      ownerName: userInfoMap.get(row.owner)?.name ?? '未知用户',
      startDate: row.startDate,
      endDate: row.endDate,
      status: row.status as ProjectStatus,
      progress: row.progress,
      customerId: row.customerId,
      customerName: customerNameMap.get(customerId) ?? null,
    }));
  }

  async create(dto: CreateProjectRequest): Promise<CreateProjectResponse> {
    if (!dto.name?.trim()) {
      throw new BadRequestException('项目名称不能为空');
    }
    if (!dto.startDate || !dto.endDate) {
      throw new BadRequestException('请选择项目起止日期');
    }
    if (dto.endDate < dto.startDate) {
      throw new BadRequestException('结束日期不能早于开始日期');
    }
    if (!dto.ownerId) {
      throw new BadRequestException('请选择项目负责人');
    }
    if (dto.customerId) {
      await this.ensureCustomerExists(dto.customerId);
    }
    const memberIds: string[] = Array.from(
      new Set([dto.ownerId, ...(dto.memberIds ?? [])]),
    ).filter((id: string) => typeof id === 'string' && id.length > 0);
    return this.db.transaction(async (tx) => {
      const inserted: Array<{ id: string }> = await tx
        .insert(project)
        .values({
          name: dto.name.trim(),
          owner: dto.ownerId,
          startDate: dto.startDate,
          endDate: dto.endDate,
          description: dto.description ?? null,
          status: 'not_started',
          progress: 0,
          customerId: dto.customerId ?? null,
        })
        .returning({ id: project.id });
      const projectId: string = inserted[0].id;
      if (memberIds.length > 0) {
        await tx
          .insert(projectMember)
          .values(
            memberIds.map((userId: string) => ({
              projectId,
              member: userId,
            })),
          )
          .onConflictDoNothing();
      }
      return { id: projectId };
    });
  }

  async detail(id: string): Promise<ProjectDetail> {
    const row: ProjectRow = await this.ensureProject(id);
    const memberRows: Array<{ id: string; member: string }> = await this.db
      .select({ id: projectMember.id, member: projectMember.member })
      .from(projectMember)
      .where(eq(projectMember.projectId, id));
    const userInfoMap: Map<string, UserInfoBrief> = await this.fetchUserInfoMap(
      [
        row.owner,
        ...memberRows.map((memberRow: { member: string }) => memberRow.member),
      ],
    );
    const ownerName: string =
      userInfoMap.get(row.owner)?.name ?? '未知用户';
    const customerNameMap: Map<string, string> = await this.fetchCustomerNameMap(
      [row.customerId],
    );
    const members: ProjectMemberInfo[] = memberRows.map(
      (memberRow: { member: string }) => {
        const info: UserInfoBrief | undefined = userInfoMap.get(
          memberRow.member,
        );
        return {
          userId: memberRow.member,
          name: info?.name ?? '未知用户',
          avatar: info?.avatar ?? '',
        };
      },
    );
    return {
      id: row.id,
      name: row.name,
      ownerId: row.owner,
      ownerName,
      startDate: row.startDate,
      endDate: row.endDate,
      description: row.description ?? '',
      status: row.status as ProjectStatus,
      progress: row.progress,
      members,
      customerId: row.customerId,
      customerName: row.customerId
        ? customerNameMap.get(row.customerId) ?? null
        : null,
    };
  }

  async update(
    id: string,
    dto: UpdateProjectRequest,
    userId: string,
  ): Promise<SuccessResponse> {
    await this.ensureProject(id);
    const patch: Partial<typeof project.$inferInsert> = {};
    if (dto.customerId === null) {
      patch.customerId = null;
    } else if (typeof dto.customerId === 'string' && dto.customerId.length > 0) {
      await this.ensureCustomerExists(dto.customerId);
      patch.customerId = dto.customerId;
    }
    if (dto.progress !== undefined) {
      const progressValue: number = Number(dto.progress);
      if (
        !Number.isInteger(progressValue) ||
        progressValue < 0 ||
        progressValue > 100
      ) {
        throw new BadRequestException('进度必须为 0-100 的整数');
      }
      patch.progress = progressValue;
    }
    if (Object.keys(patch).length === 0) {
      throw new BadRequestException('未提供可更新字段');
    }
    patch.updatedAt = new Date();
    patch.updatedBy = userId;
    const updated: Array<{ id: string }> = await this.db
      .update(project)
      .set(patch)
      .where(eq(project.id, id))
      .returning({ id: project.id });
    if (updated.length === 0) {
      throw new NotFoundException('项目不存在');
    }
    return { success: true };
  }

  async updateStatus(
    id: string,
    status: ProjectStatus,
  ): Promise<SuccessResponse> {
    const updated: Array<{ id: string }> = await this.db
      .update(project)
      .set({ status })
      .where(eq(project.id, id))
      .returning({ id: project.id });
    if (updated.length === 0) {
      throw new NotFoundException('项目不存在');
    }
    return { success: true };
  }

  async addMembers(
    id: string,
    memberIds: string[],
  ): Promise<SuccessResponse> {
    await this.ensureProject(id);
    const uniqueIds: string[] = Array.from(new Set(memberIds ?? [])).filter(
      (memberId: string) => typeof memberId === 'string' && memberId.length > 0,
    );
    if (uniqueIds.length > 0) {
      await this.db
        .insert(projectMember)
        .values(
          uniqueIds.map((userId: string) => ({ projectId: id, member: userId })),
        )
        .onConflictDoNothing();
    }
    return { success: true };
  }

  async listTasks(projectId: string): Promise<ProjectTaskListResponse> {
    await this.ensureProject(projectId);
    const rows: ProjectTaskRow[] = await this.db
      .select()
      .from(projectTask)
      .where(eq(projectTask.projectId, projectId))
      .orderBy(asc(projectTask.dueDate));
    const userInfoMap: Map<string, UserInfoBrief> = await this.fetchUserInfoMap(
      rows.map((row: ProjectTaskRow) => row.assignee),
    );
    const items: ProjectTaskItem[] = rows.map((row: ProjectTaskRow) => ({
      id: row.id,
      taskName: row.taskName,
      assigneeId: row.assignee,
      assigneeName: userInfoMap.get(row.assignee)?.name ?? '未知用户',
      status: row.status as ProjectTaskStatus,
      dueDate: row.dueDate,
    }));
    return { items };
  }

  async createTask(
    projectId: string,
    dto: CreateProjectTaskRequest,
  ): Promise<CreateProjectTaskResponse> {
    await this.ensureProject(projectId);
    if (!dto.taskName?.trim()) {
      throw new BadRequestException('任务名称不能为空');
    }
    if (!dto.assigneeId) {
      throw new BadRequestException('请选择任务负责人');
    }
    if (!dto.dueDate) {
      throw new BadRequestException('请选择任务截止日期');
    }
    return this.db.transaction(async (tx) => {
      const inserted: Array<{ id: string }> = await tx
        .insert(projectTask)
        .values({
          projectId,
          taskName: dto.taskName.trim(),
          assignee: dto.assigneeId,
          status: 'pending',
          dueDate: dto.dueDate,
        })
        .returning({ id: projectTask.id });
      return { id: inserted[0].id };
    });
  }

  async updateTaskStatus(
    projectId: string,
    taskId: string,
    status: ProjectTaskStatus,
  ): Promise<SuccessResponse> {
    await this.ensureProject(projectId);
    const updated: Array<{ id: string }> = await this.db
      .update(projectTask)
      .set({ status })
      .where(
        and(eq(projectTask.id, taskId), eq(projectTask.projectId, projectId)),
      )
      .returning({ id: projectTask.id });
    if (updated.length === 0) {
      throw new NotFoundException('任务不存在');
    }
    return { success: true };
  }
}
