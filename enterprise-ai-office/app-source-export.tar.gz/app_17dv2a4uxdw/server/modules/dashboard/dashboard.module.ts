import { Module } from '@nestjs/common';
import { DashboardController } from './dashboard.controller';
import { DashboardService } from './dashboard.service';
import { DashboardStatsService } from './dashboard-stats.service';

@Module({
  controllers: [DashboardController],
  providers: [DashboardService, DashboardStatsService],
})
export class DashboardModule {}
