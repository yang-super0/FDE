import {
  BadRequestException,
  Inject,
  Injectable,
} from '@nestjs/common';
import {
  AuthNPaasService,
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { and, count, eq, gte, lt, lte, sql } from 'drizzle-orm';
import type { AnyPgColumn } from 'drizzle-orm/pg-core';
import {
  customer,
  dailyReport,
  followUp,
  project,
  quotation,
} from '@server/database/schema';
import type {
  DashboardCards,
  DashboardDeltaStat,
  DashboardMetrics,
  DashboardOwnerOption,
  DashboardQuotationTrendPoint,
  DashboardRange,
  DashboardReportRatePoint,
  DashboardStatPoint,
  DashboardStats,
  DashboardStatsParams,
} from '@shared/api.interface';

const SHANGHAI_OFFSET_MS: number = 8 * 60 * 60 * 1000;
const DAY_MS: number = 24 * 60 * 60 * 1000;
const MAX_REPORT_TREND_DAYS: number = 31;
const OWNER_LIMIT: number = 100;
const DAY_PATTERN: RegExp = /^\d{4}-\d{2}-\d{2}$/u;

interface DateWindow {
  startDay: string;
  endDay: string;
  prevStartDay: string;
  prevEndDay: string;
  granularity: 'day' | 'month';
  reportStartDay: string;
}

interface QuotationWindowRow {
  count: number;
  amount: string;
  confirmed: number;
}

function pad(value: number): string {
  return String(value).padStart(2, '0');
}

function toShanghaiDay(utcMs: number): string {
  const local: Date = new Date(utcMs + SHANGHAI_OFFSET_MS);
  return `${local.getUTCFullYear()}-${pad(local.getUTCMonth() + 1)}-${pad(
    local.getUTCDate()
  )}`;
}

function dayToUtcMs(day: string): number {
  const [year, month, date]: number[] = day.split('-').map(Number);
  return Date.UTC(year, month - 1, date) - SHANGHAI_OFFSET_MS;
}

function shiftDay(day: string, days: number): string {
  return toShanghaiDay(dayToUtcMs(day) + days * DAY_MS);
}

function spanDays(startDay: string, endDay: string): number {
  return Math.round((dayToUtcMs(endDay) - dayToUtcMs(startDay)) / DAY_MS) + 1;
}

function listDayBuckets(startDay: string, endDay: string): string[] {
  const buckets: string[] = [];
  let cursor: string = startDay;
  while (cursor <= endDay) {
    buckets.push(cursor);
    cursor = shiftDay(cursor, 1);
  }
  return buckets;
}

function listMonthBuckets(startDay: string, endDay: string): string[] {
  const buckets: string[] = [];
  let cursor: string = startDay.slice(0, 7);
  const endMonth: string = endDay.slice(0, 7);
  while (cursor <= endMonth) {
    buckets.push(cursor);
    const [year, month]: number[] = cursor.split('-').map(Number);
    cursor = `${month === 12 ? year + 1 : year}-${pad(
      month === 12 ? 1 : month + 1
    )}`;
  }
  return buckets;
}

function calcDelta(current: number, previous: number): number | null {
  if (previous <= 0) {
    return null;
  }
  return Math.round(((current - previous) / previous) * 1000) / 10;
}

@Injectable()
export class DashboardStatsService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
    private readonly authn: AuthNPaasService
  ) {}

  async getStats(params: DashboardStatsParams): Promise<DashboardStats> {
    const window_: DateWindow = this.resolveWindow(params);
    const ownerId: string | undefined =
      params.ownerId && params.ownerId.trim().length > 0
        ? params.ownerId.trim()
        : undefined;

    const [cards, quotationTrend, customerTrend, projectStatusDist,
      reportRateTrend, metrics] = await Promise.all([
      this.buildCards(window_, ownerId),
      this.buildQuotationTrend(window_, ownerId),
      this.buildCustomerTrend(window_, ownerId),
      this.buildProjectStatusDist(ownerId),
      this.buildReportRateTrend(window_, ownerId),
      this.buildMetrics(window_, ownerId),
    ]);

    return {
      cards,
      quotationTrend,
      customerTrend,
      projectStatusDist,
      reportRateTrend,
      metrics,
    };
  }

  async getOwnerOptions(): Promise<DashboardOwnerOption[]> {
    const rows: Record<string, unknown>[] = await this.db.execute(sql`
      select distinct uid from (
        select (${quotation.createdBy}).user_id as uid from ${quotation}
        union select (${project.owner}).user_id from ${project}
        union select (${customer.createdBy}).user_id from ${customer}
      ) as owners where uid is not null and uid <> ''
      limit ${OWNER_LIMIT}
    `);
    const ids: string[] = rows.map(
      (row: Record<string, unknown>) => String(row.uid ?? '')
    ).filter((id: string) => id.length > 0);
    if (ids.length === 0) {
      return [];
    }
    const users: ({
      name?: { zh_cn?: string; en_us?: string };
    } | null)[] = await this.authn.listUsersByIds(ids);
    return ids
      .map((id: string, index: number): DashboardOwnerOption | null => {
        const user: { name?: { zh_cn?: string; en_us?: string } } | null =
          users[index];
        if (!user) {
          return null;
        }
        const name: string =
          user.name?.zh_cn ?? user.name?.en_us ?? '';
        if (name.length === 0) {
          return null;
        }
        return { userId: id, name };
      })
      .filter(
        (option: DashboardOwnerOption | null): option is DashboardOwnerOption =>
          option !== null
      );
  }

  private resolveWindow(params: DashboardStatsParams): DateWindow {
    const today: string = toShanghaiDay(Date.now());
    let startDay: string;
    if (params.range === 'custom') {
      if (
        !params.startDate ||
        !params.endDate ||
        !DAY_PATTERN.test(params.startDate) ||
        !DAY_PATTERN.test(params.endDate) ||
        params.startDate > params.endDate
      ) {
        throw new BadRequestException('自定义时间范围参数无效');
      }
      startDay = params.startDate;
      return this.buildWindow(startDay, params.endDate, today);
    }
    const rangeDays: Record<Exclude<DashboardRange, 'custom'>, number> = {
      '7d': 7,
      '30d': 30,
      '90d': 90,
      year: spanDays(`${today.slice(0, 4)}-01-01`, today),
    };
    startDay = shiftDay(today, -(rangeDays[params.range] - 1));
    return this.buildWindow(startDay, today, today);
  }

  private buildWindow(
    startDay: string,
    endDay: string,
    today: string
  ): DateWindow {
    const span: number = spanDays(startDay, endDay);
    const prevEndDay: string = shiftDay(startDay, -1);
    const prevStartDay: string = shiftDay(prevEndDay, -(span - 1));
    const reportSpan: number = Math.min(spanDays(startDay, today),
      MAX_REPORT_TREND_DAYS);
    return {
      startDay,
      endDay,
      prevStartDay,
      prevEndDay,
      granularity: span <= MAX_REPORT_TREND_DAYS ? 'day' : 'month',
      reportStartDay: shiftDay(today, -(reportSpan - 1)),
    };
  }

  private timeWindowCond(
    column: AnyPgColumn,
    startDay: string,
    endDay: string
  ) {
    return and(
      gte(column, new Date(dayToUtcMs(startDay))),
      lt(column, new Date(dayToUtcMs(endDay) + DAY_MS))
    );
  }

  private ownerCond(column: unknown, ownerId: string | undefined) {
    if (!ownerId) {
      return undefined;
    }
    return sql`(${column}).user_id = ${ownerId}`;
  }

  private async queryQuotationWindow(
    startDay: string,
    endDay: string,
    ownerId: string | undefined
  ): Promise<QuotationWindowRow> {
    const rows: QuotationWindowRow[] = await this.db
      .select({
        count: count(),
        amount: sql<string>`coalesce(sum(${quotation.totalAmount}), 0)`,
        confirmed: sql<number>`count(*) filter (where ${quotation.status} = 'confirmed')`,
      })
      .from(quotation)
      .where(
        and(
          this.timeWindowCond(quotation.createdAt, startDay, endDay),
          this.ownerCond(quotation.createdBy, ownerId)
        )
      );
    return rows[0] ?? { count: 0, amount: '0', confirmed: 0 };
  }

  private async buildCards(
    window_: DateWindow,
    ownerId: string | undefined
  ): Promise<DashboardCards> {
    const [currentQuotation, prevQuotation, newCustomerRows,
      prevNewCustomerRows, totalCustomerRows, activeProjectRows,
      todayReportRows, yesterdayReportRows] = await Promise.all([
      this.queryQuotationWindow(window_.startDay, window_.endDay, ownerId),
      this.queryQuotationWindow(
        window_.prevStartDay,
        window_.prevEndDay,
        ownerId
      ),
      this.db
        .select({ count: count() })
        .from(customer)
        .where(
          and(
            this.timeWindowCond(customer.createdAt, window_.startDay,
              window_.endDay),
            this.ownerCond(customer.createdBy, ownerId)
          )
        ),
      this.db
        .select({ count: count() })
        .from(customer)
        .where(
          and(
            this.timeWindowCond(customer.createdAt, window_.prevStartDay,
              window_.prevEndDay),
            this.ownerCond(customer.createdBy, ownerId)
          )
        ),
      this.db
        .select({ count: count() })
        .from(customer)
        .where(this.ownerCond(customer.createdBy, ownerId)),
      this.db
        .select({ count: count() })
        .from(project)
        .where(
          and(
            eq(project.status, 'in_progress'),
            this.ownerCond(project.owner, ownerId)
          )
        ),
      this.countReports(toShanghaiDay(Date.now()), ownerId),
      this.countReports(shiftDay(toShanghaiDay(Date.now()), -1), ownerId),
    ]);

    const quotationAmount: DashboardDeltaStat = {
      value: Number(currentQuotation.amount),
      delta: calcDelta(
        Number(currentQuotation.amount),
        Number(prevQuotation.amount)
      ),
    };
    const quotationCount: DashboardDeltaStat = {
      value: currentQuotation.count,
      delta: calcDelta(currentQuotation.count, prevQuotation.count),
    };
    const newCustomers: number = newCustomerRows[0]?.count ?? 0;
    const customerCount: DashboardDeltaStat = {
      value: totalCustomerRows[0]?.count ?? 0,
      delta: calcDelta(newCustomers, prevNewCustomerRows[0]?.count ?? 0),
    };
    const todayReportCount: DashboardDeltaStat = {
      value: todayReportRows,
      delta: calcDelta(todayReportRows, yesterdayReportRows),
    };

    return {
      quotationAmount,
      quotationCount,
      customerCount,
      activeProjectCount: activeProjectRows[0]?.count ?? 0,
      todayReportCount,
    };
  }

  private async countReports(
    day: string,
    ownerId: string | undefined
  ): Promise<number> {
    const rows: { count: number }[] = await this.db
      .select({ count: count() })
      .from(dailyReport)
      .where(
        and(
          eq(dailyReport.reportDate, day),
          this.ownerCond(dailyReport.author, ownerId)
        )
      );
    return rows[0]?.count ?? 0;
  }

  private async buildQuotationTrend(
    window_: DateWindow,
    ownerId: string | undefined
  ): Promise<DashboardQuotationTrendPoint[]> {
    const format: string =
      window_.granularity === 'day' ? 'YYYY-MM-DD' : 'YYYY-MM';
    const rows: { bucket: string; amount: string; count: number }[] =
      await this.db
        .select({
          bucket: sql<string>`to_char(${quotation.createdAt} at time zone 'Asia/Shanghai', ${format})`,
          amount: sql<string>`coalesce(sum(${quotation.totalAmount}), 0)`,
          count: count(),
        })
        .from(quotation)
        .where(
          and(
            this.timeWindowCond(quotation.createdAt, window_.startDay,
              window_.endDay),
            this.ownerCond(quotation.createdBy, ownerId)
          )
        )
        .groupBy(sql`1`);
    const byBucket: Map<string, { amount: number; count: number }> = new Map(
      rows.map((row) => [row.bucket,
        { amount: Number(row.amount), count: row.count }])
    );
    const buckets: string[] = window_.granularity === 'day'
      ? listDayBuckets(window_.startDay, window_.endDay)
      : listMonthBuckets(window_.startDay, window_.endDay);
    return buckets.map((bucket: string): DashboardQuotationTrendPoint => {
      const hit: { amount: number; count: number } | undefined =
        byBucket.get(bucket);
      return {
        date: bucket,
        amount: hit?.amount ?? 0,
        count: hit?.count ?? 0,
      };
    });
  }

  private async buildCustomerTrend(
    window_: DateWindow,
    ownerId: string | undefined
  ): Promise<DashboardStatPoint[]> {
    const format: string =
      window_.granularity === 'day' ? 'YYYY-MM-DD' : 'YYYY-MM';
    const rows: { bucket: string; count: number }[] = await this.db
      .select({
        bucket: sql<string>`to_char(${customer.createdAt} at time zone 'Asia/Shanghai', ${format})`,
        count: count(),
      })
      .from(customer)
      .where(
        and(
          this.timeWindowCond(customer.createdAt, window_.startDay,
            window_.endDay),
          this.ownerCond(customer.createdBy, ownerId)
        )
      )
      .groupBy(sql`1`);
    const byBucket: Map<string, number> = new Map(
      rows.map((row) => [row.bucket, row.count])
    );
    const buckets: string[] = window_.granularity === 'day'
      ? listDayBuckets(window_.startDay, window_.endDay)
      : listMonthBuckets(window_.startDay, window_.endDay);
    return buckets.map((bucket: string): DashboardStatPoint => ({
      date: bucket,
      value: byBucket.get(bucket) ?? 0,
    }));
  }

  private async buildProjectStatusDist(ownerId: string | undefined) {
    const rows: { status: string; count: number }[] = await this.db
      .select({ status: project.status, count: count() })
      .from(project)
      .where(this.ownerCond(project.owner, ownerId))
      .groupBy(project.status);
    return rows.map((row) => ({
      status: row.status as DashboardStats['projectStatusDist'][number]['status'],
      count: row.count,
    }));
  }

  private async buildReportRateTrend(
    window_: DateWindow,
    ownerId: string | undefined
  ): Promise<DashboardReportRatePoint[]> {
    let employeeIds: string[];
    if (ownerId) {
      employeeIds = [ownerId];
    } else {
      const rows: Record<string, unknown>[] = await this.db.execute(sql`
        select distinct uid from (
          select (${quotation.createdBy}).user_id as uid from ${quotation}
          union select (${project.owner}).user_id from ${project}
          union select (${customer.createdBy}).user_id from ${customer}
          union select (${dailyReport.author}).user_id from ${dailyReport}
        ) as staff where uid is not null and uid <> ''
      `);
      employeeIds = rows.map(
        (row: Record<string, unknown>) => String(row.uid ?? '')
      ).filter((id: string) => id.length > 0);
    }
    const total: number = employeeIds.length;
    const today: string = toShanghaiDay(Date.now());
    const rows: { day: string; submitted: number | string }[] = await this.db
      .select({
        day: dailyReport.reportDate,
        submitted: sql<number>`count(distinct (${dailyReport.author}).user_id)`,
      })
      .from(dailyReport)
      .where(
        and(
          gte(dailyReport.reportDate, window_.reportStartDay),
          lte(dailyReport.reportDate, today),
          this.ownerCond(dailyReport.author, ownerId)
        )
      )
      .groupBy(dailyReport.reportDate);
    const byDay: Map<string, number> = new Map(
      rows.map((row) => [row.day, Number(row.submitted)])
    );
    return listDayBuckets(window_.reportStartDay, today).map(
      (day: string): DashboardReportRatePoint => {
        const submitted: number = byDay.get(day) ?? 0;
        return {
          date: day,
          submitted,
          total,
          rate: total > 0
            ? Math.round((submitted / total) * 1000) / 10
            : 0,
        };
      }
    );
  }

  private async buildMetrics(
    window_: DateWindow,
    ownerId: string | undefined
  ): Promise<DashboardMetrics> {
    const [quotationStat, totalCustomerRows, followedCustomerRows,
      completedProjectRows] = await Promise.all([
      this.queryQuotationWindow(window_.startDay, window_.endDay, ownerId),
      this.db
        .select({ count: count() })
        .from(customer)
        .where(this.ownerCond(customer.createdBy, ownerId)),
      this.db
        .select({
          count: sql<number>`count(distinct ${followUp.customerId})`,
        })
        .from(followUp)
        .innerJoin(customer, eq(followUp.customerId, customer.id))
        .where(this.ownerCond(customer.createdBy, ownerId)),      this.db
        .select({
          completed: count(),
          onTime: sql<number>`count(*) filter (where ${project.updatedAt} <= (${project.endDate} + 1)::timestamp at time zone 'Asia/Shanghai')`,
        })
        .from(project)
        .where(
          and(
            eq(project.status, 'completed'),
            this.ownerCond(project.owner, ownerId)
          )
        ),
    ]);

    const totalCustomers: number = totalCustomerRows[0]?.count ?? 0;
    const completed: number = completedProjectRows[0]?.completed ?? 0;
    const followedCustomers: number =
      Number(followedCustomerRows[0]?.count ?? 0);
    const onTimeCount: number = Number(completedProjectRows[0]?.onTime ?? 0);
    return {
      conversionRate: quotationStat.count > 0
        ? Math.round((quotationStat.confirmed / quotationStat.count) * 1000) / 10
        : 0,
      followUpRate: totalCustomers > 0
        ? Math.round((followedCustomers / totalCustomers) * 1000) / 10
        : 0,
      onTimeRate: completed > 0
        ? Math.round((onTimeCount / completed) * 1000) / 10
        : 0,
      avgQuotationAmount: quotationStat.count > 0
        ? Math.round(Number(quotationStat.amount) / quotationStat.count)
        : 0,
    };
  }
}
