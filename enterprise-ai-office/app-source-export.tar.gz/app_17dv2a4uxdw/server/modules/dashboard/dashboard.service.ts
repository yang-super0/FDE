import { Inject, Injectable } from '@nestjs/common';
import {
  DRIZZLE_DATABASE,
  type PostgresJsDatabase,
} from '@lark-apaas/fullstack-nestjs-core';
import { and, asc, count, eq, gte, isNotNull, lte, ne, sql } from 'drizzle-orm';
import {
  customer,
  dailyReport,
  followUp,
  project,
  quotation,
} from '@server/database/schema';
import type {
  DashboardOverview,
  DashboardTodos,
  FollowUpTodo,
  NearingProjectTodo,
} from '@shared/api.interface';

const SHANGHAI_OFFSET_MS: number = 8 * 60 * 60 * 1000;
const TODO_WINDOW_DAYS: number = 7;
const FOLLOW_UP_LIMIT: number = 5;

interface ShanghaiBoundaries {
  today: string;
  weekLater: string;
  monthStart: Date;
}

interface QuotationStatRow {
  count: number;
  amount: string;
}

interface CountRow {
  count: number;
}

@Injectable()
export class DashboardService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase
  ) {}

  private getShanghaiBoundaries(now: Date): ShanghaiBoundaries {
    const local: Date = new Date(now.getTime() + SHANGHAI_OFFSET_MS);
    const pad = (value: number): string => String(value).padStart(2, '0');
    const year: number = local.getUTCFullYear();
    const monthIndex: number = local.getUTCMonth();
    const today: string = `${year}-${pad(monthIndex + 1)}-${pad(
      local.getUTCDate()
    )}`;
    const end: Date = new Date(
      local.getTime() + TODO_WINDOW_DAYS * 24 * 60 * 60 * 1000
    );
    const weekLater: string = `${end.getUTCFullYear()}-${pad(
      end.getUTCMonth() + 1
    )}-${pad(end.getUTCDate())}`;
    const monthStartUtcMs: number =
      Date.UTC(year, monthIndex, 1) - SHANGHAI_OFFSET_MS;
    return { today, weekLater, monthStart: new Date(monthStartUtcMs) };
  }

  async getOverview(): Promise<DashboardOverview> {
    const boundaries: ShanghaiBoundaries = this.getShanghaiBoundaries(
      new Date()
    );

    const [
      quotationStatRows,
      customerStatRows,
      activeProjectRows,
      todayReportRows,
    ]: [QuotationStatRow[], CountRow[], CountRow[], CountRow[]] =
      await Promise.all([
        this.db
          .select({
            count: count(),
            amount: sql<string>`coalesce(sum(${quotation.totalAmount}), 0)`,
          })
          .from(quotation)
          .where(gte(quotation.createdAt, boundaries.monthStart)),
        this.db.select({ count: count() }).from(customer),
        this.db
          .select({ count: count() })
          .from(project)
          .where(eq(project.status, 'in_progress')),
        this.db
          .select({ count: count() })
          .from(dailyReport)
          .where(eq(dailyReport.reportDate, boundaries.today)),
      ]);

    const quotationStat: QuotationStatRow = quotationStatRows[0] ?? {
      count: 0,
      amount: '0',
    };
    return {
      monthlyQuotationCount: quotationStat.count,
      monthlyQuotationAmount: Number(quotationStat.amount),
      customerCount: customerStatRows[0]?.count ?? 0,
      activeProjectCount: activeProjectRows[0]?.count ?? 0,
      todayReportCount: todayReportRows[0]?.count ?? 0,
    };
  }

  async getTodos(userId: string | undefined): Promise<DashboardTodos> {
    const boundaries: ShanghaiBoundaries = this.getShanghaiBoundaries(
      new Date()
    );

    const followUpRows: FollowUpTodo[] = await this.db
      .select({
        customerId: followUp.customerId,
        customerName: customer.name,
        nextFollowAt: followUp.nextFollowAt,
      })
      .from(followUp)
      .innerJoin(customer, eq(followUp.customerId, customer.id))
      .where(
        and(
          isNotNull(followUp.nextFollowAt),
          gte(followUp.nextFollowAt, boundaries.today),
          lte(followUp.nextFollowAt, boundaries.weekLater)
        )
      )
      .orderBy(asc(followUp.nextFollowAt))

      .limit(FOLLOW_UP_LIMIT);

    const nearingRows: NearingProjectTodo[] = await this.db
      .select({
        projectId: project.id,
        projectName: project.name,
        endDate: project.endDate,
      })
      .from(project)
      .where(
        and(
          ne(project.status, 'completed'),
          gte(project.endDate, boundaries.today),
          lte(project.endDate, boundaries.weekLater)
        )
      )
      .orderBy(asc(project.endDate));

    let dailyReportMissing: boolean = true;
    if (userId !== undefined && userId !== '') {
      const reportRows: { id: string }[] = await this.db
        .select({ id: dailyReport.id })
        .from(dailyReport)
        .where(
          and(
            eq(dailyReport.reportDate, boundaries.today),
            sql`(${dailyReport.author}).user_id = ${userId}`
          )
        )
        .limit(1);
      dailyReportMissing = reportRows.length === 0;
    }

    return {
      followUps: followUpRows,
      nearingProjects: nearingRows,
      dailyReportMissing,
    };
  }
}
