import {
  BadRequestException,
  Controller,
  Get,
  Query,
  Req,
} from '@nestjs/common';
import type { Request } from 'express';
import type {
  DashboardOverview,
  DashboardOwnerOption,
  DashboardRange,
  DashboardStats,
  DashboardTodos,
} from '@shared/api.interface';
import { DashboardService } from './dashboard.service';
import { DashboardStatsService } from './dashboard-stats.service';

const VALID_RANGES: DashboardRange[] = ['7d', '30d', '90d', 'year', 'custom'];

@Controller('api/dashboard')
export class DashboardController {
  constructor(
    private readonly dashboardService: DashboardService,
    private readonly dashboardStatsService: DashboardStatsService
  ) {}

  @Get('overview')
  async getOverview(): Promise<DashboardOverview> {
    return this.dashboardService.getOverview();
  }

  @Get('todos')
  async getTodos(@Req() req: Request): Promise<DashboardTodos> {
    const userId: string | undefined = req.userContext?.userId;
    return this.dashboardService.getTodos(userId);
  }

  @Get('stats')
  async getStats(
    @Query('range') range: string | undefined,
    @Query('startDate') startDate: string | undefined,
    @Query('endDate') endDate: string | undefined,
    @Query('ownerId') ownerId: string | undefined
  ): Promise<DashboardStats> {
    const resolvedRange: DashboardRange | undefined = VALID_RANGES.find(
      (item: DashboardRange) => item === range
    );
    if (!resolvedRange) {
      throw new BadRequestException('时间范围参数无效');
    }
    return this.dashboardStatsService.getStats({
      range: resolvedRange,
      startDate,
      endDate,
      ownerId,
    });
  }

  @Get('owners')
  async getOwners(): Promise<DashboardOwnerOption[]> {
    return this.dashboardStatsService.getOwnerOptions();
  }
}
