/* eslint-disable */
/** auto generated, do not edit */
import { sql } from 'drizzle-orm';
import { bigint, date, foreignKey, index, integer, jsonb, numeric, pgTable, text, uniqueIndex, uuid, varchar, customType } from "drizzle-orm/pg-core"

export const customTimestamptz = customType<{
  data: Date;
  driverData: string;
  config: { precision?: number };
}>({
  dataType(config) {
    const precision = typeof config?.precision !== 'undefined'
      ? ` (${config.precision})`
      : '';
    return `timestamptz${precision}`;
  },
  toDriver(value: Date | string | number) {
    if (value == null) return value as any;
    if (typeof value === 'number') return new Date(value).toISOString();
    if (typeof value === 'string') return value;
    if (value instanceof Date) return value.toISOString();
    throw new Error('Invalid timestamp value');
  },
  fromDriver(value: string | Date): Date {
    if (value instanceof Date) return value;
    return new Date(value);
  },
});

export const userProfile = customType<{
  data: string;
  driverData: string;
}>({
  dataType() {
    return 'user_profile';
  },
  toDriver(value: string) {
    return sql`ROW(${value})::user_profile`;
  },
  fromDriver(value: string) {
    const [userId] = value.slice(1, -1).split(',');
    return userId.trim();
  },
});

export type FileAttachment = {
  bucket_id: string;
  file_path: string;
};

export const fileAttachment = customType<{
  data: FileAttachment;
  driverData: string;
}>({
  dataType() {
    return 'file_attachment';
  },
  toDriver(value: FileAttachment) {
    return sql`ROW(${value.bucket_id},${value.file_path})::file_attachment`;
  },
  fromDriver(value: string): FileAttachment {
    const [bucketId, filePath] = value.slice(1, -1).split(',');
    return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
  },
});

export function escapeLiteral(str: string): string {
  return "'" + str.replace(/'/g, "''") + "'";
}

export const userProfileArray = customType<{
  data: string[];
  driverData: string;
}>({
  dataType() {
    return 'user_profile[]';
  },
  toDriver(value: string[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::user_profile[]`;
    }
    const elements = value.map(id => `ROW(${escapeLiteral(id)})::user_profile`).join(',');
    return sql.raw(`ARRAY[${elements}]::user_profile[]`);
  },
  fromDriver(value: string): string[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => m.slice(1, -1).split(',')[0].trim());
  },
});

export const fileAttachmentArray = customType<{
  data: FileAttachment[];
  driverData: string;
}>({
  dataType() {
    return 'file_attachment[]';
  },
  toDriver(value: FileAttachment[]) {
    if (!value || value.length === 0) {
      return sql`'{}'::file_attachment[]`;
    }
    const elements = value.map(f =>
      `ROW(${escapeLiteral(f.bucket_id)},${escapeLiteral(f.file_path)})::file_attachment`
    ).join(',');
    return sql.raw(`ARRAY[${elements}]::file_attachment[]`);
  },
  fromDriver(value: string): FileAttachment[] {
    if (!value || value === '{}') return [];
    const inner = value.slice(1, -1);
    const matches = inner.match(/\([^)]*\)/g) || [];
    return matches.map(m => {
      const [bucketId, filePath] = m.slice(1, -1).split(',');
      return { bucket_id: bucketId.trim(), file_path: filePath.trim() };
    });
  },
});

export const alertDismiss = pgTable("alert_dismiss", {
  id: uuid("id").primaryKey().defaultRandom(),
  alertType: varchar("alert_type", { length: 50 }).notNull(),
  targetId: varchar("target_id", { length: 100 }).notNull(),
  dismissedBy: userProfile("dismissed_by").notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("idx_alert_dismiss_type_target").on(table.alertType, table.targetId),
  // Complex index: CREATE INDEX idx_alert_dismiss_user ON alert_dismiss USING btree (((dismissed_by).user_id)),
]);

export const meetingMinutes = pgTable("meeting_minutes", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: varchar("title", { length: 200 }).notNull(),
  meetingDate: date("meeting_date").notNull(),
  meetingType: varchar("meeting_type", { length: 20 }).notNull(),
  customerId: uuid("customer_id"),
  /**
   * @type [{ name: string; role: string }]
   */
  attendees: jsonb("attendees").notNull().default('[]'),
  /**
   * @type string[]
   */
  keyTopics: jsonb("key_topics").notNull().default('[]'),
  /**
   * @type [{ content: string; assignee: string; due_date: string; status: string }]
   */
  actionItems: jsonb("action_items").notNull().default('[]'),
  decisions: text("decisions"),
  source: varchar("source", { length: 20 }).notNull().default('手动录入'),
  createdBy: varchar("created_by", { length: 100 }).notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_meeting_minutes_meeting_date").on(table.meetingDate),
  index("idx_meeting_minutes_meeting_type").on(table.meetingType),
  index("idx_meeting_minutes_customer_id").on(table.customerId),
  index("idx_meeting_minutes_source").on(table.source),
  foreignKey({
    columns: [table.customerId],
    foreignColumns: [customer.id],
    name: "meeting_minutes_customer_id_fkey",
  }).onDelete("set null"),
]);

export const workRecords = pgTable("work_records", {
  id: uuid("id").primaryKey().defaultRandom(),
  employeeId: varchar("employee_id", { length: 100 }).notNull(),
  workDate: date("work_date").notNull(),
  workType: varchar("work_type", { length: 20 }).notNull(),
  relatedId: bigint("related_id", { mode: 'number' }),
  content: text("content").notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_work_records_employee_date").on(table.employeeId, table.workDate),
  index("idx_work_records_work_type").on(table.workType),
  index("idx_work_records_work_date").on(table.workDate),
]);

export const quotationUnits = pgTable("quotation_units", {
  id: uuid("id").primaryKey().defaultRandom(),
  quotationId: uuid("quotation_id").notNull(),
  unitNo: integer("unit_no").notNull(),
  productId: uuid("product_id").notNull(),
  projectScene: varchar("project_scene", { length: 50 }).notNull().default('普通项目'),
  unitSubtotal: numeric("unit_subtotal").notNull().default('0'),
  remark: text("remark"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_quotation_units_quotation_id").on(table.quotationId),
  foreignKey({
    columns: [table.quotationId],
    foreignColumns: [quotation.id],
    name: "quotation_units_quotation_id_fkey",
  }).onDelete("cascade"),
  foreignKey({
    columns: [table.productId],
    foreignColumns: [products.id],
    name: "quotation_units_product_id_fkey",
  }),
]);

export const pricingRules = pgTable("pricing_rules", {
  id: uuid("id").primaryKey().defaultRandom(),
  productId: uuid("product_id").notNull(),
  customItemId: uuid("custom_item_id"),
  ruleType: varchar("rule_type", { length: 50 }).notNull(),
  priceAdjustment: numeric("price_adjustment").notNull().default('0'),
  /**
   * @type { [key: string]: string | number | boolean }
   */
  conditions: jsonb("conditions"),
  priority: integer("priority").notNull().default(0),
  description: text("description"),
  status: varchar("status", { length: 20 }).notNull().default('active'),
  name: varchar("name", { length: 200 }).notNull().default('未命名规则'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_pricing_rules_product_id").on(table.productId),
  index("idx_pricing_rules_custom_item_id").on(table.customItemId),
  foreignKey({
    columns: [table.productId],
    foreignColumns: [products.id],
    name: "pricing_rules_product_id_fkey",
  }).onDelete("cascade"),
  foreignKey({
    columns: [table.customItemId],
    foreignColumns: [customItems.id],
    name: "pricing_rules_custom_item_id_fkey",
  }).onDelete("cascade"),
]);

export const customItems = pgTable("custom_items", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  categoryId: uuid("category_id").notNull(),
  description: text("description"),
  defaultPrice: numeric("default_price").notNull().default('0'),
  priceType: varchar("price_type", { length: 20 }).notNull().default('fixed'),
  unit: varchar("unit", { length: 20 }),
  status: varchar("status", { length: 20 }).notNull().default('active'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_custom_items_category_id").on(table.categoryId),
  foreignKey({
    columns: [table.categoryId],
    foreignColumns: [customCategories.id],
    name: "custom_items_category_id_fkey",
  }).onDelete("restrict"),
]);

export const customCategories = pgTable("custom_categories", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  parentId: uuid("parent_id"),
  sortOrder: integer("sort_order").notNull().default(0),
  status: varchar("status", { length: 20 }).notNull().default('active'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_custom_categories_parent_id").on(table.parentId),
  foreignKey({
    columns: [table.parentId],
    foreignColumns: [customCategories.id],
    name: "custom_categories_parent_id_fkey",
  }).onDelete("set null"),
]);

export const products = pgTable("products", {
  id: uuid("id").primaryKey().defaultRandom(),
  productCode: varchar("product_code", { length: 50 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }),
  basePrice: numeric("base_price").notNull().default('0'),
  description: text("description"),
  /**
   * @type { [key: string]: string }
   */
  spec: jsonb("spec"),
  status: varchar("status", { length: 20 }).notNull().default('active'),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("products_product_code_key").on(table.productCode),
]);

export const dailyReport = pgTable("daily_report", {
  id: uuid("id").primaryKey().defaultRandom(),
  reportDate: date("report_date").notNull(),
  author: userProfile("author").notNull(),
  todayContent: text("today_content").notNull(),
  tomorrowPlan: text("tomorrow_plan"),
  risk: text("risk"),
  status: varchar("status", { length: 20 }).notNull().default('submitted'),
  /**
   * @type { categories: [{ type: string; items: [{ time: string; relatedObject: string; summary: string }] }] }
   */
  contentStructure: jsonb("content_structure"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  // Complex index: CREATE UNIQUE INDEX idx_daily_report_author_date ON daily_report USING btree (((author).user_id), report_date),
  index("idx_daily_report_date").on(table.reportDate),
]);

export const projectTask = pgTable("project_task", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull(),
  taskName: varchar("task_name", { length: 255 }).notNull(),
  assignee: userProfile("assignee").notNull(),
  status: varchar("status", { length: 20 }).notNull().default('pending'),
  dueDate: date("due_date").notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_project_task_project_id").on(table.projectId),
  foreignKey({
    columns: [table.projectId],
    foreignColumns: [project.id],
    name: "project_task_project_id_fkey",
  }).onDelete("cascade"),
]);

export const projectMember = pgTable("project_member", {
  id: uuid("id").primaryKey().defaultRandom(),
  projectId: uuid("project_id").notNull(),
  member: userProfile("member").notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_project_member_project_id").on(table.projectId),
  // Complex index: CREATE UNIQUE INDEX idx_project_member_unique ON project_member USING btree (project_id, ((member).user_id)),
  foreignKey({
    columns: [table.projectId],
    foreignColumns: [project.id],
    name: "project_member_project_id_fkey",
  }).onDelete("cascade"),
]);

export const project = pgTable("project", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull(),
  owner: userProfile("owner").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  description: text("description"),
  status: varchar("status", { length: 20 }).notNull().default('not_started'),
  progress: integer("progress").notNull().default(0),
  customerId: uuid("customer_id"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_project_customer_id").on(table.customerId),
  foreignKey({
    columns: [table.customerId],
    foreignColumns: [customer.id],
    name: "project_customer_id_fkey",
  }),
]);

export const quotationItem = pgTable("quotation_item", {
  id: uuid("id").primaryKey().defaultRandom(),
  quotationId: uuid("quotation_id").notNull(),
  itemName: varchar("item_name", { length: 255 }).notNull(),
  quantity: numeric("quantity").notNull(),
  unitPrice: numeric("unit_price").notNull(),
  amount: numeric("amount").notNull(),
  customItemId: uuid("custom_item_id"),
  priceAdjustment: numeric("price_adjustment"),
  quotationUnitId: uuid("quotation_unit_id"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_quotation_item_quotation_id").on(table.quotationId),
  index("idx_quotation_item_custom_item_id").on(table.customItemId),
  index("idx_quotation_item_unit_id").on(table.quotationUnitId),
  foreignKey({
    columns: [table.quotationId],
    foreignColumns: [quotation.id],
    name: "quotation_item_quotation_id_fkey",
  }).onDelete("cascade"),
  foreignKey({
    columns: [table.customItemId],
    foreignColumns: [customItems.id],
    name: "quotation_item_custom_item_id_fkey",
  }).onDelete("set null"),
  foreignKey({
    columns: [table.quotationUnitId],
    foreignColumns: [quotationUnits.id],
    name: "quotation_item_quotation_unit_id_fkey",
  }).onDelete("cascade"),
]);

export const quotation = pgTable("quotation", {
  id: uuid("id").primaryKey().defaultRandom(),
  quotationNo: varchar("quotation_no", { length: 50 }).notNull().unique(),
  customerId: uuid("customer_id").notNull(),
  totalAmount: numeric("total_amount").notNull().default('0'),
  status: varchar("status", { length: 20 }).notNull().default('draft'),
  remark: text("remark"),
  aiSuggestion: text("ai_suggestion"),
  productId: uuid("product_id"),
  projectScene: varchar("project_scene", { length: 50 }).notNull().default('普通项目'),
  totalUnits: integer("total_units").notNull().default(1),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("quotation_quotation_no_key").on(table.quotationNo),
  index("idx_quotation_customer_id").on(table.customerId),
  index("idx_quotation_product_id").on(table.productId),
  foreignKey({
    columns: [table.customerId],
    foreignColumns: [customer.id],
    name: "quotation_customer_id_fkey",
  }),
  foreignKey({
    columns: [table.productId],
    foreignColumns: [products.id],
    name: "quotation_product_id_fkey",
  }).onDelete("restrict"),
]);

export const followUp = pgTable("follow_up", {
  id: uuid("id").primaryKey().defaultRandom(),
  customerId: uuid("customer_id").notNull(),
  method: varchar("method", { length: 50 }).notNull(),
  content: text("content").notNull(),
  nextFollowAt: date("next_follow_at"),
  operator: userProfile("operator").notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  index("idx_follow_up_customer_id").on(table.customerId),
  foreignKey({
    columns: [table.customerId],
    foreignColumns: [customer.id],
    name: "follow_up_customer_id_fkey",
  }).onDelete("cascade"),
]);

export const customer = pgTable("customer", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  industry: varchar("industry", { length: 100 }),
  contactName: varchar("contact_name", { length: 100 }),
  contactPhone: varchar("contact_phone", { length: 50 }),
  address: varchar("address", { length: 500 }),
  lastFollowedAt: customTimestamptz("last_followed_at", { precision: 6 }),
  owner: userProfile("owner"),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 3 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by").default(sql`CASE
    WHEN (current_setting('app.user_id'::text, true) = ''::text) THEN NULL`),
}, (table) => [
  uniqueIndex("customer_name_key").on(table.name),
  // Complex index: CREATE INDEX idx_customer_owner ON customer USING btree (((owner).user_id)),
]);

export const authzRolePermissions = pgTable("authz_role_permissions", {
  id: uuid("id").primaryKey().defaultRandom(),
  roleKey: varchar("role_key", { length: 100 }).notNull(),
  permissionId: uuid("permission_id").notNull(),
  creator: userProfile("creator").notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 6 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by"),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 6 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by"),
}, (table) => [
  uniqueIndex("authz_role_permissions_role_key_permission_id_key").on(table.roleKey, table.permissionId),
  foreignKey({
    columns: [table.permissionId],
    foreignColumns: [authzPermissions.id],
    name: "authz_role_permissions_permission_id_fkey",
  }).onDelete("cascade"),
]);

export const authzPermissions = pgTable("authz_permissions", {
  id: uuid("id").primaryKey().defaultRandom(),
  action: varchar("action", { length: 100 }).notNull(),
  subject: varchar("subject", { length: 100 }).notNull(),
  description: text("description"),
  creator: userProfile("creator").notNull(),
  // System field: Creation time (auto-filled, do not modify)
  createdAt: customTimestamptz("_created_at", { precision: 6 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Creator (auto-filled, do not modify)
  createdBy: userProfile("_created_by"),
  // System field: Update time (auto-filled, do not modify)
  updatedAt: customTimestamptz("_updated_at", { precision: 6 }).notNull().default(sql`CURRENT_TIMESTAMP`),
  // System field: Updater (auto-filled, do not modify)
  updatedBy: userProfile("_updated_by"),
}, (table) => [
  uniqueIndex("authz_permissions_action_subject_key").on(table.action, table.subject),
]);

// table aliases
export const alertDismissTable = alertDismiss;
export const authzPermissionsTable = authzPermissions;
export const authzRolePermissionsTable = authzRolePermissions;
export const customCategoriesTable = customCategories;
export const customItemsTable = customItems;
export const customerTable = customer;
export const dailyReportTable = dailyReport;
export const followUpTable = followUp;
export const meetingMinutesTable = meetingMinutes;
export const pricingRulesTable = pricingRules;
export const productsTable = products;
export const projectTable = project;
export const projectMemberTable = projectMember;
export const projectTaskTable = projectTask;
export const quotationTable = quotation;
export const quotationItemTable = quotationItem;
export const quotationUnitsTable = quotationUnits;
export const workRecordsTable = workRecords;
