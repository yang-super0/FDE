# UI 设计指南

> **设计类型**: App 设计（应用架构设计）
> **确认检查**: 本指南适用于可交互的应用/网站/工具。

> ℹ️ Section 1 为设计意图与决策上下文。Code agent 实现时以 Section 2 及之后的具体参数为准。

## 1. Design Archetype (设计原型)

### 1.1 内容理解

- **目标用户**: 企业销售、项目经理、管理层；高频办公场景，追求高效掌控感
- **核心目的**: 信息聚合与任务驱动，支持 AI 辅助决策与多角色协同
- **情绪基调**: 专业冷静 / 避免焦虑与视觉疲劳

### 1.2 设计方向

- **Design Style**: Grid 网格 + Soft Blocks 柔色块融合 — 兼顾数据密度与阅读舒适度，适配 SaaS 商务场景
- **Application Type**: Admin/SaaS — PC 宽屏优先，左侧边栏导航
- **Aesthetic Direction**: 蓝灰冷调基底 + 结构化留白 + 关键数据高亮

## 2. Color System (色彩系统)

**色彩关系**: 冷灰蓝主色 + 极浅蓝灰底 + 深墨文字 + 状态语义色
**配色设计理由**: 蓝灰基调契合企业办公专业感，低饱和底色降低高频使用疲劳
**主色推导**: primary 取自商务蓝灰，用于新建/确认/AI 生成等核心行动点
**使用比例**: 60% 中性底 / 30% 卡片白 / 10% 主色+状态色点缀

### 2.1 主题颜色

| Token                | HSL 值             | 说明                                     |
| -------------------- | ------------------ | ---------------------------------------- |
| `background`         | hsl(216 20% 97%)   | 页面底色，冷灰蓝调                       |
| `card`               | hsl(0 0% 100%)     | 卡片/容器背景                            |
| `foreground`         | hsl(220 25% 12%)   | 主文字，深墨色                           |
| `muted-foreground`   | hsl(216 15% 50%)   | 次要文字                                 |
| `primary`            | hsl(217 70% 52%)   | 主交互色，沉稳商务蓝                     |
| `primary-foreground` | hsl(0 0% 100%)     | 主交互文字/图标                          |
| `accent`             | hsl(217 40% 95%)   | 次级交互反馈（hover/focus/骨架屏背景）   |
| `accent-foreground`  | hsl(217 70% 40%)   | accent 上的文字/图标                     |
| `border`             | hsl(216 18% 88%)   | 边框，低对比度分隔                       |

### 2.2 导航区配色

- **基调关系**: 复用主配色系统，侧边栏背景略深于 content 区以区分层级
- **关键状态**: 激活态使用 `bg-accent` + `text-primary`；hover 态使用 `bg-accent`；默认态 `text-muted-foreground`
- **边界与背景**: 非透明背景；右侧 1px `border` 分隔内容区

### 2.3 语义颜色

| 用途       | 边框/文字          | 背景              | 说明                         |
| ---------- | ------------------ | ----------------- | ---------------------------- |
| 成功/已确认 | hsl(152 60% 42%)   | hsl(152 55% 96%)  | 报价已确认、项目已完成       |
| 警告/延期   | hsl(38 85% 48%)    | hsl(38 80% 96%)   | 项目延期、待跟进提醒         |
| 错误/关闭   | hsl(0 65% 52%)     | hsl(0 60% 96%)    | 校验失败、已关闭单据         |
| 草稿/未开始 | hsl(216 15% 55%)   | hsl(216 12% 94%)  | 中性状态标签                 |

## 3. Typography (字体排版)

- **Heading**: Inter, "PingFang SC", "Microsoft YaHei", sans-serif
- **Body**: Inter, "PingFang SC", "Microsoft YaHei", sans-serif
- **数字专用**: Roboto Mono, "SF Mono", monospace（统计卡片金额/数量）
- **字体策略**: 西文 Inter 保障数据对齐与可读性；中文回退苹方/微软雅黑；关键数字使用等宽字体确保位数对齐

## 4. Layout Strategy (布局策略)

- **导航意图**: 持久型左侧边栏导航（应用概要设计已声明 6 个入口）；至多一套；非透明背景；按角色权限动态渲染菜单项
- **页面架构**: Sidebar + Content 两栏布局；内容区 `max-w-[1400px]` 居中；工作台/列表页全宽利用，表单/详情页限制阅读宽度
- **响应式**: 移动端侧边栏折叠为底部 Tab 或汉堡菜单；桌面端保持双栏常态

## 5. Visual Language (视觉语言)

- **形态参数**: 圆角 `rounded-lg (0.5rem)` · 阴影 `shadow-sm` · 间距基调 `standard (gap-4/p-6)`
- **识别签名**: 统计卡片数字 Roboto Mono + text-3xl font-bold；状态标签 pill 形状 + 语义色背景；AI 操作按钮带微光渐变边框
- **装饰策略**: 仅在工作台问候条与 AI 生成加载态使用微渐变；其余区域纯平面色块
- **动效原则**: 状态流转与列表刷新 200ms ease-out；弹窗出入 250ms ease-in-out
- **可及性**: 正文对比度 ≥ 4.5:1；状态标签文字使用深色变体确保可读；复杂背景加遮罩

## 6. Component Principles (组件原则)

- **状态完整性**: Button/Input/Card/Table Row 覆盖 Default/Hover/Focus/Active/Disabled；AI 生成按钮额外增加 Loading 脉冲态
- **层级清晰**: Primary 填充蓝 / Secondary Outline 蓝边框 / Ghost 无边框仅 hover 显色；表单 Focus ring 2px offset primary
- **一致性**: 所有表格统一行高 `h-12`、列间距 `px-4`；所有弹窗统一 `max-w-2xl rounded-xl shadow-lg`
- **空态处理**: 无待办/无搜索结果时展示插画占位 + 引导文案，不使用纯文字空白

## 7. Image Direction (图片与视觉资产)

- **Image Role**: 无强制图片需求
- **Image Art Direction**: 空态插图采用线性单色风格（primary 色描边 + 5% opacity 填充），几何化办公符号（文档/日历/人员剪影），无真人照片
- **Image Prompt Keywords**: line art, minimal, office symbols, single color stroke, geometric, blueprint style
- **Image Avoidance**: 避免 3D 渲染素材、商务握手照片、通用科技感抽象图、多彩渐变插图

## 8. 应避免 (Anti-patterns)

- ❌ 统计卡片使用彩色图标代替数字本身作为视觉焦点 — 数字才是信息核心
- ❌ 侧边栏使用深色主题而内容区浅色 — 违反应用概要设计的蓝灰统一基调
- ❌ AI 生成结果区域无明确边界或与手动录入区视觉混淆 — 必须用 accent 底色 + 标签区分 AI 产出内容